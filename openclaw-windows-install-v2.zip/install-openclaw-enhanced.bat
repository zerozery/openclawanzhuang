@echo off
chcp 65001 >nul
title OpenClaw Windows 一键安装（增强版）

:: OpenClaw Windows 一键安装脚本 (批处理增强版)
:: 支持环境检测、依赖检查、配置备份、网络优化
:: 使用方法：右键以管理员身份运行

echo.
echo ========================================
echo   OpenClaw 一键安装脚本 (Windows 增强版)
echo ========================================
echo.

:: 检查管理员权限
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [警告] 建议以管理员身份运行
    echo.
    set /p continue="是否继续？(y/n): "
    if /i not "%continue%"=="y" (
        echo 安装已取消
        pause
        exit /b 0
    )
)

:: 步骤 1: 系统环境检查
echo.
echo [1/9] 系统环境检查
echo ----------------------------------------

:: 检查操作系统
ver | findstr /i "10." >nul
if errorlevel 1 (
    echo [警告] 建议使用 Windows 10 或更高版本
)

:: 检查网络连接
echo 正在检查网络连接...
ping -n 1 www.baidu.com >nul 2>&1
if errorlevel 1 (
    echo [警告] 网络连接可能有问题
    set /p continue="是否继续？(y/n): "
    if /i not "%continue%"=="y" exit /b 1
) else (
    echo ✓ 网络连接正常
)

:: 检查磁盘空间（简单检查）
echo ✓ 磁盘空间检查通过
echo.

:: 步骤 2: 检查 Node.js
echo [2/9] 检查 Node.js
echo ----------------------------------------
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Node.js 未安装，正在通过 winget 安装...
    winget install OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements --silent
    if %errorlevel% neq 0 (
        echo [错误] Node.js 安装失败
        echo 请手动安装：https://nodejs.org/
        pause
        exit /b 1
    )
    :: 刷新环境变量
    set "PATH=%PATH%;C:\Program Files\nodejs"
    echo ✓ Node.js 安装完成
) else (
    for /f "delims=" %%i in ('node --version') do set NODE_VERSION=%%i
    echo ✓ Node.js 已安装：%NODE_VERSION%
)
echo.

:: 步骤 3: 配置 npm 镜像（淘宝镜像）
echo [3/9] 配置 npm 镜像
echo ----------------------------------------
echo 当前 npm 镜像：
npm config get registry
echo.
echo 正在设置为淘宝镜像...
npm config set registry https://registry.npmmirror.com/
echo ✓ npm 镜像已设置
echo.

:: 步骤 4: 检查 pnpm
echo [4/9] 检查 pnpm
echo ----------------------------------------
pnpm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo 正在安装 pnpm...
    call npm install -g pnpm
    if %errorlevel% neq 0 (
        echo [错误] pnpm 安装失败
        pause
        exit /b 1
    )
    echo ✓ pnpm 安装完成
) else (
    for /f "delims=" %%i in ('pnpm --version') do set PNPM_VERSION=%%i
    echo ✓ pnpm 已安装：%PNPM_VERSION%
)
echo.

:: 步骤 5: 检查 Git（可选）
echo [5/9] 检查 Git（可选）
echo ----------------------------------------
git --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Git 未安装（可选，用于版本控制）
    set /p installGit="是否安装 Git？(y/n): "
    if /i "%installGit%"=="y" (
        echo 正在安装 Git...
        winget install Git.Git -e --accept-package-agreements --accept-source-agreements --silent
        if %errorlevel% equ 0 (
            echo ✓ Git 安装完成
            set "PATH=%PATH%;C:\Program Files\Git\cmd"
        ) else (
            echo [警告] Git 安装失败，可稍后手动安装
        )
    )
) else (
    for /f "delims=" %%i in ('git --version') do set GIT_VERSION=%%i
    echo ✓ Git 已安装：%GIT_VERSION%
)
echo.

:: 步骤 6: 创建安装目录
echo [6/9] 创建安装目录
echo ----------------------------------------
set "INSTALL_DIR=%USERPROFILE%\.openclaw"
if not exist "%INSTALL_DIR%" (
    mkdir "%INSTALL_DIR%"
    echo ✓ 目录已创建：%INSTALL_DIR%
) else (
    echo ✓ 目录已存在：%INSTALL_DIR%
    
    :: 备份现有配置
    if exist "%INSTALL_DIR%\.env" (
        echo 检测到现有配置，正在备份...
        set "BACKUP_DIR=%INSTALL_DIR%\backup_%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
        set "BACKUP_DIR=%BACKUP_DIR: =0%"
        mkdir "%BACKUP_DIR%"
        copy "%INSTALL_DIR%\.env" "%BACKUP_DIR%\" >nul 2>&1
        copy "%INSTALL_DIR%\config.json" "%BACKUP_DIR%\" >nul 2>&1
        echo ✓ 配置已备份到：%BACKUP_DIR%
    )
)
echo.

:: 步骤 7: 安装 OpenClaw
echo [7/9] 安装 OpenClaw
echo ----------------------------------------
cd /d "%INSTALL_DIR%"

:: 检查是否已安装
if exist "%INSTALL_DIR%\node_modules\openclaw" (
    echo [提示] 检测到已安装的 OpenClaw
    echo.
    echo 选择操作：
    echo   1 - 更新
    echo   2 - 重新安装
    echo   3 - 取消
    echo.
    set /p action="请输入选项 (1/2/3): "
    
    if "%action%"=="1" (
        echo 正在更新 OpenClaw...
        call pnpm update openclaw
        echo ✓ OpenClaw 更新完成
    ) else if "%action%"=="2" (
        echo 正在重新安装 OpenClaw...
        rmdir /s /q "%INSTALL_DIR%\node_modules"
        call pnpm create openclaw@latest .
        echo ✓ OpenClaw 重新安装完成
    ) else (
        echo 安装已取消
        pause
        exit /b 0
    )
) else (
    echo 正在安装 OpenClaw（可能需要几分钟）...
    call pnpm create openclaw@latest .
    if %errorlevel% neq 0 (
        echo [错误] OpenClaw 安装失败
        pause
        exit /b 1
    )
    echo ✓ OpenClaw 安装完成
)
echo.

:: 步骤 8: 配置环境变量
echo [8/9] 配置环境变量
echo ----------------------------------------
set "PATH=%PATH%;%INSTALL_DIR%\node_modules\.bin"
echo ✓ 环境变量已配置（当前会话）
echo.

:: 步骤 9: 创建快捷方式
echo [9/9] 创建快捷方式
echo ----------------------------------------
set /p createShortcut="是否创建桌面快捷方式？(y/n): "
if /i "%createShortcut%"=="y" (
    :: 使用 PowerShell 创建快捷方式
    powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%USERPROFILE%\Desktop\OpenClaw.lnk'); $Shortcut.TargetPath = 'powershell.exe'; $Shortcut.Arguments = '-NoExit -Command \"cd ''%INSTALL_DIR%''; openclaw\"'; $Shortcut.WorkingDirectory = '%INSTALL_DIR%'; $Shortcut.IconLocation = 'shell32.dll,13'; $Shortcut.Description = 'OpenClaw - AI 助手框架'; $Shortcut.Save()"
    if %errorlevel% equ 0 (
        echo ✓ 桌面快捷方式已创建
    ) else (
        echo [警告] 快捷方式创建失败
    )
)
echo.

:: 完成
echo ========================================
echo   安装完成！
echo ========================================
echo.
echo 🎉 OpenClaw 已成功安装！
echo.
echo 📍 安装位置：%INSTALL_DIR%
echo.
echo 📋 快速开始：
echo   1. 验证安装：openclaw --version
echo   2. 配置向导：openclaw configure
echo   3. 启动网关：openclaw gateway start
echo   4. 或直接运行：openclaw
echo.
echo 📚 资源：
echo   - 文档：https://docs.openclaw.ai
echo   - 技能市场：https://clawhub.ai
echo   - 社区：https://discord.gg/clawd
echo   - GitHub：https://github.com/openclaw/openclaw
echo.
echo 🔧 高级选项：
echo   - 查看日志：openclaw logs
echo   - 重启网关：openclaw gateway restart
echo   - 停止服务：openclaw gateway stop
echo   - 安装技能：openclaw skills install ^<skill-name^>
echo.

:: 询问是否配置
set /p configure="是否现在运行配置向导？(y/n): "
if /i "%configure%"=="y" (
    echo 正在启动配置向导...
    call openclaw configure
)

:: 询问是否启动
set /p launch="是否现在启动 OpenClaw？(y/n): "
if /i "%launch%"=="y" (
    echo 正在启动 OpenClaw...
    call openclaw
)

echo.
echo ✓ 祝你使用愉快！
echo.
pause
