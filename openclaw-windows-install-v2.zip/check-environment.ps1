# OpenClaw 环境检查脚本
# 用于安装前检测系统环境是否满足要求

param(
    [switch]$Detailed,
    [switch]$Fix,
    [string]$OutputFile
)

$Results = @{
    Passed = 0
    Failed = 0
    Warnings = 0
    Checks = @()
}

function Write-Check {
    param(
        [string]$Name,
        [bool]$Passed,
        [string]$Message = "",
        [string]$Fix = ""
    )
    
    $status = if ($Passed) { "✓" } else { "✗" }
    $color = if ($Passed) { "Green" } else { "Red" }
    
    Write-Host "$status $Name" -ForegroundColor $color
    if ($Message) {
        Write-Host "  $Message" -ForegroundColor Gray
    }
    if (-not $Passed -and $Fix) {
        Write-Host "  修复：$Fix" -ForegroundColor Yellow
    }
    
    $Results.Checks += @{
        Name = $Name
        Passed = $Passed
        Message = $Message
        Fix = $Fix
    }
    
    if ($Passed) {
        $Results.Passed++
    } else {
        $Results.Failed++
    }
}

function Write-Warning {
    param([string]$Message)
    Write-Host "⚠ $Message" -ForegroundColor Yellow
    $Results.Warnings++
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  OpenClaw 环境检查" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 1. 操作系统检查
Write-Host "[1/10] 操作系统" -ForegroundColor Magenta
$osVersion = [Environment]::OSVersion.Version
$osName = (Get-WmiObject Win32_OperatingSystem).Caption
Write-Check -Name "Windows 版本" `
    -Passed ($osVersion.Major -ge 10) `
    -Message "$osName (Build $($osVersion.Build))" `
    -Fix "建议升级到 Windows 10 或更高版本"

# 2. 内存检查
Write-Host ""
Write-Host "[2/10] 内存" -ForegroundColor Magenta
$memory = (Get-WmiObject Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum / 1GB
Write-Check -Name "物理内存" `
    -Passed ($memory -ge 4) `
    -Message "$([math]::Round($memory, 2)) GB" `
    -Fix "建议至少 4GB 内存"

if ($memory -lt 8) {
    Write-Warning "内存小于 8GB，可能影响性能"
}

# 3. 磁盘空间检查
Write-Host ""
Write-Host "[3/10] 磁盘空间" -ForegroundColor Magenta
$disk = Get-WmiObject Win32_LogicalDisk -Filter "DriveType=3" | Select-Object DeviceID, Size, FreeSpace
foreach ($d in $disk) {
    $freeGB = [math]::Round($d.FreeSpace / 1GB, 2)
    $totalGB = [math]::Round($d.Size / 1GB, 2)
    $drive = $d.DeviceID
    
    if ($drive -eq "C:") {
        Write-Check -Name "$drive 盘可用空间" `
            -Passed ($freeGB -ge 1) `
            -Message "$freeGB GB / $totalGB GB" `
            -Fix "清理磁盘空间或选择其他磁盘安装"
    }
}

# 4. Node.js 检查
Write-Host ""
Write-Host "[4/10] Node.js" -ForegroundColor Magenta
try {
    $nodeVersion = node --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        $nodeMajor = [int]($nodeVersion -replace 'v(\d+)\..*', '$1')
        Write-Check -Name "Node.js 版本" `
            -Passed ($nodeMajor -ge 18) `
            -Message "$nodeVersion" `
            -Fix "升级 Node.js 到 18+ 版本"
        
        if ($nodeMajor -lt 18) {
            Write-Warning "Node.js 版本过低，可能导致兼容性问题"
        }
    } else {
        Write-Check -Name "Node.js" -Passed $false -Message "未安装" -Fix "运行安装脚本或手动安装：https://nodejs.org/"
    }
} catch {
    Write-Check -Name "Node.js" -Passed $false -Message "未安装" -Fix "运行安装脚本或手动安装：https://nodejs.org/"
}

# 5. pnpm 检查
Write-Host ""
Write-Host "[5/10] pnpm" -ForegroundColor Magenta
try {
    $pnpmVersion = pnpm --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Check -Name "pnpm 版本" -Passed $true -Message "$pnpmVersion"
    } else {
        Write-Check -Name "pnpm" -Passed $false -Message "未安装" -Fix "安装脚本会自动安装"
    }
} catch {
    Write-Check -Name "pnpm" -Passed $false -Message "未安装" -Fix "安装脚本会自动安装"
}

# 6. Git 检查（可选）
Write-Host ""
Write-Host "[6/10] Git（可选）" -ForegroundColor Magenta
try {
    $gitVersion = git --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Check -Name "Git 版本" -Passed $true -Message "$gitVersion"
    } else {
        Write-Check -Name "Git" -Passed $true -Message "未安装（可选）" -Fix "如需版本控制可安装：https://git-scm.com/"
    }
} catch {
    Write-Check -Name "Git" -Passed $true -Message "未安装（可选）"
}

# 7. 网络连接检查
Write-Host ""
Write-Host "[7/10] 网络连接" -ForegroundColor Magenta
$testUrls = @(
    @{ Name = "百度"; Url = "https://www.baidu.com" },
    @{ Name = "npm 官方"; Url = "https://registry.npmjs.org/" },
    @{ Name = "淘宝镜像"; Url = "https://registry.npmmirror.com/" }
)

foreach ($test in $testUrls) {
    try {
        $response = Invoke-WebRequest -Uri $test.Url -TimeoutSec 5 -UseBasicParsing
        $passed = $response.StatusCode -eq 200
        Write-Check -Name "$($test.Name) 连接" `
            -Passed $passed `
            -Message (if ($passed) { "正常" } else { "失败" })
    } catch {
        Write-Check -Name "$($test.Name) 连接" -Passed $false -Message "无法连接"
    }
}

# 8. PowerShell 版本检查
Write-Host ""
Write-Host "[8/10] PowerShell" -ForegroundColor Magenta
$psVersion = $PSVersionTable.PSVersion.Major
Write-Check -Name "PowerShell 版本" `
    -Passed ($psVersion -ge 5) `
    -Message "$($PSVersionTable.PSVersion.ToString())" `
    -Fix "建议升级到 PowerShell 5.1 或更高版本"

# 9. 管理员权限检查
Write-Host ""
Write-Host "[9/10] 权限" -ForegroundColor Magenta
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
Write-Check -Name "管理员权限" `
    -Passed $isAdmin `
    -Message (if ($isAdmin) { "已管理员身份运行" } else { "普通用户权限" }) `
    -Fix "右键以管理员身份运行安装脚本"

if (-not $isAdmin) {
    Write-Warning "非管理员权限可能导致安装失败"
}

# 10. 杀毒软件检查
Write-Host ""
Write-Host "[10/10] 安全软件" -ForegroundColor Magenta
$securityCenter = Get-WmiObject -Namespace "root\SecurityCenter2" -Class "AntivirusProduct" -ErrorAction SilentlyContinue
if ($securityCenter) {
    $avNames = $securityCenter | ForEach-Object { $_.displayName } -join ", "
    Write-Check -Name "杀毒软件" -Passed $true -Message "检测到：$avNames"
    Write-Warning "如安装失败，请临时关闭杀毒软件或添加白名单"
} else {
    Write-Check -Name "杀毒软件" -Passed $true -Message "未检测到"
}

# 总结
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  检查结果" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "通过：$($Results.Passed)" -ForegroundColor Green
Write-Host "失败：$($Results.Failed)" -ForegroundColor Red
Write-Host "警告：$($Results.Warnings)" -ForegroundColor Yellow
Write-Host ""

if ($Results.Failed -eq 0) {
    Write-Host "✓ 系统环境满足要求，可以安装 OpenClaw" -ForegroundColor Green
    Write-Host ""
    Write-Host "下一步：" -ForegroundColor Cyan
    Write-Host "  1. 运行安装脚本：.\install-openclaw-enhanced.ps1" -ForegroundColor White
    Write-Host "  2. 或使用参数：.\install-openclaw-enhanced.ps1 -Mirror cnpm" -ForegroundColor White
} else {
    Write-Host "✗ 存在未满足的要求，请先修复后再安装" -ForegroundColor Red
    Write-Host ""
    Write-Host "建议：" -ForegroundColor Cyan
    foreach ($check in $Results.Checks) {
        if (-not $check.Passed -and $check.Fix) {
            Write-Host "  • $($check.Name): $($check.Fix)" -ForegroundColor Yellow
        }
    }
}

Write-Host ""

# 输出到文件（可选）
if ($OutputFile) {
    $Results | ConvertTo-Json -Depth 3 | Out-File -FilePath $OutputFile -Encoding utf8
    Write-Host "检查结果已保存到：$OutputFile" -ForegroundColor Gray
}

if ($Results.Failed -gt 0) {
    pause
}
