@echo off
chcp 65001 >nul
title OpenClaw 快速启动

:: OpenClaw 快速启动脚本
:: 双击即可启动 OpenClaw

set "INSTALL_DIR=%USERPROFILE%\.openclaw"

:: 检查是否已安装
if not exist "%INSTALL_DIR%\node_modules\openclaw" (
    echo [错误] 未检测到 OpenClaw 安装
    echo.
    echo 请先运行安装脚本：install-openclaw.bat
    echo.
    pause
    exit /b 1
)

:: 启动 OpenClaw
cd /d "%INSTALL_DIR%"
echo ======================================
echo   OpenClaw 启动中...
echo ======================================
echo.
call openclaw

if %errorlevel% neq 0 (
    echo.
    echo [错误] OpenClaw 启动失败
    echo.
    echo 可能的原因：
    echo   1. 网关未启动
    echo   2. 配置不完整
    echo.
    echo 解决方法：
    echo   1. 运行：openclaw gateway start
    echo   2. 运行：openclaw configure
    echo.
    pause
)
