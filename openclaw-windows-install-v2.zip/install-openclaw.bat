@echo off
chcp 65001 >nul
title OpenClaw Windows 一键安装

:: OpenClaw Windows 一键安装脚本 (批处理版本)
:: 使用方法：双击运行此文件

echo.
echo ======================================
echo   OpenClaw 一键安装脚本 (Windows 版)
echo ======================================
echo.

:: 检查管理员权限
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [警告] 建议以管理员身份运行
    echo.
    set /p continue="是否继续？(y/n): "
    if /i not "%continue%"=="y" (
        echo 安装已取消
        pause
        exit /b 0
    )
)

:: 步骤 1: 检查 Node.js
echo [1/5] 检查 Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Node.js 未安装，正在通过 winget 安装...
    winget install OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements
    if %errorlevel% neq 0 (
        echo [错误] Node.js 安装失败
        echo 请手动安装：https://nodejs.org/
        pause
        exit /b 1
    )
    :: 刷新环境变量
    set "PATH=%PATH%;C:\Program Files\nodejs"
) else (
    for /f "delims=" %%i in ('node --version') do set NODE_VERSION=%%i
    echo ✓ Node.js 已安装：%NODE_VERSION%
)
echo.

:: 步骤 2: 检查 pnpm
echo [2/5] 检查 pnpm...
pnpm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo 正在安装 pnpm...
    call npm install -g pnpm
    if %errorlevel% neq 0 (
        echo [错误] pnpm 安装失败
        pause
        exit /b 1
    )
) else (
    for /f "delims=" %%i in ('pnpm --version') do set PNPM_VERSION=%%i
    echo ✓ pnpm 已安装：%PNPM_VERSION%
)
echo.

:: 步骤 3: 创建安装目录
echo [3/5] 创建安装目录...
set "INSTALL_DIR=%USERPROFILE%\.openclaw"
if not exist "%INSTALL_DIR%" (
    mkdir "%INSTALL_DIR%"
    echo ✓ 目录已创建：%INSTALL_DIR%
) else (
    echo ✓ 目录已存在：%INSTALL_DIR%
)
echo.

:: 步骤 4: 安装 OpenClaw
echo [4/5] 安装 OpenClaw...
cd /d "%INSTALL_DIR%"

:: 检查是否已安装
if exist "%INSTALL_DIR%\node_modules\openclaw" (
    echo [提示] 检测到已安装的 OpenClaw
    echo.
    echo 选择操作：
    echo   1 - 更新
    echo   2 - 重新安装
    echo   3 - 取消
    echo.
    set /p action="请输入选项 (1/2/3): "
    
    if "%action%"=="1" (
        echo 正在更新 OpenClaw...
        call pnpm update openclaw
    ) else if "%action%"=="2" (
        echo 正在重新安装 OpenClaw...
        rmdir /s /q "%INSTALL_DIR%\node_modules"
        call pnpm create openclaw@latest .
    ) else (
        echo 安装已取消
        pause
        exit /b 0
    )
) else (
    call pnpm create openclaw@latest .
)

if %errorlevel% neq 0 (
    echo [错误] OpenClaw 安装失败
    pause
    exit /b 1
)
echo ✓ OpenClaw 安装完成
echo.

:: 步骤 5: 添加到 PATH（当前会话）
set "PATH=%PATH%;%INSTALL_DIR%\node_modules\.bin"
echo [提示] 环境变量已配置（当前会话）
echo.

:: 完成
echo ======================================
echo   安装完成！
echo ======================================
echo.
echo 🎉 OpenClaw 已成功安装！
echo.
echo 📍 安装位置：%INSTALL_DIR%
echo.
echo 下一步：
echo   1. 验证安装：openclaw --version
echo   2. 配置向导：openclaw configure
echo   3. 启动网关：openclaw gateway start
echo.
echo 📚 资源：
echo   - 文档：https://docs.openclaw.ai
echo   - 技能市场：https://clawhub.ai
echo   - 社区：https://discord.gg/clawd
echo.

:: 询问是否配置
set /p configure="是否现在运行配置向导？(y/n): "
if /i "%configure%"=="y" (
    echo 正在启动配置向导...
    call openclaw configure
)

:: 询问是否启动
set /p launch="是否现在启动 OpenClaw？(y/n): "
if /i "%launch%"=="y" (
    echo 正在启动 OpenClaw...
    call openclaw
)

echo.
echo ✓ 祝你使用愉快！
echo.
pause
