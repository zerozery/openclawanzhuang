# OpenClaw Windows 一键安装脚本（增强版）
# 支持环境检测、依赖检查、配置备份、网络优化

param(
    [switch]$Help,
    [switch]$SkipNode,
    [switch]$SkipCheck,
    [switch]$Backup,
    [string]$InstallPath,
    [string]$Mirror = "cnpm"  # npm, cnpm, tencent, taobao
)

# 帮助信息
if ($Help) {
    Write-Host @"
OpenClaw Windows 一键安装脚本（增强版）

用法:
  .\install-openclaw.ps1 [-Help] [-SkipNode] [-SkipCheck] [-Backup] [-InstallPath <路径>] [-Mirror <镜像>]

参数:
  -Help        显示此帮助信息
  -SkipNode    跳过 Node.js 安装（已手动安装时使用）
  -SkipCheck   跳过环境检查（不推荐）
  -Backup      备份现有配置
  -InstallPath 自定义安装路径（默认：%USERPROFILE%\.openclaw）
  -Mirror      npm 镜像源：npm(官方), cnpm(淘宝), tencent(腾讯), taobao(阿里)

示例:
  .\install-openclaw.ps1                           # 默认安装
  .\install-openclaw.ps1 -SkipNode                 # 跳过 Node.js 安装
  .\install-openclaw.ps1 -Mirror cnpm              # 使用淘宝镜像
  .\install-openclaw.ps1 -InstallPath "D:\OpenClaw"  # 自定义路径
  .\install-openclaw.ps1 -Backup                   # 备份现有配置

"@ -ForegroundColor Cyan
    exit 0
}

# ========== 配置 ==========
$Config = @{
    MinNodeVersion = 18
    MinPnpmVersion = 8
    RequiredDiskSpaceMB = 500
    TimeoutSeconds = 300
    RetryCount = 3
}

# 颜色主题
$Theme = @{
    Title = 'Cyan'
    Success = 'Green'
    Warning = 'Yellow'
    Error = 'Red'
    Info = 'White'
    Step = 'Magenta'
}

# ========== 辅助函数 ==========

function Write-Title {
    param([string]$Text)
    Write-Host ""
    Write-Host "========================================" -ForegroundColor $Theme.Title
    Write-Host "  $Text" -ForegroundColor $Theme.Title
    Write-Host "========================================" -ForegroundColor $Theme.Title
    Write-Host ""
}

function Write-Step {
    param([string]$Text, [int]$Index = 0, [int]$Total = 0)
    Write-Host ""
    if ($Index -gt 0 -and $Total -gt 0) {
        Write-Host "[$Index/$Total] $Text" -ForegroundColor $Theme.Step
    } else {
        Write-Host "[$Text]" -ForegroundColor $Theme.Step
    }
}

function Write-Success {
    param([string]$Text)
    Write-Host "✓ $Text" -ForegroundColor $Theme.Success
}

function Write-ErrorMsg {
    param([string]$Text)
    Write-Host "✗ $Text" -ForegroundColor $Theme.Error
}

function Write-Info {
    param([string]$Text)
    Write-Host "ℹ $Text" -ForegroundColor $Theme.Info
}

function Test-Admin {
    $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    return $isAdmin
}

function Test-Internet {
    try {
        $response = Invoke-WebRequest -Uri "https://www.baidu.com" -TimeoutSec 5 -UseBasicParsing
        return $response.StatusCode -eq 200
    } catch {
        return $false
    }
}

function Get-DiskSpace {
    param([string]$Drive = "C")
    $disk = Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='$Drive:'" | Select-Object Size,FreeSpace
    $freeMB = [math]::Round($disk.FreeSpace / 1MB, 2)
    $totalMB = [math]::Round($disk.Size / 1MB, 2)
    return @{ Free = $freeMB; Total = $totalMB }
}

function Get-NpmRegistry {
    $registry = npm config get registry 2>$null
    return $registry
}

function Set-NpmRegistry {
    param([string]$Mirror = "cnpm")
    $registries = @{
        npm = "https://registry.npmjs.org/"
        cnpm = "https://registry.npmmirror.com/"
        tencent = "https://mirrors.cloud.tencent.com/npm/"
        taobao = "https://registry.npmmirror.com/"
    }
    
    $url = $registries[$Mirror]
    if ($url) {
        npm config set registry $url
        Write-Success "npm 镜像已设置为：$Mirror ($url)"
    }
}

function Backup-Config {
    param([string]$SourcePath)
    if (!(Test-Path $SourcePath)) {
        Write-Info "无现有配置需要备份"
        return $false
    }
    
    $backupDir = "$SourcePath\backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    
    $filesToBackup = @('.env', 'config.json', 'openclaw.config.json', 'MEMORY.md', 'USER.md', 'SOUL.md')
    $backedUp = $false
    
    foreach ($file in $filesToBackup) {
        $src = Join-Path $SourcePath $file
        if (Test-Path $src) {
            Copy-Item $src -Destination $backupDir -Force
            $backedUp = $true
        }
    }
    
    if ($backedUp) {
        Write-Success "配置已备份到：$backupDir"
        return $true
    } else {
        Remove-Item $backupDir -Force
        return $false
    }
}

function Install-NodeJS {
    Write-Info "正在通过 winget 安装 Node.js LTS..."
    try {
        winget install OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements --silent
        return $true
    } catch {
        Write-ErrorMsg "winget 安装失败，尝试直接下载..."
        try {
            $installerUrl = "https://nodejs.org/dist/latest-v20.x/node-v20.11.0-x64.msi"
            $installerPath = "$env:TEMP\nodejs-installer.msi"
            Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -UseBasicParsing
            Start-Process msiexec.exe -Wait -ArgumentList "/i $installerPath /quiet"
            Remove-Item $installerPath -Force
            return $true
        } catch {
            return $false
        }
    }
}

function Wait-ForCommand {
    param([string]$Command, [int]$Timeout = 30)
    $startTime = Get-Date
    while ((Get-Date) -lt $startTime.AddSeconds($Timeout)) {
        try {
            $result = Invoke-Expression "$Command 2>&1"
            if ($LASTEXITCODE -eq 0) {
                return $true
            }
        } catch {}
        Start-Sleep -Seconds 2
    }
    return $false
}

# ========== 主安装流程 ==========

Write-Title "OpenClaw 一键安装脚本 (Windows 增强版)"

# 检查管理员权限
$isAdmin = Test-Admin
if (-not $isAdmin) {
    Write-Warning "建议以管理员身份运行，否则可能安装失败"
    $continue = Read-Host "是否继续？(y/n)"
    if ($continue -ne "y" -and $continue -ne "Y") {
        Write-Host "安装已取消" -ForegroundColor $Theme.Warning
        exit 0
    }
}

# 设置安装路径
if (-not $InstallPath) {
    $InstallPath = "$env:USERPROFILE\.openclaw"
}

# ========== 步骤 1: 系统环境检查 ==========
Write-Step "系统环境检查" 1 7

# 1.1 检查操作系统版本
$osVersion = [Environment]::OSVersion.Version
Write-Info "操作系统：Windows $($osVersion.Major).$($osVersion.Minor) (Build $($osVersion.Build))"
if ($osVersion.Major -lt 10) {
    Write-Warning "Windows 版本过低，建议 Windows 10 或更高版本"
}

# 1.2 检查网络连接
Write-Info "检查网络连接..."
if (Test-Internet) {
    Write-Success "网络连接正常"
} else {
    Write-ErrorMsg "网络连接失败，请检查网络"
    $continue = Read-Host "是否继续？(y/n)"
    if ($continue -ne "y") { exit 1 }
}

# 1.3 检查磁盘空间
Write-Info "检查磁盘空间..."
$diskInfo = Get-DiskSpace (Split-Path $InstallPath -Qualifier).TrimEnd(':')
Write-Info "可用空间：$($diskInfo.Free) MB / 总计：$($diskInfo.Total) MB"
if ($diskInfo.Free -lt $Config.MinDiskSpaceMB) {
    Write-ErrorMsg "磁盘空间不足（需要至少 $($Config.MinDiskSpaceMB) MB）"
    exit 1
} else {
    Write-Success "磁盘空间充足"
}

# 1.4 备份现有配置
if ($Backup -or (Test-Path "$InstallPath\.env")) {
    Write-Info "检测到低估配置，正在备份..."
    Backup-Config -SourcePath $InstallPath
}

# ========== 步骤 2: 检查 Node.js ==========
Write-Step "检查 Node.js" 2 7

$nodeInstalled = $false
try {
    $nodeVersion = node --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        $nodeInstalled = $true
        $nodeMajor = [int]($nodeVersion -replace 'v(\d+)\..*', '$1')
        Write-Success "Node.js 已安装：$nodeVersion"
        
        if ($nodeMajor -lt $Config.MinNodeVersion) {
            Write-Warning "Node.js 版本过低（需要 $($Config.MinNodeVersion)+，当前：$nodeMajor）"
            if (-not $SkipNode) {
                $update = Read-Host "是否更新 Node.js？(y/n)"
                if ($update -eq "y" -or $update -eq "Y") {
                    $nodeInstalled = $false
                }
            }
        }
    }
} catch {
    $nodeInstalled = $false
}

if (-not $nodeInstalled) {
    if ($SkipNode) {
        Write-ErrorMsg "未检测到 Node.js 且跳过了安装"
        exit 1
    }
    
    if (Install-NodeJS) {
        Write-Success "Node.js 安装完成"
        
        # 刷新环境变量
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        
        # 等待 Node.js 可用
        if (Wait-ForCommand "node --version" -Timeout 10) {
            Write-Success "Node.js 已就绪"
        } else {
            Write-Warning "Node.js 可能需要重启终端才能使用"
        }
    } else {
        Write-ErrorMsg "Node.js 安装失败"
        Write-Host "请手动安装：https://nodejs.org/" -ForegroundColor $Theme.Warning
        pause
        exit 1
    }
}

# ========== 步骤 3: 配置 npm 镜像 ==========
Write-Step "配置 npm 镜像" 3 7

$currentRegistry = Get-NpmRegistry
Write-Info "当前 npm 镜像：$currentRegistry"

if ($Mirror -ne "npm") {
    Set-NpmRegistry -Mirror $Mirror
} else {
    Write-Info "使用官方 npm 镜像"
}

# ========== 步骤 4: 检查 pnpm ==========
Write-Step "检查 pnpm" 4 7

$pnpmInstalled = $false
try {
    $pnpmVersion = pnpm --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        $pnpmInstalled = $true
        $pnpmMajor = [int]($pnpmVersion -replace '(\d+)\..*', '$1')
        Write-Success "pnpm 已安装：$pnpmVersion"
        
        if ($pnpmMajor -lt $Config.MinPnpmVersion) {
            Write-Warning "pnpm 版本过低（需要 $($Config.MinPnpmVersion)+）"
            $update = Read-Host "是否更新 pnpm？(y/n)"
            if ($update -eq "y" -or $update -eq "Y") {
                $pnpmInstalled = $false
            }
        }
    }
} catch {
    $pnpmInstalled = $false
}

if (-not $pnpmInstalled) {
    Write-Info "正在安装 pnpm..."
    try {
        npm install -g pnpm
        Write-Success "pnpm 安装完成"
        
        # 刷新环境变量
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
    } catch {
        Write-ErrorMsg "pnpm 安装失败"
        Write-Host "请手动运行：npm install -g pnpm" -ForegroundColor $Theme.Warning
        pause
        exit 1
    }
}

# ========== 步骤 5: 检查 Git（可选） ==========
Write-Step "检查 Git（可选）" 5 7

$gitInstalled = $false
try {
    $gitVersion = git --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        $gitInstalled = $true
        Write-Success "Git 已安装：$gitVersion"
    }
} catch {
    Write-Info "Git 未安装（可选，用于版本控制）"
}

if (-not $gitInstalled) {
    $installGit = Read-Host "是否安装 Git？(y/n)"
    if ($installGit -eq "y" -or $installGit -eq "Y") {
        try {
            winget install Git.Git -e --accept-package-agreements --accept-source-agreements --silent
            Write-Success "Git 安装完成"
            $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        } catch {
            Write-Warning "Git 安装失败，可稍后手动安装：https://git-scm.com/"
        }
    }
}

# ========== 步骤 6: 创建安装目录 ==========
Write-Step "创建安装目录" 6 7

if (!(Test-Path $InstallPath)) {
    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    Write-Success "目录已创建：$InstallPath"
} else {
    Write-Success "目录已存在：$InstallPath"
}

# ========== 步骤 7: 安装 OpenClaw ==========
Write-Step "安装 OpenClaw" 7 7

Set-Location $InstallPath

# 检查是否已安装
if (Test-Path "$InstallPath\node_modules\openclaw") {
    Write-Host "检测到已安装的 OpenClaw" -ForegroundColor $Theme.Warning
    $action = Read-Host "选择操作：1-更新 2-重新安装 3-取消 (1/2/3)"
    
    if ($action -eq "1") {
        Write-Host "正在更新 OpenClaw..." -ForegroundColor $Theme.Warning
        pnpm update openclaw
        Write-Success "OpenClaw 更新完成"
    } elseif ($action -eq "2") {
        Write-Host "正在重新安装 OpenClaw..." -ForegroundColor $Theme.Warning
        Remove-Item -Path "$InstallPath\node_modules" -Recurse -Force
        pnpm create openclaw@latest .
        Write-Success "OpenClaw 重新安装完成"
    } else {
        Write-Host "安装已取消" -ForegroundColor $Theme.Warning
        exit 0
    }
} else {
    try {
        Write-Info "正在安装 OpenClaw（可能需要几分钟）..."
        pnpm create openclaw@latest .
        Write-Success "OpenClaw 安装完成"
    } catch {
        Write-ErrorMsg "OpenClaw 安装失败"
        Write-Host "请检查网络连接或手动安装" -ForegroundColor $Theme.Warning
        pause
        exit 1
    }
}

# ========== 步骤 8: 配置环境变量 ==========
Write-Step "配置环境变量" 8 9

$envPath = [Environment]::GetEnvironmentVariable("PATH", "User")
$nodeModulesBin = "$InstallPath\node_modules\.bin"

if ($envPath -notlike "*$nodeModulesBin*") {
    [Environment]::SetEnvironmentVariable("PATH", $envPath + ";$nodeModulesBin", "User")
    Write-Success "环境变量已配置"
    
    # 刷新当前会话
    $env:Path += ";$nodeModulesBin"
} else {
    Write-Success "环境变量已存在"
}

# ========== 步骤 9: 创建快捷方式 ==========
Write-Step "创建快捷方式" 9 9

$createShortcut = Read-Host "是否创建桌面快捷方式？(y/n)"
if ($createShortcut -eq "y" -or $createShortcut -eq "Y") {
    try {
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\OpenClaw.lnk")
        $Shortcut.TargetPath = "powershell.exe"
        $Shortcut.Arguments = "-NoExit -Command `"cd '$InstallPath'; openclaw`""
        $Shortcut.WorkingDirectory = $InstallPath
        $Shortcut.IconLocation = "shell32.dll,13"
        $Shortcut.Description = "OpenClaw - AI 助手框架"
        $Shortcut.Save()
        Write-Success "桌面快捷方式已创建"
    } catch {
        Write-Warning "快捷方式创建失败（可手动创建）"
    }
}

# ========== 完成 ==========
Write-Title "安装完成！"

Write-Host @"
🎉 OpenClaw 已成功安装！

📍 安装位置：$InstallPath

📋 快速开始：
  1. 验证安装：openclaw --version
  2. 配置向导：openclaw configure
  3. 启动网关：openclaw gateway start
  4. 或直接运行：openclaw

📚 资源：
  - 文档：https://docs.openclaw.ai
  - 技能市场：https://clawhub.ai
  - 社区：https://discord.gg/clawd
  - GitHub：https://github.com/openclaw/openclaw

🔧 高级选项：
  - 查看日志：openclaw logs
  - 重启网关：openclaw gateway restart
  - 停止服务：openclaw gateway stop
  - 安装技能：openclaw skills install <skill-name>

"@ -ForegroundColor $Theme.Info

# 询问是否现在配置
$configure = Read-Host "是否现在运行配置向导？(y/n)"
if ($configure -eq "y" -or $configure -eq "Y") {
    Write-Host "正在启动配置向导..." -ForegroundColor $Theme.Warning
    Set-Location $InstallPath
    openclaw configure
}

# 询问是否现在启动
$launch = Read-Host "是否现在启动 OpenClaw？(y/n)"
if ($launch -eq "y" -or $launch -eq "Y") {
    Write-Host "正在启动 OpenClaw..." -ForegroundColor $Theme.Warning
    Set-Location $InstallPath
    openclaw
}

Write-Host ""
Write-Success "祝你使用愉快！🌿"
Write-Host ""
pause
