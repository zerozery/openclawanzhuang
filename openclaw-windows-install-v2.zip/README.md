# OpenClaw Windows 安装脚本（增强版）

本目录包含 OpenClaw 的 Windows 一键安装脚本，支持环境检测、依赖管理、配置备份等功能。

## 📦 文件列表

| 文件 | 说明 | 推荐使用 |
|------|------|---------|
| `install-openclaw-enhanced.ps1` | PowerShell 增强版安装脚本 | ⭐ 推荐 |
| `install-openclaw-enhanced.bat` | 批处理增强版安装脚本 | 推荐 |
| `check-environment.ps1` | 环境检查脚本 | 安装前运行 |
| `install-openclaw.ps1` | PowerShell 标准版（旧版） | 备用 |
| `install-openclaw.bat` | 批处理标准版（旧版） | 备用 |
| `start-openclaw.bat` | 快速启动脚本 | - |
| `INSTALL_GUIDE.md` | 详细安装指南 | 📖 必读 |
| `QUICKSTART.md` | 快速入门指南 | - |
| `README.md` | 本文档 | - |

## 🚀 快速开始

### 方式 1: PowerShell（推荐）

```powershell
# 1. 打开 PowerShell（右键以管理员身份运行）
# 2. 切换到脚本目录
cd 脚本所在路径

# 3. 运行安装脚本
.\install-openclaw-enhanced.ps1
```

### 方式 2: 批处理

```cmd
:: 双击运行或在 CMD 中执行
install-openclaw-enhanced.bat
```

### 方式 3: 高级选项

```powershell
# 使用淘宝镜像加速（中国大陆推荐）
.\install-openclaw-enhanced.ps1 -Mirror cnpm

# 自定义安装路径
.\install-openclaw-enhanced.ps1 -InstallPath "D:\OpenClaw"

# 跳过 Node.js 安装（已手动安装时）
.\install-openclaw-enhanced.ps1 -SkipNode

# 备份现有配置
.\install-openclaw-enhanced.ps1 -Backup

# 查看所有选项
.\install-openclaw-enhanced.ps1 -Help
```

## 📋 安装流程

### 1. 环境检查（可选但推荐）

在安装前，先运行环境检查脚本：

```powershell
.\check-environment.ps1
```

检查项目：
- ✓ 操作系统版本
- ✓ 内存和磁盘空间
- ✓ Node.js 和 pnpm
- ✓ 网络连接
- ✓ 管理员权限
- ✓ 杀毒软件

### 2. 运行安装脚本

安装脚本会自动完成以下步骤：

1. **系统环境检查** - 检测 Windows 版本、网络、磁盘空间
2. **安装 Node.js** - 如未安装，自动通过 winget 安装
3. **配置 npm 镜像** - 设置为淘宝镜像（加速下载）
4. **安装 pnpm** - 包管理器
5. **安装 Git** - 可选，用于版本控制
6. **创建安装目录** - 默认 `%USERPROFILE%\.openclaw`
7. **安装 OpenClaw** - 主程序
8. **配置环境变量** - 添加 openclaw 命令
9. **创建快捷方式** - 桌面快捷方式（可选）

### 3. 验证安装

```powershell
# 检查版本
openclaw --version

# 配置向导
openclaw configure

# 启动服务
openclaw gateway start
```

## 🔧 高级功能

### 环境检测

- 自动检测系统要求
- 彩色输出和进度提示
- 详细的错误信息和建议

### 依赖管理

- **Node.js**: 自动安装 LTS 版本（18+）
- **pnpm**: 自动安装最新版本
- **Git**: 可选安装

### 网络优化

支持多种 npm 镜像源：

```powershell
# 淘宝镜像（中国大陆推荐）
-Mirror cnpm

# 腾讯镜像
-Mirror tencent

# 官方镜像（海外）
-Mirror npm
```

### 配置保护

- 自动备份现有配置（`.env`, `config.json` 等）
- 支持配置迁移
- 避免数据丢失

### 快捷方式

- 可选创建桌面快捷方式
- 一键启动 OpenClaw
- 自动配置工作目录

## 📖 参数说明

### PowerShell 参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `-Help` | Switch | 显示帮助信息 |
| `-SkipNode` | Switch | 跳过 Node.js 安装 |
| `-SkipCheck` | Switch | 跳过环境检查 |
| `-Backup` | Switch | 备份现有配置 |
| `-InstallPath` | String | 自定义安装路径 |
| `-Mirror` | String | npm 镜像源（npm/cnpm/tencent/taobao） |

### 示例

```powershell
# 默认安装（使用淘宝镜像）
.\install-openclaw-enhanced.ps1

# 自定义所有选项
.\install-openclaw-enhanced.ps1 -InstallPath "D:\OpenClaw" -Mirror tencent -Backup

# 仅更新（已安装情况下）
.\install-openclaw-enhanced.ps1 -SkipNode -SkipCheck
```

## 🐛 故障排查

### 问题 1: 脚本无法运行

**症状**: PowerShell 提示无法运行脚本

**解决方案**:
```powershell
# 修改执行策略
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# 然后重新运行
.\install-openclaw-enhanced.ps1
```

### 问题 2: Node.js 安装失败

**症状**: winget 安装失败

**解决方案**:
1. 手动下载：https://nodejs.org/
2. 使用 `-SkipNode` 参数
3. 确保有管理员权限

### 问题 3: 网络超时

**症状**: pnpm 安装超时

**解决方案**:
```powershell
# 使用淘宝镜像
.\install-openclaw-enhanced.ps1 -Mirror cnpm

# 或手动设置
npm config set registry https://registry.npmmirror.com/
```

### 问题 4: 权限不足

**症状**: 无法写入目录

**解决方案**:
1. 右键以管理员身份运行
2. 更改安装路径到用户目录
3. 检查杀毒软件拦截

## 📚 相关文档

- **安装指南**: [INSTALL_GUIDE.md](INSTALL_GUIDE.md) - 详细安装说明
- **快速入门**: [QUICKSTART.md](QUICKSTART.md) - 快速开始使用
- **官方文档**: https://docs.openclaw.ai
- **GitHub**: https://github.com/openclaw/openclaw

## ✅ 安装后

### 配置

```powershell
# 运行配置向导
openclaw configure

# 配置项：
# - 模型提供商（OpenAI、Claude 等）
# - API 密钥
# - 消息渠道（微信、飞书等）
```

### 安装技能

```powershell
# 查看可用技能
openclaw skills list

# 安装技能
openclaw skills install <skill-name>

# 例如：
openclaw skills install weather
openclaw skills install finance
```

### 启动服务

```powershell
# 启动
openclaw gateway start

# 查看日志
openclaw logs

# 停止
openclaw gateway stop

# 重启
openclaw gateway restart
```

## 🆘 获取帮助

### 官方资源
- **文档**: https://docs.openclaw.ai
- **GitHub**: https://github.com/openclaw/openclaw
- **技能市场**: https://clawhub.ai
- **社区**: https://discord.gg/clawd

### 本地帮助
```powershell
openclaw --help
openclaw <command> --help
```

## 📄 更新日志

### v2.0 (增强版)
- ✅ 新增环境检查脚本
- ✅ 支持多种 npm 镜像源
- ✅ 自动备份现有配置
- ✅ 彩色输出和进度提示
- ✅ 可选安装 Git
- ✅ 创建桌面快捷方式
- ✅ 详细的故障排查指南

### v1.0 (标准版)
- ✅ 基础安装功能
- ✅ Node.js 自动安装
- ✅ pnpm 自动安装

---

**祝你使用愉快！🌿**

如有问题，请提交 Issue 或联系社区。
