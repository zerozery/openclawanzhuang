# OpenClaw Windows 安装指南（增强版）

本文档介绍如何使用增强版安装脚本在 Windows 系统上安装 OpenClaw。

## 📋 系统要求

### 最低配置
- **操作系统**: Windows 10 或更高版本
- **内存**: 4GB RAM（推荐 8GB+）
- **磁盘空间**: 至少 500MB 可用空间
- **网络**: 需要互联网连接（用于下载依赖）

### 推荐配置
- **操作系统**: Windows 11
- **内存**: 8GB RAM 或更高
- **磁盘空间**: 1GB+ 可用空间（用于安装技能和缓存）
- **网络**: 稳定的宽带连接

## 🚀 快速开始

### 方法 1: PowerShell 脚本（推荐）

```powershell
# 1. 下载脚本后，右键以管理员身份运行
# 或在 PowerShell 中执行：
cd 脚本所在目录
.\install-openclaw-enhanced.ps1
```

### 方法 2: 批处理脚本

```cmd
:: 双击运行或在 CMD 中执行
install-openclaw-enhanced.bat
```

### 方法 3: 命令行参数

```powershell
# 使用淘宝镜像加速安装
.\install-openclaw-enhanced.ps1 -Mirror cnpm

# 自定义安装路径
.\install-openclaw-enhanced.ps1 -InstallPath "D:\OpenClaw"

# 跳过 Node.js 安装（已手动安装时）
.\install-openclaw-enhanced.ps1 -SkipNode

# 备份现有配置
.\install-openclaw-enhanced.ps1 -Backup

# 查看帮助
.\install-openclaw-enhanced.ps1 -Help
```

## 📦 安装脚本功能

### 增强版特性

1. **系统环境检测**
   - 检查操作系统版本
   - 检查网络连接
   - 检查磁盘空间
   - 自动修复常见问题

2. **依赖管理**
   - 自动安装 Node.js（如果未安装）
   - 自动安装 pnpm（包管理器）
   - 可选安装 Git（版本控制）
   - 版本检查和升级提示

3. **网络优化**
   - 支持多种 npm 镜像源
   - 自动配置淘宝镜像（中国大陆）
   - 支持超时重试机制

4. **配置保护**
   - 自动备份现有配置
   - 支持配置迁移
   - 避免数据丢失

5. **用户体验**
   - 彩色输出
   - 进度提示
   - 交互式选择
   - 桌面快捷方式创建

## 🔧 安装参数详解

### PowerShell 参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `-Help` | 显示帮助信息 | `.\install-openclaw-enhanced.ps1 -Help` |
| `-SkipNode` | 跳过 Node.js 安装 | `.\install-openclaw-enhanced.ps1 -SkipNode` |
| `-SkipCheck` | 跳过环境检查 | `.\install-openclaw-enhanced.ps1 -SkipCheck` |
| `-Backup` | 备份现有配置 | `.\install-openclaw-enhanced.ps1 -Backup` |
| `-InstallPath` | 自定义安装路径 | `.\install-openclaw-enhanced.ps1 -InstallPath "D:\OpenClaw"` |
| `-Mirror` | npm 镜像源 | `.\install-openclaw-enhanced.ps1 -Mirror cnpm` |

### Mirror 选项

| 镜像 | 说明 | 适用地区 |
|------|------|---------|
| `npm` | 官方 npm 镜像 | 海外 |
| `cnpm` | 淘宝镜像（推荐） | 中国大陆 |
| `tencent` | 腾讯镜像 | 中国大陆 |
| `taobao` | 阿里镜像 | 中国大陆 |

## 📝 安装流程

### 步骤 1: 系统环境检查
- 检查 Windows 版本
- 测试网络连接
- 检查磁盘空间
- 提示备份配置

### 步骤 2: 安装 Node.js
- 自动检测是否已安装
- 检查版本（需要 18+）
- 通过 winget 自动安装
- 或提供手动安装链接

### 步骤 3: 配置 npm 镜像
- 显示当前镜像
- 设置为淘宝镜像（加速下载）
- 验证配置

### 步骤 4: 安装 pnpm
- 检查是否已安装
- 全局安装 pnpm
- 配置环境变量

### 步骤 5: 安装 Git（可选）
- 询问是否安装
- 用于版本控制和技能管理
- 可稍后手动安装

### 步骤 6: 创建安装目录
- 默认：`%USERPROFILE%\.openclaw`
- 可自定义路径
- 备份现有配置

### 步骤 7: 安装 OpenClaw
- 使用 pnpm 创建项目
- 检测已安装版本
- 提供更新/重装选项

### 步骤 8: 配置环境变量
- 添加 openclaw 命令到 PATH
- 当前会话立即可用
- 永久配置系统变量

### 步骤 9: 创建快捷方式
- 询问是否创建桌面快捷方式
- 一键启动 OpenClaw
- 可手动创建

## ✅ 验证安装

安装完成后，打开新的终端窗口验证：

```powershell
# 检查版本
openclaw --version

# 查看帮助
openclaw --help

# 运行配置向导
openclaw configure

# 启动网关
openclaw gateway start

# 查看状态
openclaw gateway status
```

## 🔍 故障排查

### 问题 1: Node.js 安装失败

**症状**: winget 安装失败

**解决方案**:
1. 手动下载安装：https://nodejs.org/
2. 使用 `-SkipNode` 参数跳过自动安装
3. 确保有管理员权限

### 问题 2: 网络超时

**症状**: pnpm 安装超时或失败

**解决方案**:
```powershell
# 使用淘宝镜像
.\install-openclaw-enhanced.ps1 -Mirror cnpm

# 或手动设置
npm config set registry https://registry.npmmirror.com/
```

### 问题 3: 权限不足

**症状**: 无法写入安装目录

**解决方案**:
1. 右键以管理员身份运行脚本
2. 或更改安装路径到用户目录
3. 检查杀毒软件拦截

### 问题 4: 环境变量不生效

**症状**: 新终端中 openclaw 命令不存在

**解决方案**:
1. 关闭并重新打开终端
2. 或手动添加 PATH：
   ```
   %USERPROFILE%\.openclaw\node_modules\.bin
   ```
3. 重启计算机

### 问题 5: 磁盘空间不足

**症状**: 安装过程中提示空间不足

**解决方案**:
1. 清理磁盘空间
2. 选择其他磁盘安装
3. 使用 `-InstallPath` 指定到大容量磁盘

## 📚 后续步骤

### 初次配置

```powershell
# 运行配置向导
openclaw configure

# 配置项包括：
# - 模型提供商（OpenAI、Claude 等）
# - API 密钥
# - 消息渠道（微信、飞书等）
# - 其他个性化设置
```

### 安装技能

```powershell
# 查看可用技能
openclaw skills list

# 安装技能
openclaw skills install <skill-name>

# 例如：
openclaw skills install weather
openclaw skills install finance
```

### 启动服务

```powershell
# 启动网关
openclaw gateway start

# 查看日志
openclaw logs

# 停止服务
openclaw gateway stop

# 重启服务
openclaw gateway restart
```

## 🆘 获取帮助

### 官方资源
- **文档**: https://docs.openclaw.ai
- **GitHub**: https://github.com/openclaw/openclaw
- **技能市场**: https://clawhub.ai
- **社区**: https://discord.gg/clawd

### 本地帮助
```powershell
openclaw --help
openclaw <command> --help
```

## 📄 许可证

OpenClaw 遵循 MIT 许可证。详细信息请参阅项目仓库。

---

**祝你使用愉快！🌿**

如有问题，请提交 Issue 或联系社区。
