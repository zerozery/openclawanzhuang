# 🪟 OpenClaw Windows 一键部署工具

> 让 OpenClaw 安装像普通软件一样简单  
> 适用：Windows 10/11  
> 版本：v1.0 (2026-03-11)

---

## 📦 包含文件

```
windows-install/
├── install-openclaw.ps1      # PowerShell 安装脚本（推荐）
├── install-openclaw.bat      # 批处理安装脚本（备用）
├── start-openclaw.bat        # 快速启动脚本
└── README.md                 # 使用说明（本文件）
```

---

## 🚀 快速开始

### 方法 1：PowerShell 脚本（推荐）

**步骤**：

1. **下载脚本**
   - 将整个 `windows-install` 文件夹下载到电脑
   - 或者只下载 `install-openclaw.ps1`

2. **运行安装**
   - 右键 `install-openclaw.ps1`
   - 选择"使用 PowerShell 运行"
   - 或者在 PowerShell 中执行：
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   .\install-openclaw.ps1
   ```

3. **等待完成**
   - 脚本会自动安装 Node.js、pnpm、OpenClaw
   - 配置环境变量
   - 创建桌面快捷方式

4. **验证安装**
   ```powershell
   openclaw --version
   ```

---

### 方法 2：批处理脚本（备用）

**步骤**：

1. **下载脚本**
   - 下载 `install-openclaw.bat` 和 `start-openclaw.bat`

2. **运行安装**
   - 双击 `install-openclaw.bat`
   - 按提示操作

3. **启动 OpenClaw**
   - 双击 `start-openclaw.bat`
   - 或者运行 `openclaw`

---

## ⚙️ 安装选项

### PowerShell 高级选项

```powershell
# 显示帮助
.\install-openclaw.ps1 -Help

# 跳过 Node.js 安装（已手动安装时）
.\install-openclaw.ps1 -SkipNode

# 自定义安装路径
.\install-openclaw.ps1 -InstallPath "D:\OpenClaw"
```

---

## 📋 安装后配置

### 1. 运行配置向导

```powershell
openclaw configure
```

### 2. 配置飞书（可选）

编辑配置文件：
```powershell
notepad $env:USERPROFILE\.openclaw\openclaw.json
```

添加配置：
```json
{
  "feishu": {
    "app_id": "cli_xxx",
    "app_secret": "xxx"
  }
}
```

### 3. 启动网关

```powershell
openclaw gateway start
```

### 4. 验证

```powershell
openclaw --help
```

---

## 🔧 常见问题

### Q1: PowerShell 执行策略错误

**错误信息**：
```
无法加载文件，因为在此系统上禁止运行脚本
```

**解决方法**：
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

### Q2: Node.js 安装失败

**原因**：winget 不可用或网络问题

**解决方法**：
1. 手动下载 Node.js：https://nodejs.org/
2. 安装后重新运行脚本，加上 `-SkipNode` 参数

---

### Q3: pnpm 命令找不到

**解决方法**：
```powershell
# 重新安装
npm install -g pnpm

# 刷新环境变量
refreshenv

# 或重启终端
```

---

### Q4: 权限错误

**错误信息**：
```
Access to the path is denied
```

**解决方法**：
1. 右键脚本 → 以管理员身份运行
2. 或者给安装目录添加权限：
   ```powershell
   icacls "$env:USERPROFILE\.openclaw" /grant Users:F
   ```

---

### Q5: 安装后命令无效

**原因**：环境变量未刷新

**解决方法**：
1. 重启终端或 PowerShell
2. 或者运行：
   ```powershell
   refreshenv
   ```
3. 或者手动添加 PATH：
   ```powershell
   $env:Path += ";$env:USERPROFILE\.openclaw\node_modules\.bin"
   ```

---

### Q6: 网关启动失败

**错误信息**：
```
Cannot start gateway
```

**解决方法**：
1. 检查配置：
   ```powershell
   openclaw configure
   ```
2. 查看日志：
   ```powershell
   Get-Content "$env:USERPROFILE\.openclaw\logs\gateway.log"
   ```
3. 重启网关：
   ```powershell
   openclaw gateway restart
   ```

---

## 📊 系统要求

| 要求 | 最低配置 | 推荐配置 |
|------|---------|---------|
| 系统 | Windows 10 | Windows 11 |
| 内存 | 4GB | 8GB+ |
| 磁盘 | 1GB | 5GB+ |
| Node.js | 18+ | 20+ LTS |
| 网络 | 需要 | 需要 |

---

## 🎯 卸载方法

### 完全卸载

```powershell
# 1. 停止网关
openclaw gateway stop

# 2. 删除安装目录
Remove-Item -Path "$env:USERPROFILE\.openclaw" -Recurse -Force

# 3. 删除全局包
pnpm remove -g openclaw

# 4. 清理环境变量（可选）
# 编辑系统环境变量，删除 OpenClaw 相关路径
```

---

## 📦 离线安装（高级）

### 创建离线包

```powershell
# 在有网络的电脑上
$packageDir = "$env:TEMP\openclaw-offline"
New-Item -ItemType Directory -Path $packageDir | Out-Null

# 1. 下载 Node.js
Invoke-WebRequest -Uri "https://nodejs.org/dist/v22.22.0/node-v22.22.0-x64.msi" -OutFile "$packageDir\node-installer.msi"

# 2. 复制安装脚本
Copy-Item "install-openclaw.ps1" -Destination "$packageDir\"
Copy-Item "start-openclaw.bat" -Destination "$packageDir\"

# 3. 创建说明文档
@"
OpenClaw 离线安装包
==================

1. 安装 Node.js: node-installer.msi
2. 重启电脑
3. 运行：install-openclaw.ps1 -SkipNode
4. 启动：start-openclaw.bat
"@ | Out-File -FilePath "$packageDir\README.txt" -Encoding UTF8

# 4. 压缩
Compress-Archive -Path "$packageDir\*" -DestinationPath "OpenClaw-Offline.zip" -Force
```

### 使用离线包

1. 解压 `OpenClaw-Offline.zip`
2. 安装 Node.js
3. 重启电脑
4. 运行 `install-openclaw.ps1 -SkipNode`

---

## 🆘 获取帮助

### 官方资源

- 📚 文档：https://docs.openclaw.ai
- 💬 社区：https://discord.gg/clawd
- 🐙 GitHub：https://github.com/openclaw/openclaw
- 🛒 技能市场：https://clawhub.ai

### 本地帮助

```powershell
# 查看帮助
openclaw --help

# 查看版本
openclaw --version

# 查看状态
openclaw status
```

---

## 📝 更新日志

### v1.0 (2026-03-11)

**新增**：
- ✅ PowerShell 一键安装脚本
- ✅ 批处理安装脚本（备用）
- ✅ 快速启动脚本
- ✅ 自动检测安装 Node.js/pnpm
- ✅ 自动配置环境变量
- ✅ 创建桌面快捷方式
- ✅ 安装后配置向导
- ✅ 完整的错误处理

**已知问题**：
- ⚠️ 离线安装需要手动准备
- ⚠️ winget 在某些系统上不可用

---

## 🤝 贡献

遇到问题或有改进建议？欢迎反馈：

1. GitHub Issues: https://github.com/openclaw/openclaw/issues
2. Discord 社区：https://discord.gg/clawd
3. 邮件：support@openclaw.ai

---

## 📄 许可证

MIT License - 详见 OpenClaw 主项目

---

*让每个人都能轻松使用 OpenClaw* 🌿

**祝你使用愉快！**
