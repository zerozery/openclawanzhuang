# 🛠️ OpenClaw 运维手册

_安全操作指南，避免"挂掉"_

---

## 📋 修改配置前的标准流程

**每次修改 `openclaw.json` 前，按顺序执行：**

```bash
# 1. 备份当前配置
~/.openclaw/workspace/scripts/backup-config.sh "修改前备注"

# 2. 验证新配置（修改后）
~/.openclaw/workspace/scripts/validate-config.sh

# 3. 重启网关
openclaw gateway restart

# 4. 检查状态
openclaw status
```

---

## 🔧 可用脚本

### backup-config.sh
备份配置文件到 `~/.openclaw/backups/`，自动保留最近 10 个备份。

```bash
# 手动备份
~/.openclaw/workspace/scripts/backup-config.sh "添加新功能"

# 输出示例
✅ 配置已备份：/root/.openclaw/backups/openclaw.20260302_114500.添加新功能.json
🧹 已清理旧备份（保留最近 10 个）
```

### validate-config.sh
验证 JSON 语法和关键字段。

```bash
# 验证默认配置
~/.openclaw/workspace/scripts/validate-config.sh

# 验证指定文件
~/.openclaw/workspace/scripts/validate-config.sh /path/to/config.json
```

### health-monitor.sh
全面健康检查。

```bash
# 常规检查
~/.openclaw/workspace/scripts/health-monitor.sh

# 自动修复模式
~/.openclaw/workspace/scripts/health-monitor.sh --fix
```

---

## 🚨 故障排查流程

### 1. 快速诊断
```bash
openclaw status
openclaw doctor
```

### 2. 查看日志
```bash
# 实时日志
openclaw logs --follow

# 最近 100 行
openclaw logs 2>&1 | tail -100

# 查看特定日志文件
cat /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | tail -50
```

### 3. 检查服务状态
```bash
# systemd 服务
systemctl status openclaw-gateway

# 进程检查
pgrep -af openclaw

# 端口检查
netstat -tlnp | grep 18789
```

### 4. 恢复操作
```bash
# 重启网关
openclaw gateway restart

# 恢复备份配置
cp ~/.openclaw/backups/openclaw.最新备份.json ~/.openclaw/openclaw.json
openclaw gateway restart

# 运行健康检查
~/.openclaw/workspace/scripts/health-monitor.sh --fix
```

---

## ⚠️ 常见风险及避免方法

### 1. 配置语法错误
**风险**：JSON 格式错误导致网关无法启动

**避免**：
- 修改前备份
- 修改后用 `validate-config.sh` 验证
- 使用 JSON 编辑器（VS Code 等）

### 2. 无效配置项
**风险**：添加了 OpenClaw 不支持的配置项（如 `timezone`）

**避免**：
- 参考官方文档：https://docs.openclaw.ai
- 不确定时先问 MOSS
- 查看现有配置结构

### 3. 权限问题
**风险**：配置文件权限过宽导致安全警告

**避免**：
```bash
chmod 600 ~/.openclaw/openclaw.json
```

### 4. 资源耗尽
**风险**：磁盘/内存不足导致服务崩溃

**监控**：
- 健康检查 cron 每 6 小时自动检查
- 磁盘使用率 > 80% 会告警
- 可用内存 < 500MB 会告警

---

## 📊 监控任务

| 任务 | 频率 | 说明 |
|------|------|------|
| 健康监控检查 | 每 6 小时 | 自动检查网关、资源、配置 |
| 投资早报推送 | 每天 09:00 | 飞书推送 |
| 每周 Skills 探索 | 每周一 10:00 | Skills 推荐清单 |

---

## 🔄 备份策略

**自动备份位置**：`~/.openclaw/backups/`

**保留策略**：最近 10 个备份

**手动备份时机**：
- 修改配置前
- 安装新技能前
- 系统升级前

**恢复备份**：
```bash
# 查看可用备份
ls -lt ~/.openclaw/backups/

# 恢复指定备份
cp ~/.openclaw/backups/openclaw.20260302_114500.json ~/.openclaw/openclaw.json
openclaw gateway restart
```

---

## 📞 需要人工干预的情况

健康检查发现以下问题时会推送飞书通知：

- ❌ 网关重启失败
- ❌ 磁盘空间 < 10%
- ❌ 可用内存 < 200MB
- ❌ 配置文件损坏

收到通知后：
1. 查看具体错误信息
2. 运行 `openclaw doctor` 诊断
3. 必要时恢复备份配置
4. 联系 MOSS 协助排查

---

_最后更新：2026-03-02_
