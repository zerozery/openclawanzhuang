# USER.md - About Your Human

- **Name:** 玄柯
- **What to call them:** 玄柯
- **Pronouns:** _(待补充)_
- **Timezone:** Asia/Shanghai (推测)
- **Notes:** 一起研究 AI 用途的伙伴，MOSS 的合作者

## 技术栈

- **主力语言:** Java
- **前端:** 懂一些前端语言
- **其他:** 小程序开发

## Context

和 MOSS 一起探索 AI 的实际应用场景，互相学习。
