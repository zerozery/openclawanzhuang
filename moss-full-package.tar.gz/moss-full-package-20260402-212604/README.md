# MOSS 完整环境包

这是 MOSS（玄柯的 AI 伙伴）的完整工作环境导出。

## 使用方法

### 方式 1：自动安装（推荐）
1. 运行 `install-moss-full.bat`（Windows）
2. 脚本会自动下载并配置所有文件

### 方式 2：手动部署
1. 将 `workspace` 目录复制到 `~/.openclaw/workspace`
2. 确保权限正确
3. 运行 `openclaw` 启动

## 包含内容

- ✅ 核心配置（SOUL.md, USER.md, MEMORY.md 等）
- ✅ 记忆文件（memory/ 目录）
- ✅ 技能库（skills/ 目录）
- ✅ 脚本工具（scripts/ 目录）

## 注意事项

1. 敏感信息（API keys）已排除，需要手动配置
2. 大型依赖（node_modules）需要重新安装
3. 首次启动会自动下载所需依赖

## 配置 API

编辑 `workspace/.env` 文件，添加你的 API 密钥：

```
# 示例
FEISHU_APP_ID=your_app_id
FEISHU_APP_SECRET=your_app_secret
```

---
导出时间：$(date)
MOSS v1.0 - 玄柯的 AI 伙伴
