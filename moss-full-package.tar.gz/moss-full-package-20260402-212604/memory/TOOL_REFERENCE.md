# 工具/技能参考文档

_最后更新：2026-03-20_

---

## 📸 小红书配图生成 Skill

**Skill 名称**: `xiaohongshu-image`  
**位置**: `~/.openclaw/workspace/skills/xiaohongshu-image/`  
**状态**: ✅ 已创建并测试成功

### 功能
- 使用阿里通义万相 API 生成小红书配图
- 支持异步生成流程（自动轮询任务状态）
- 支持多种尺寸和风格

### 支持尺寸
- 1:1 → 1024×1024（知识卡片）
- 3:4 → 720×1280（竖图封面，推荐）
- 9:16 → 1080×1920（全屏背景）

### 支持风格
- `flat illustration` - 扁平插画（推荐用于技术分享）
- `anime` - 动漫（推荐用于学习日常）
- `auto` - 自动
- 其他：3d cartoon, oil painting, watercolor, sketch, chinese painting, photography, portrait

### 使用方法
```bash
# 基础用法
python3 ~/.openclaw/workspace/skills/xiaohongshu-image/scripts/generate.py \
  --prompt "AI 技术分享封面" \
  --style "flat illustration" \
  --size "720*1280" \
  --theme "技术"

# 快捷脚本
~/.openclaw/workspace/skills/xiaohongshu-image/scripts/xhs-img "提示词" "风格" "尺寸" "主题"
```

### API 配置
- API Key: 存储在 DashScope 配置文件
- 端点：`https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis`
- 模型：`wanx2.1-t2i-turbo`

### 输出
- 图片保存在 `/tmp/xhs_image_*.png`
- 可通过飞书 API 发送给用户

---

## 🎨 图片生成 + 发送工作流

**完整流程**:
1. 使用 `xiaohongshu-image` Skill 生成图片
2. 使用飞书 API 发送图片给用户
3. 用户确认后可用于小红书发布

**用途**:
- 小红书笔记配图生成
- 技术分享封面制作
- 学习日常插画
- 知识卡片背景

---

## 🔧 系统运维脚本

### 配置备份
- 脚本：`~/.openclaw/workspace/scripts/backup-config.sh`
- 自动保留最近 10 个备份
- 位置：`~/.openclaw/backups/`

### 配置验证
- 脚本：`~/.openclaw/workspace/scripts/validate-config.sh`
- 检查 JSON 语法和关键字段

### 健康监控
- 脚本：`~/.openclaw/workspace/scripts/health-monitor.sh`
- Cron 任务：每 6 小时自动检查
- 检查项：网关状态、WebSocket、磁盘、内存、cron 任务
- 异常时自动尝试恢复并推送飞书通知

### 安全重启
- 脚本：`~/.openclaw/workspace/scripts/safe-restart.sh`
- 流程：备份 → 验证 → 重启 → 确认
- 用法：`./safe-restart.sh "备注"`

### 运维文档
- 文件：`~/root/.openclaw/workspace/OPERATIONS.md`

---

## 📅 定时任务清单

| 时间 | 任务 | 说明 |
|------|------|------|
| 每天 09:00 | 投资早报推送 | 飞书推送投资机会分析 |
| 每周一 10:00 | Skills 探索 | 搜索推荐新 skills |
| 每 6 小时 | 健康监控 | 系统状态检查 |
| 每天 18:00 | 内容提醒 | 内容创作提醒 |
