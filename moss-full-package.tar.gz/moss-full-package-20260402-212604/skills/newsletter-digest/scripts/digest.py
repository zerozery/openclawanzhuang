#!/usr/bin/env python3
"""
新闻通讯摘要脚本
支持 RSS 订阅、内容抓取、摘要生成
"""

import json
import os
from datetime import datetime, timedelta
import argparse
import feedparser

SUBS_FILE = os.path.expanduser("~/.openclaw/workspace/memory/newsletter_subs.json")
CACHE_DIR = os.path.expanduser("~/.openclaw/workspace/memory/newsletter_cache")

def load_subs():
    """加载订阅列表"""
    if not os.path.exists(SUBS_FILE):
        return []
    with open(SUBS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_subs(subs):
    """保存订阅列表"""
    os.makedirs(os.path.dirname(SUBS_FILE), exist_ok=True)
    with open(SUBS_FILE, 'w', encoding='utf-8') as f:
        json.dump(subs, f, ensure_ascii=False, indent=2)

def subscribe(url, name=None, keywords=None):
    """添加订阅"""
    subs = load_subs()
    
    # 检查是否已存在
    for s in subs:
        if s["url"] == url:
            print(f"⚠️ 该订阅已存在：{s.get('name', url)}")
            return
    
    # 测试 RSS 源
    try:
        feed = feedparser.parse(url)
        if not feed.entries:
            print(f"⚠️ 未找到有效内容：{url}")
    except Exception as e:
        print(f"❌ 无法解析 RSS: {e}")
        return
    
    sub = {
        "id": len(subs) + 1,
        "url": url,
        "name": name or url,
        "keywords": keywords or [],
        "enabled": True,
        "added": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "last_fetch": None
    }
    
    subs.append(sub)
    save_subs(subs)
    
    print(f"✅ 已添加订阅：{sub['name']}")
    print(f"   URL: {url}")
    if keywords:
        print(f"   关键词：{', '.join(keywords)}")
    
    return sub

def list_subs():
    """列出订阅"""
    subs = load_subs()
    
    if not subs:
        print("📭 暂无订阅")
        return
    
    print(f"📰 订阅列表 (共 {len(subs)} 个)\n")
    
    for s in subs:
        status = "✅" if s["enabled"] else "❌"
        print(f"{status} #{s['id']} {s['name']}")
        print(f"   URL: {s['url']}")
        if s.get('keywords'):
            print(f"   关键词：{', '.join(s['keywords'])}")
        last = s.get('last_fetch')
        print(f"   最后抓取：{last or '从未'}")
        print()

def unsubscribe(sub_id):
    """取消订阅"""
    subs = load_subs()
    
    for i, s in enumerate(subs):
        if s["id"] == sub_id:
            removed = subs.pop(i)
            save_subs(subs)
            print(f"✅ 已取消订阅：{removed['name']}")
            return
    
    print(f"❌ 未找到订阅 #{sub_id}")

def fetch_feed(sub_id, days=7):
    """抓取订阅内容"""
    subs = load_subs()
    
    sub = None
    for s in subs:
        if s["id"] == sub_id:
            sub = s
            break
    
    if not sub:
        print(f"❌ 未找到订阅 #{sub_id}")
        return
    
    print(f"📥 抓取：{sub['name']}")
    
    try:
        feed = feedparser.parse(sub["url"])
        cutoff = datetime.now() - timedelta(days=days)
        
        articles = []
        for entry in feed.entries:
            published = None
            if hasattr(entry, 'published_parsed') and entry.published_parsed:
                published = datetime(*entry.published_parsed[:6])
            
            if published and published < cutoff:
                continue
            
            # 关键词过滤
            if sub.get('keywords'):
                content = (entry.get('title', '') + ' ' + entry.get('summary', '')).lower()
                if not any(kw.lower() in content for kw in sub['keywords']):
                    continue
            
            articles.append({
                "title": entry.get('title', '无标题'),
                "link": entry.get('link', ''),
                "summary": entry.get('summary', '')[:500],
                "published": published.strftime("%Y-%m-%d") if published else None,
                "source": sub['name']
            })
        
        # 更新最后抓取时间
        sub['last_fetch'] = datetime.now().strftime("%Y-%m-%d %H:%M")
        save_subs(subs)
        
        # 保存到缓存
        os.makedirs(CACHE_DIR, exist_ok=True)
        cache_file = os.path.join(CACHE_DIR, f"{sub_id}_{datetime.now().strftime('%Y%m%d')}.json")
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(articles, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 抓取成功：{len(articles)} 篇文章")
        for a in articles[:5]:
            print(f"   - {a['title']}")
        if len(articles) > 5:
            print(f"   ... 还有 {len(articles) - 5} 篇")
        
        return articles
    
    except Exception as e:
        print(f"❌ 抓取失败：{e}")
        return []

def generate_digest(period="weekly"):
    """生成摘要"""
    days = 7 if period == "weekly" else 1
    
    print(f"📝 生成{period}摘要...\n")
    
    subs = load_subs()
    all_articles = []
    
    for sub in subs:
        if not sub["enabled"]:
            continue
        articles = fetch_feed(sub["id"], days)
        all_articles.extend(articles)
    
    if not all_articles:
        print("📭 暂无新内容")
        return
    
    # 按来源分组
    by_source = {}
    for a in all_articles:
        source = a["source"]
        if source not in by_source:
            by_source[source] = []
        by_source[source].append(a)
    
    print(f"\n📊 摘要统计")
    print(f"   来源数：{len(by_source)}")
    print(f"   文章数：{len(all_articles)}")
    
    # 生成 Markdown 摘要
    md = f"# 📰 {period.title()} 新闻摘要\n\n"
    md += f"_生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}_\n\n"
    md += f"共 {len(all_articles)} 篇文章，来自 {len(by_source)} 个来源\n\n"
    md += "---\n\n"
    
    for source, articles in by_source.items():
        md += f"## {source} ({len(articles)}篇)\n\n"
        for i, a in enumerate(articles, 1):
            md += f"{i}. **[{a['title']}]({a['link']})**\n"
            if a.get('summary'):
                md += f"   > {a['summary'][:200]}...\n"
            md += "\n"
        md += "\n"
    
    # 保存摘要
    os.makedirs(CACHE_DIR, exist_ok=True)
    digest_file = os.path.join(CACHE_DIR, f"digest_{period}_{datetime.now().strftime('%Y%m%d')}.md")
    with open(digest_file, 'w', encoding='utf-8') as f:
        f.write(md)
    
    print(f"\n✅ 摘要已保存：{digest_file}")
    
    return digest_file

def main():
    parser = argparse.ArgumentParser(description="新闻通讯摘要")
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # subscribe
    sub_parser = subparsers.add_parser("subscribe", help="添加订阅")
    sub_parser.add_argument("url", help="RSS URL")
    sub_parser.add_argument("--name", "-n", help="订阅名称")
    sub_parser.add_argument("--keywords", "-k", nargs="+", help="过滤关键词")
    
    # unsubscribe
    unsub_parser = subparsers.add_parser("unsubscribe", help="取消订阅")
    unsub_parser.add_argument("id", type=int, help="订阅 ID")
    
    # list
    subparsers.add_parser("list", help="列出订阅")
    
    # fetch
    fetch_parser = subparsers.add_parser("fetch", help="抓取内容")
    fetch_parser.add_argument("--source", "-s", type=int, help="订阅 ID")
    fetch_parser.add_argument("--days", "-d", type=int, default=7, help="天数")
    
    # generate
    gen_parser = subparsers.add_parser("generate", help="生成摘要")
    gen_parser.add_argument("--period", "-p", choices=["daily", "weekly"], default="weekly")
    
    args = parser.parse_args()
    
    if args.command == "subscribe":
        subscribe(args.url, args.name, args.keywords)
    elif args.command == "unsubscribe":
        unsubscribe(args.id)
    elif args.command == "list":
        list_subs()
    elif args.command == "fetch":
        fetch_feed(args.source, args.days)
    elif args.command == "generate":
        generate_digest(args.period)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
