---
name: newsletter-digest
description: 新闻通讯摘要技能。订阅 RSS/邮件列表，生成每日/每周摘要，支持自定义主题过滤。
---

# 新闻通讯摘要

管理和生成新闻通讯摘要。

## 快速开始

```bash
# 添加订阅源
python3 scripts/digest.py subscribe "https://example.com/rss" --name "技术新闻"

# 查看订阅
python3 scripts/digest.py subscriptions

# 获取摘要
python3 scripts/digest.py fetch --source "技术新闻" --days 7

# 生成周报
python3 scripts/digest.py generate --period weekly
```

## 功能

1. **RSS 订阅管理** - 添加/删除订阅源
2. **内容抓取** - 定期抓取最新文章
3. **智能摘要** - AI 生成内容摘要
4. **主题过滤** - 按关键词过滤内容
5. **定时推送** - 每日/每周自动推送

## 推送方式

- 飞书消息
- 邮件
- 保存到笔记（Notion/Obsidian）

## 数据存储

- 订阅配置：`~/.openclaw/workspace/memory/newsletter_subs.json`
- 抓取内容：`~/.openclaw/workspace/memory/newsletter_cache/`
