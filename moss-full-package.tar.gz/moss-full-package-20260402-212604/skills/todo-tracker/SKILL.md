---
name: todo-tracker
description: 待办事项追踪技能。支持添加、完成、删除待办，支持优先级和分类管理。
---

# 待办事项管理

管理和追踪待办事项。

## 快速开始

```bash
# 添加待办
python3 scripts/todo.py add "完成项目报告" --priority high --category 工作

# 查看待办
python3 scripts/todo.py list

# 完成待办
python3 scripts/todo.py done 1

# 删除待办
python3 scripts/todo.py delete 1
```

## 优先级

- `high` - 高优先级 🔴
- `medium` - 中优先级 🟡
- `low` - 低优先级 🟢

## 分类示例

- 工作
- 学习
- 生活
- 购物
- 健康

## 数据存储

待办事项保存在 `~/.openclaw/workspace/memory/todos.json`
