#!/usr/bin/env python3
"""
待办事项管理脚本
支持添加、完成、删除待办，支持优先级和分类
"""

import json
import os
from datetime import datetime
import argparse

TODOS_FILE = os.path.expanduser("~/.openclaw/workspace/memory/todos.json")

PRIORITY_ICONS = {
    "high": "🔴",
    "medium": "🟡",
    "low": "🟢"
}

def load_todos():
    """加载待办列表"""
    if not os.path.exists(TODOS_FILE):
        return []
    with open(TODOS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_todos(todos):
    """保存待办列表"""
    os.makedirs(os.path.dirname(TODOS_FILE), exist_ok=True)
    with open(TODOS_FILE, 'w', encoding='utf-8') as f:
        json.dump(todos, f, ensure_ascii=False, indent=2)

def add_todo(title, priority="medium", category=None):
    """添加待办"""
    todos = load_todos()
    
    todo = {
        "id": len(todos) + 1,
        "title": title,
        "priority": priority,
        "category": category,
        "status": "pending",
        "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "completed": None
    }
    
    todos.append(todo)
    save_todos(todos)
    
    icon = PRIORITY_ICONS.get(priority, "⚪")
    print(f"✅ 待办已添加：{title}")
    print(f"   优先级：{icon} {priority}")
    if category:
        print(f"   分类：{category}")
    
    return todo

def list_todos(status=None, category=None):
    """列出待办"""
    todos = load_todos()
    
    # 过滤
    if status:
        todos = [t for t in todos if t["status"] == status]
    if category:
        todos = [t for t in todos if t.get("category") == category]
    
    if not todos:
        print("📭 暂无待办")
        return
    
    print(f"📋 待办列表 (共 {len(todos)} 条)\n")
    
    # 按状态和优先级排序
    todos.sort(key=lambda x: (0 if x["status"] == "pending" else 1, 
                              {"high": 0, "medium": 1, "low": 2}.get(x["priority"], 3)))
    
    for t in todos:
        status_icon = "☐" if t["status"] == "pending" else "✅"
        priority_icon = PRIORITY_ICONS.get(t["priority"], "⚪")
        
        print(f"{status_icon} #{t['id']} {priority_icon} {t['title']}")
        if t.get("category"):
            print(f"   分类：{t['category']}")
        print(f"   创建：{t['created']}")
        if t.get("completed"):
            print(f"   完成：{t['completed']}")
        print()

def done_todo(todo_id):
    """完成待办"""
    todos = load_todos()
    
    for t in todos:
        if t["id"] == todo_id:
            t["status"] = "completed"
            t["completed"] = datetime.now().strftime("%Y-%m-%d %H:%M")
            save_todos(todos)
            print(f"✅ 待办已完成：{t['title']}")
            return
    
    print(f"❌ 未找到待办 #{todo_id}")

def delete_todo(todo_id):
    """删除待办"""
    todos = load_todos()
    
    for i, t in enumerate(todos):
        if t["id"] == todo_id:
            deleted = todos.pop(i)
            save_todos(todos)
            print(f"✅ 待办已删除：{deleted['title']}")
            return
    
    print(f"❌ 未找到待办 #{todo_id}")

def stats():
    """统计待办"""
    todos = load_todos()
    
    total = len(todos)
    pending = len([t for t in todos if t["status"] == "pending"])
    completed = len([t for t in todos if t["status"] == "completed"])
    
    print(f"📊 待办统计")
    print(f"   总计：{total}")
    print(f"   待完成：{pending}")
    print(f"   已完成：{completed}")
    
    if total > 0:
        rate = completed / total * 100
        print(f"   完成率：{rate:.1f}%")

def main():
    parser = argparse.ArgumentParser(description="待办事项管理")
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # add
    add_parser = subparsers.add_parser("add", help="添加待办")
    add_parser.add_argument("title", help="待办标题")
    add_parser.add_argument("--priority", "-p", choices=["high", "medium", "low"], default="medium")
    add_parser.add_argument("--category", "-c", help="分类")
    
    # list
    list_parser = subparsers.add_parser("list", help="列出待办")
    list_parser.add_argument("--status", "-s", choices=["pending", "completed"])
    list_parser.add_argument("--category", "-c", help="分类")
    
    # done
    done_parser = subparsers.add_parser("done", help="完成待办")
    done_parser.add_argument("id", type=int, help="待办 ID")
    
    # delete
    del_parser = subparsers.add_parser("delete", help="删除待办")
    del_parser.add_argument("id", type=int, help="待办 ID")
    
    # stats
    subparsers.add_parser("stats", help="统计")
    
    args = parser.parse_args()
    
    if args.command == "add":
        add_todo(args.title, args.priority, args.category)
    elif args.command == "list":
        list_todos(args.status, args.category)
    elif args.command == "done":
        done_todo(args.id)
    elif args.command == "delete":
        delete_todo(args.id)
    elif args.command == "stats":
        stats()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
