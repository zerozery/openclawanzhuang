# Finance Skill - 腾讯财经 API 集成文档

## 概述
Finance Skill 现已集成腾讯财经 API 作为主要数据源，替代被限流的 yfinance。

## 数据源
- **主要**: 腾讯财经 API (`qt.gtimg.cn`) - 免费、无需 API key、支持 A 股/港股/美股/期货/外汇
- **备用**: yfinance (仅当腾讯 API 失败时使用)

## 支持的资产类别

| 资产类型 | 代码前缀 | 示例 | 说明 |
|---------|---------|------|------|
| A 股 (上证) | `sh` | `sh000300`, `sh600000` | 上证指数、平安银行等 |
| A 股 (深证) | `sz` | `sz000001`, `sz300750` | 深证成指、宁德时代等 |
| 港股 | `hk` | `hk0700`, `hk9988` | 腾讯控股、阿里巴巴等 |
| 美股 | `us` | `usAAPL`, `usTSLA` | 苹果、特斯拉等 |
| 美股指数 | `us` | `usNDX`, `usDJI`, `usSPX` | 纳斯达克、道琼斯、标普 500 |
| 期货 (外盘) | `hf` | `hf_GC`, `hf_CL` | COMEX 黄金、WTI 原油 |
| ETF (国内) | `sh`/`sz` | `sh518880` | 黄金 ETF |

## 脚本说明

### 1. finance_crawler.py
抓取主要指数和黄金价格的专用脚本

```bash
# 获取所有数据（格式化输出）
python3 finance_crawler.py

# 获取所有数据（JSON 输出）
python3 finance_crawler.py --json
```

**返回数据**:
- 沪深 300 指数
- 纳斯达克 100 指数
- COMEX 黄金期货（美元/盎司 + 人民币/克换算）
- 黄金 ETF（国内）

### 2. fetch_quote.py
通用报价查询脚本，支持任意腾讯 API 代码

```bash
# 查询单个标的
python3 fetch_quote.py sh000300
python3 fetch_quote.py usAAPL
python3 fetch_quote.py hf_GC

# 查询所有主要指数
python3 fetch_quote.py --all
```

## API 字段解析

腾讯 API 返回格式：
```
v_sh000300="51~1~000300~4518.61~4526.07~4514.44~..."
```

字段说明（`~` 分隔）：
- 字段 0: 未知
- 字段 1: 未知
- 字段 2: 代码
- **字段 3: 当前价格**
- **字段 4: 最高价**
- **字段 5: 最低价**
- 字段 31: 涨跌额
- 字段 32: 涨跌幅 (%)
- 字段 37: 开盘价
- 字段 38: 昨收价

**注意**: 期货（如黄金）使用 `,` 分隔而非 `~`

## 黄金价格换算

COMEX 黄金期货报价单位：**美元/金衡盎司**

换算为人民币/克：
```python
price_cny = price_usd * exchange_rate / 31.1035
```

其中：
- `exchange_rate`: 美元/人民币汇率（约 7.2）
- `31.1035`: 1 金衡盎司 = 31.1035 克

示例：
- COMEX 黄金：4722.34 美元/盎司
- 折合人民币：4722.34 × 7.2 ÷ 31.1035 ≈ 1093.15 元/克

## 集成到 Finance Skill

修改了以下文件：
1. `SKILL.md` - 更新 provider 策略，添加腾讯 API 说明
2. `requirements.txt` - 标注 yfinance 为备用
3. `scripts/finance_crawler.py` - 主要爬虫脚本
4. `scripts/fetch_quote.py` - 通用查询脚本

## 使用示例

### 查询 A 股指数
```bash
python3 fetch_quote.py sh000300  # 沪深 300
python3 fetch_quote.py sh000001  # 上证指数
python3 fetch_quote.py sz399001  # 深证成指
```

### 查询美股
```bash
python3 fetch_quote.py usAAPL    # 苹果
python3 fetch_quote.py usTSLA    # 特斯拉
python3 fetch_quote.py usNDX     # 纳斯达克 100
```

### 查询黄金
```bash
python3 finance_crawler.py       # 获取黄金期货 + ETF
python3 fetch_quote.py hf_GC     # COMEX 黄金
python3 fetch_quote.py sh518880  # 黄金 ETF
```

## 注意事项

1. **编码**: 腾讯 API 返回 GBK 编码，必须正确解码
2. **分隔符**: 股票用 `~`，期货用 `,`
3. **汇率**: 黄金换算使用固定汇率 7.2，可更新为实时汇率
4. **缓存**: 建议在 skill 层面实现缓存，避免频繁请求

## 后续优化

- [ ] 添加更多期货品种（原油、铜等）
- [ ] 支持历史数据抓取
- [ ] 集成实时汇率 API
- [ ] 添加缓存机制（Redis/SQLite）
- [ ] 支持批量查询（一次请求多个标的）
