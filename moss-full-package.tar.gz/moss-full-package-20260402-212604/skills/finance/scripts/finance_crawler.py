#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
财经数据爬虫工具
抓取黄金价格、沪深 300、纳斯达克 100 等实时行情数据
数据源：腾讯财经 API
"""

import requests
import re
import json
from datetime import datetime

# 请求头配置
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Referer': 'https://stockapp.finance.qq.com/',
}

def fetch_csi300():
    """
    抓取沪深 300 指数
    代码：sh000300
    """
    url = 'https://qt.gtimg.cn/q=sh000300'
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.encoding = 'gbk'  # 腾讯 API 返回 GBK 编码
        text = response.text
        
        # 解析：v_sh000300="51~1~000300~4518.61~4526.07~4514.44~..."
        # 字段：~ 分隔，第 4 个是当前价，第 5 个是最高，第 6 个是最低，第 32 个是涨跌额，第 33 个是涨跌幅
        match = re.search(r'v_sh000300="([^"]+)"', text)
        if match:
            fields = match.group(1).split('~')
            if len(fields) >= 39:
                price = float(fields[3]) if fields[3] else 0
                # 昨收价在字段 38，但有时数据异常，用当前价 - 涨跌额计算
                prev_close_raw = float(fields[38]) if len(fields) > 38 and fields[38] else 0
                change = float(fields[31]) if len(fields) > 31 and fields[31] else 0
                # 如果昨收价异常（太小或太大），用计算值
                if prev_close_raw < 100 or prev_close_raw > 100000:
                    prev_close = price - change
                else:
                    prev_close = prev_close_raw
                return {
                    'name': '沪深 300',
                    'code': '000300',
                    'price': price,
                    'high': float(fields[4]) if fields[4] else 0,
                    'low': float(fields[5]) if fields[5] else 0,
                    'open': float(fields[37]) if len(fields) > 37 and fields[37] else 0,
                    'prev_close': prev_close,
                    'change': change,
                    'change_pct': float(fields[32]) if len(fields) > 32 and fields[32] else 0,
                    'vs_prev': price - prev_close,
                    'vs_prev_pct': ((price - prev_close) / prev_close * 100) if prev_close else 0,
                    'timestamp': datetime.now().isoformat()
                }
    except Exception as e:
        pass
    
    return {'error': f'Failed to fetch CSI300: {str(e)}'}

def fetch_nasdaq100():
    """
    抓取纳斯达克 100 指数
    代码：usNDX
    """
    url = 'https://qt.gtimg.cn/q=usNDX'
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.encoding = 'gbk'
        text = response.text
        
        # 解析：v_usNDX="51~1~NDX~21234.56~..."
        match = re.search(r'v_usNDX="([^"]+)"', text)
        if match:
            fields = match.group(1).split('~')
            if len(fields) >= 39:
                price = float(fields[3]) if fields[3] else 0
                change = float(fields[31]) if len(fields) > 31 and fields[31] else 0
                # 昨收价在字段 38，但美股数据可能异常，用计算值
                prev_close_raw = float(fields[38]) if len(fields) > 38 and fields[38] else 0
                if prev_close_raw < 1000 or prev_close_raw > 100000:
                    prev_close = price - change
                else:
                    prev_close = prev_close_raw
                return {
                    'name': '纳斯达克 100',
                    'code': 'NDX',
                    'price': price,
                    'high': float(fields[4]) if fields[4] else 0,
                    'low': float(fields[5]) if fields[5] else 0,
                    'open': float(fields[37]) if len(fields) > 37 and fields[37] else 0,
                    'prev_close': prev_close,
                    'change': change,
                    'change_pct': float(fields[32]) if len(fields) > 32 and fields[32] else 0,
                    'vs_prev': price - prev_close,
                    'vs_prev_pct': ((price - prev_close) / prev_close * 100) if prev_close else 0,
                    'timestamp': datetime.now().isoformat()
                }
    except Exception as e:
        pass
    
    return {'error': f'Failed to fetch NASDAQ100: {str(e)}'}

def fetch_gold_price():
    """
    抓取黄金价格
    数据源：腾讯财经 COMEX 黄金期货
    代码：hf_GC (COMEX 黄金期货，美元/盎司)
    """
    url = 'https://qt.gtimg.cn/q=hf_GC'
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.encoding = 'gbk'
        text = response.text
        
        # 解析：v_hf_GC="4722.34,-1.89,4726.30,4727.00,4825.90,4675.70,..."
        # 字段：0=当前价，1=涨跌额，2=?, 3=今开，4=最高，5=最低
        match = re.search(r'v_hf_GC="([^"]+)"', text)
        if match:
            fields = match.group(1).split(',')
            if len(fields) >= 6:
                price_usd = float(fields[0]) if fields[0] else 0
                change = float(fields[1]) if fields[1] else 0
                high = float(fields[4]) if fields[4] else 0
                low = float(fields[5]) if fields[5] else 0
                # 计算昨收价
                prev_close_usd = price_usd - change
                # 国际黄金是美元/盎司，转换为人民币/克
                # 1 盎司 = 31.1035 克，假设美元/人民币汇率约为 7.2
                exchange_rate = 7.2
                price_cny = price_usd * exchange_rate / 31.1035
                prev_close_cny = prev_close_usd * exchange_rate / 31.1035
                return {
                    'name': 'COMEX 黄金期货',
                    'code': 'hf_GC',
                    'price_usd': price_usd,
                    'price_cny': round(price_cny, 2),
                    'prev_close_usd': round(prev_close_usd, 2),
                    'prev_close_cny': round(prev_close_cny, 2),
                    'change': change,
                    'change_pct': (change / prev_close_usd * 100) if prev_close_usd else 0,
                    'high': high,
                    'low': low,
                    'unit': '美元/盎司',
                    'exchange_rate': exchange_rate,
                    'vs_prev': -change,  # 期货字段 1 已经是涨跌
                    'vs_prev_pct': -(change / prev_close_usd * 100) if prev_close_usd else 0,
                    'timestamp': datetime.now().isoformat()
                }
    except Exception as e:
        pass
    
    return {'error': f'Failed to fetch gold: {str(e)}'}

def fetch_gold_domestic():
    """
    抓取国内黄金价格（黄金 T+D）
    代码：sh518880 (黄金 ETF)
    """
    url = 'https://qt.gtimg.cn/q=sh518880'
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.encoding = 'gbk'
        text = response.text
        
        match = re.search(r'v_sh518880="([^"]+)"', text)
        if match:
            fields = match.group(1).split('~')
            if len(fields) >= 4:
                return {
                    'name': '黄金 ETF',
                    'code': '518880',
                    'price': float(fields[3]) if fields[3] else 0,
                    'change': float(fields[31]) if len(fields) > 31 and fields[31] else 0,
                    'change_pct': float(fields[32]) if len(fields) > 32 and fields[32] else 0,
                    'timestamp': datetime.now().isoformat()
                }
    except Exception as e:
        pass
    
    return {'error': 'Failed to fetch domestic gold'}

def fetch_all():
    """
    抓取所有数据
    """
    print(f"🕒 抓取时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 沪深 300
    print("\n📈 沪深 300 指数")
    print("-" * 60)
    csi300 = fetch_csi300()
    if 'error' not in csi300:
        print(f"   指数：{csi300['price']:.2f}")
        print(f"   涨跌：{csi300['change']:+.2f} ({csi300['change_pct']:+.2f}%)")
        print(f"   最高：{csi300['high']:.2f} | 最低：{csi300['low']:.2f}")
        print(f"   开盘：{csi300['open']:.2f}")
        print(f"   昨收：{csi300['prev_close']:.2f} → 今日：{csi300['price']:.2f} (变动：{csi300['vs_prev']:+.2f}, {csi300['vs_prev_pct']:+.2f}%)")
    else:
        print(f"   ❌ 获取失败：{csi300['error']}")
    
    # 纳斯达克 100
    print("\n🇺🇸 纳斯达克 100 指数")
    print("-" * 60)
    nasdaq = fetch_nasdaq100()
    if 'error' not in nasdaq:
        print(f"   指数：{nasdaq['price']:.2f}")
        print(f"   涨跌：{nasdaq['change']:+.2f} ({nasdaq['change_pct']:+.2f}%)")
        print(f"   最高：{nasdaq['high']:.2f} | 最低：{nasdaq['low']:.2f}")
        print(f"   开盘：{nasdaq['open']:.2f}")
        print(f"   昨收：{nasdaq['prev_close']:.2f} → 今日：{nasdaq['price']:.2f} (变动：{nasdaq['vs_prev']:+.2f}, {nasdaq['vs_prev_pct']:+.2f}%)")
    else:
        print(f"   ❌ 获取失败：{nasdaq['error']}")
    
    # 黄金价格（COMEX 期货）
    print("\n🥇 黄金价格 (COMEX 期货)")
    print("-" * 60)
    gold = fetch_gold_price()
    if 'error' not in gold:
        print(f"   价格：{gold['price_usd']:.2f} 美元/盎司")
        print(f"   折合：{gold['price_cny']:.2f} 元/克 (汇率 {gold['exchange_rate']})")
        print(f"   涨跌：{gold['change']:+.2f} ({gold['change_pct']:+.2f}%)")
        print(f"   最高：{gold['high']:.2f} | 最低：{gold['low']:.2f}")
        print(f"   昨收：{gold['prev_close_usd']:.2f} 美元 → 今日：{gold['price_usd']:.2f} 美元")
        print(f"   昨收：{gold['prev_close_cny']:.2f} 元/克 → 今日：{gold['price_cny']:.2f} 元/克")
    else:
        print(f"   ❌ 获取失败：{gold['error']}")
    
    # 黄金 ETF（国内）
    print("\n🥇 黄金 ETF (国内)")
    print("-" * 60)
    gold_etf = fetch_gold_domestic()
    if 'error' not in gold_etf:
        print(f"   价格：{gold_etf['price']:.3f} 元")
        print(f"   涨跌：{gold_etf['change']:+.3f} ({gold_etf['change_pct']:+.2f}%)")
    else:
        print(f"   ❌ 获取失败：{gold_etf['error']}")
    
    print("\n" + "=" * 60)
    
    return {
        'csi300': csi300,
        'nasdaq100': nasdaq,
        'gold_intl': gold,
        'gold_etf': gold_etf,
        'timestamp': datetime.now().isoformat()
    }

def output_json():
    """
    输出 JSON 格式数据
    """
    data = fetch_all()
    print("\n📄 JSON 输出:")
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return data

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--json':
        output_json()
    else:
        fetch_all()
