#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
财经数据查询主脚本
集成腾讯财经 API 爬虫，支持 A 股、港股、美股、指数、黄金等

Usage:
    python fetch_quote.py <symbol>
    python fetch_quote.py --all  # 获取所有主要指数
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from finance_crawler import (
    fetch_csi300,
    fetch_nasdaq100,
    fetch_gold_price,
    fetch_gold_domestic,
    fetch_all,
    output_json
)

def fetch_single_symbol(symbol: str):
    """
    获取单个标的的报价
    支持代码格式：
    - sh000300, sz000001 (A 股)
    - usAAPL, usNDX (美股/指数)
    - hk0700 (港股)
    - hf_GC (COMEX 黄金)
    - sh518880 (黄金 ETF)
    """
    import requests
    
    # 自动添加前缀
    if symbol.startswith(('sh', 'sz', 'us', 'hk', 'hf')):
        code = symbol
    else:
        # 尝试自动判断
        if symbol.isdigit():
            if symbol.startswith('6'):
                code = f'sh{symbol}'
            else:
                code = f'sz{symbol}'
        elif symbol.upper() in ['NDX', 'DJI', 'IXIC', 'SPX']:
            code = f'us{symbol.upper()}'
        else:
            code = f'us{symbol.upper()}'  # 默认美股
    
    url = f'https://qt.gtimg.cn/q={code}'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': '*/*',
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = 'gbk'
        text = response.text
        
        if 'v_pv_none_match' in text:
            return {'error': f'Symbol {symbol} not found'}
        
        # 解析数据
        import re
        match = re.search(r'v_[^=]+="([^"]+)"', text)
        if match:
            fields = match.group(1).split('~')
            
            # 通用字段解析
            result = {
                'symbol': symbol,
                'code': code,
                'timestamp': __import__('datetime').datetime.now().isoformat()
            }
            
            if len(fields) >= 4:
                result['price'] = float(fields[3]) if fields[3] else 0
            if len(fields) >= 6:
                result['high'] = float(fields[4]) if fields[4] else 0
                result['low'] = float(fields[5]) if fields[5] else 0
            if len(fields) >= 33:
                result['change'] = float(fields[31]) if len(fields) > 31 and fields[31] else 0
                result['change_pct'] = float(fields[32]) if len(fields) > 32 and fields[32] else 0
            
            return result
    except Exception as e:
        return {'error': str(e)}
    
    return {'error': 'Failed to fetch'}

def main():
    if len(sys.argv) < 2:
        print("用法：python fetch_quote.py <symbol>")
        print("   或：python fetch_quote.py --all")
        print("\n示例:")
        print("  python fetch_quote.py sh000300  # 沪深 300")
        print("  python fetch_quote.py usNDX     # 纳斯达克 100")
        print("  python fetch_quote.py hf_GC     # COMEX 黄金")
        print("  python fetch_quote.py --all     # 获取所有主要指数")
        sys.exit(1)
    
    if sys.argv[1] == '--all':
        output_json()
    else:
        symbol = sys.argv[1]
        result = fetch_single_symbol(symbol)
        
        import json
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
