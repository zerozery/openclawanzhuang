---
name: finance
description: Track stocks, ETFs, indices, crypto (where available), and FX pairs with caching + provider fallbacks.
metadata: {"clawdbot":{"config":{"requiredEnv":[],"stateDirs":[".cache/finance"],"example":"# No API keys required - uses free Tencent Finance API\n"}}}
---

# Market Tracker Skill

This skill helps you fetch **latest quotes** and **historical series** for:
- Stocks / ETFs / Indices (e.g., AAPL, MSFT, ^GSPC, VOO, 沪深 300, 纳斯达克 100)
- FX pairs (e.g., USD/ZAR, EURUSD, GBP-JPY)
- Crypto tickers supported by the chosen provider (best-effort)
- Commodities (e.g., Gold, Silver)

It is optimized for:
- fast "what's the price now?" queries
- lightweight tracking with a local watchlist
- caching to avoid rate-limits

## When to use
Use this skill when the user asks:
- "What's the latest price of ___?"
- "Track ___ and ___ and show me daily changes."
- "Give me a 30-day series for ___."
- "Convert USD to ZAR (or track USD/ZAR)."
- "Maintain a watchlist and summarize performance."
- "查询黄金价格"、"沪深 300 指数"、"纳斯达克指数"

## Provider strategy (important)
- **Stocks/ETFs/indices**: Default to **Tencent Finance API** (`qt.gtimg.cn`) - free, no key required, supports A-shares, HK stocks, US stocks, indices
- **Fallback**: Yahoo Finance via `yfinance` (if Tencent fails)
- **FX**: ExchangeRate-API Open Access endpoint (no key, daily update)
- **Gold/Commodities**: Tencent Finance futures API (hf_GC for COMEX gold)

See `providers.md` for details and symbol formats.

---

# Quick start (how you run it)
These scripts are intended to be run from a terminal. The agent should:
1) ensure dependencies installed
2) run the scripts
3) summarize results cleanly

Install:
- `python -m venv .venv && source .venv/bin/activate` (or Windows equivalent)
- `pip install -r requirements.txt`

## Commands

### 1) Latest quote (stock/ETF/index) - **Primary: Tencent Finance**
Examples:
- `python scripts/finance_crawler.py` (fetch all: CSI300, NASDAQ100, Gold)
- `python scripts/market_quote.py AAPL`
- `python scripts/market_quote.py ^GSPC`
- `python scripts/market_quote.py VOO`
- `python scripts/market_quote.py sh000300` (沪深 300)
- `python scripts/market_quote.py usNDX` (纳斯达克 100)

### 2) Latest FX rate
Examples:
- `python scripts/market_quote.py USD/ZAR`
- `python scripts/market_quote.py EURUSD`
- `python scripts/market_quote.py GBP-JPY`

### 3) Historical series (CSV to stdout)
Examples:
- `python scripts/market_series.py AAPL --days 30`
- `python scripts/market_series.py USD/ZAR --days 30`

### 4) Watchlist summary (local file)
- Add tickers: `python scripts/market_watchlist.py add AAPL MSFT USD/ZAR`
- Remove: `python scripts/market_watchlist.py remove MSFT`
- Show summary: `python scripts/market_watchlist.py summary`

---

# Output expectations (what you should return to the user)
- For quotes: price, change %, timestamp/source, and any caveats (like "FX updates daily").
- For series: confirm date range, number of points, and show a small preview (first/last few rows).
- If rate-limited: explain what happened and retry with backoff OR advise to reduce frequency.
- For Chinese markets: show both CN and US market data when relevant (e.g., ADR vs local)

---

# Safety / correctness
- Never claim "real-time" unless the provider is truly real-time. FX open access updates daily.
- Always cache responses and throttle repeated calls.
- **Tencent Finance API** is the primary provider for Chinese/US stocks - no rate limits observed
- If Tencent fails, fallback to yfinance or inform user of limitations

---

# Implementation Notes (2026-04-02)

## Primary Provider: Tencent Finance API
- **Endpoint**: `https://qt.gtimg.cn/q=<code>`
- **Encoding**: GBK (must decode properly)
- **Format**: `v_<code>="field0~field1~field2~..."`
- **No API key required**

## Symbol Mapping
| Asset | Tencent Code | Example |
|-------|-------------|---------|
| 沪深 300 | `sh000300` | `q=sh000300` |
| 纳斯达克 100 | `usNDX` | `q=usNDX` |
| COMEX 黄金 | `hf_GC` | `q=hf_GC` |
| 黄金 ETF | `sh518880` | `q=sh518880` |
| 美股 | `us<SYMBOL>` | `q=usAAPL` |
| A 股 | `sh<SYMBOL>` / `sz<SYMBOL>` | `q=sh600000` |
| 港股 | `hk<SYMBOL>` | `q=hk0700` (腾讯控股) |

## Gold Price Conversion
COMEX gold is quoted in **USD per troy ounce**. To convert to **CNY per gram**:
```python
price_cny = price_usd * exchange_rate / 31.1035
# exchange_rate ≈ 7.2 (USD/CNY)
# 1 troy ounce = 31.1035 grams
```
