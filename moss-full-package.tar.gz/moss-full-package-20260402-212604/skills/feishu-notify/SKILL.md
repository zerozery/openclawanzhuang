---
name: feishu-notify
description: 飞书消息推送技能。使用场景：(1) 发送文本消息到飞书聊天，(2) 推送通知到指定用户或群组，(3) 定时任务结果推送，(4) 告警消息发送
---

# 飞书消息推送

通过飞书机器人 API 发送消息。

## 快速开始

```bash
# 发送文本消息
curl -X POST "https://open.feishu.cn/open-apis/bot/v2/hook/YOUR_WEBHOOK" \
  -H "Content-Type: application/json" \
  -d '{"msg_type":"text","content":{"text":"Hello World"}}'
```

## 配置

在 `openclaw.json` 中配置飞书：

```json
{
  "channels": {
    "feishu": {
      "enabled": true,
      "appId": "cli_xxx",
      "appSecret": "xxx",
      "domain": "feishu",
      "groupPolicy": "open"
    }
  }
}
```

## 使用脚本

调用 `message` 工具发送消息：

```yaml
action: send
channel: feishu
to: "user:ou_xxx"  # 用户 ID 或群组 ID
message: "消息内容"
```

## 消息类型

### 文本消息
```json
{
  "msg_type": "text",
  "content": {
    "text": "纯文本消息"
  }
}
```

### Markdown 消息
```json
{
  "msg_type": "interactive",
  "card": {
    "elements": [{
      "tag": "markdown",
      "content": "**标题**\n内容详情"
    }]
  }
}
```

## 获取用户/群组 ID

使用 `feishu_app_scopes` 工具查看权限，然后调用飞书 API 获取。

## 错误处理

- 401: 认证失败，检查 appId/appSecret
- 403: 权限不足，检查应用权限
- 429: 频率限制，等待后重试
