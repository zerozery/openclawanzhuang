#!/bin/bash
# 飞书消息推送脚本
# 用法：./send_message.sh "消息内容" "接收者 ID"

MESSAGE=$1
RECEIVER=$2
WEBHOOK_URL="https://open.feishu.cn/open-apis/bot/v2/hook/YOUR_WEBHOOK_HERE"

if [ -z "$MESSAGE" ] || [ -z "$RECEIVER" ]; then
    echo "用法：$0 \"消息内容\" \"接收者 ID\""
    exit 1
fi

curl -X POST "$WEBHOOK_URL" \
  -H "Content-Type: application/json" \
  -d "{
    \"msg_type\": \"text\",
    \"content\": {
      \"text\": \"$MESSAGE\"
    }
  }"

echo ""
echo "✅ 消息已发送"
