#!/usr/bin/env python3
"""
小红书配图生成脚本
使用阿里通义万相 API 生成图片
"""

import requests
import time
import argparse
import os
import json
from datetime import datetime

# API 配置
API_KEY = os.getenv("DASHSCOPE_API_KEY", "sk-c32e9b41713d4b11b1157209ba7ff21f")
BASE_URL = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis"
TASK_URL = "https://dashscope.aliyuncs.com/api/v1/tasks/"

# 支持的尺寸
SIZES = {
    "1:1": "1024*1024",
    "3:4": "720*1280",
    "9:16": "1080*1920",
    "1024*1024": "1024*1024",
    "720*1280": "720*1280",
    "1080*1920": "1080*1920",
}

# 支持的风格
STYLES = [
    "3d cartoon", "anime", "oil painting", "watercolor", "sketch",
    "chinese painting", "flat illustration", "photography", "portrait", "auto"
]

def generate_image(prompt, style="auto", size="1024*1024", n=1):
    """
    生成图片（异步流程）
    
    Args:
        prompt: 提示词
        style: 风格
        size: 尺寸
        n: 生成数量
    
    Returns:
        list: 图片 URL 列表
    """
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
        "X-DashScope-Async": "enable"
    }
    
    data = {
        "model": "wanx2.1-t2i-turbo",
        "input": {
            "prompt": prompt
        },
        "parameters": {
            "style": style,
            "size": size,
            "n": n,
            "seed": int(time.time() * 1000) % (2**32)
        }
    }
    
    print(f"🎨 开始生成图片...")
    print(f"   提示词：{prompt}")
    print(f"   风格：{style}")
    print(f"   尺寸：{size}")
    
    # 提交任务
    resp = requests.post(BASE_URL, headers=headers, json=data)
    resp_json = resp.json()
    
    if resp.status_code != 200:
        print(f"❌ 提交失败：{resp_json}")
        return None
    
    task_id = resp_json.get("output", {}).get("task_id")
    if not task_id:
        print(f"❌ 未获取到 task_id: {resp_json}")
        return None
    
    print(f"✅ 任务已提交：{task_id}")
    
    # 轮询任务状态
    return poll_task(task_id)


def poll_task(task_id, timeout=300, interval=5):
    """
    轮询任务状态
    
    Args:
        task_id: 任务 ID
        timeout: 超时时间（秒）
        interval: 轮询间隔（秒）
    
    Returns:
        list: 图片 URL 列表
    """
    headers = {"Authorization": f"Bearer {API_KEY}"}
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        resp = requests.get(f"{TASK_URL}{task_id}", headers=headers)
        resp_json = resp.json()
        
        status = resp_json.get("output", {}).get("task_status", "")
        
        if status == "SUCCEEDED":
            print(f"✅ 生成成功！")
            results = resp_json.get("output", {}).get("results", [])
            urls = [r.get("url") for r in results if r.get("url")]
            return urls
        elif status == "FAILED":
            print(f"❌ 生成失败：{resp_json}")
            return None
        elif status in ["PENDING", "RUNNING"]:
            print(f"⏳ 生成中... ({int(time.time() - start_time)}s)")
            time.sleep(interval)
        else:
            print(f"⚠️ 未知状态：{status}")
            time.sleep(interval)
    
    print(f"❌ 超时：{timeout}秒")
    return None


def download_image(url, output_path=None):
    """
    下载图片
    
    Args:
        url: 图片 URL
        output_path: 输出路径
    
    Returns:
        str: 保存的文件路径
    """
    if not output_path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = f"/tmp/xhs_image_{timestamp}.png"
    
    print(f"📥 下载图片：{url}")
    resp = requests.get(url)
    
    with open(output_path, "wb") as f:
        f.write(resp.content)
    
    file_size = os.path.getsize(output_path)
    print(f"✅ 已保存：{output_path} ({file_size // 1024}KB)")
    
    return output_path


def optimize_prompt(base_prompt, theme=""):
    """
    优化提示词
    
    Args:
        base_prompt: 基础提示词
        theme: 主题（技术/学习/生活/艺术等）
    
    Returns:
        str: 优化后的提示词
    """
    templates = {
        "技术": "科技感，未来感，蓝色紫色渐变，简洁现代，{prompt}",
        "学习": "温馨学习氛围，暖色调，柔和光线，{prompt}",
        "生活": "生活化场景，自然光线，温暖治愈，{prompt}",
        "知识": "知识卡片背景，简约渐变，纯色，适合文字叠加，{prompt}",
        "艺术": "{prompt}",  # 艺术/武侠风格不添加前缀，保持原意
        "武侠": "{prompt}",  # 武侠风格不添加前缀
    }
    
    if theme and theme in templates:
        return templates[theme].format(prompt=base_prompt)
    
    return base_prompt


def main():
    parser = argparse.ArgumentParser(description="小红书配图生成")
    parser.add_argument("--prompt", "-p", required=True, help="提示词")
    parser.add_argument("--style", "-s", default="auto", choices=STYLES, help="风格")
    parser.add_argument("--size", default="1024*1024", help="尺寸")
    parser.add_argument("--theme", "-t", choices=["技术", "学习", "生活", "知识", "艺术", "武侠"], help="主题")
    parser.add_argument("--output", "-o", help="输出路径")
    parser.add_argument("--count", "-n", type=int, default=1, help="生成数量")
    
    args = parser.parse_args()
    
    # 优化提示词
    prompt = optimize_prompt(args.prompt, args.theme) if args.theme else args.prompt
    
    # 生成图片
    urls = generate_image(prompt, args.style, args.size, args.count)
    
    if not urls:
        print("❌ 生成失败")
        return 1
    
    # 下载图片
    paths = []
    for i, url in enumerate(urls):
        output = args.output if len(urls) == 1 else f"{args.output}_{i}" if args.output else None
        path = download_image(url, output)
        paths.append(path)
    
    print(f"\n🎉 完成！生成了 {len(paths)} 张图片")
    for path in paths:
        print(f"   - {path}")
    
    # 返回 JSON 结果（供工具调用）
    result = {
        "success": True,
        "images": paths,
        "prompt": prompt,
        "style": args.style,
        "size": args.size
    }
    print(f"\n{json.dumps(result, ensure_ascii=False, indent=2)}")
    
    return 0


if __name__ == "__main__":
    exit(main())
