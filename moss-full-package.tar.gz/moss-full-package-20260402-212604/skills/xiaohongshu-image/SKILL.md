---
name: xiaohongshu-image
description: 小红书配图生成技能。使用阿里通义万相 API 生成适合小红书的图片，支持多种尺寸（1:1/3:4/9:16）和风格（简约/科技/插画等）
---

# 小红书配图生成

使用阿里通义万相（Tongyi Wanxiang）API 为小红书笔记生成配图。

## 快速开始

```bash
# 生成图片
python3 ~/.openclaw/workspace/skills/xiaohongshu-image/scripts/generate.py \
  --prompt "AI 技术分享封面" \
  --style "flat illustration" \
  --size "1024*1024"
```

## 配置

API Key 存储在 `~/.openclaw/openclaw.json` 或环境变量：

```bash
export DASHSCOPE_API_KEY="sk-xxx"
```

## 支持的尺寸

| 比例 | 尺寸 | 用途 |
|------|------|------|
| 1:1 | 1024×1024 | 知识卡片、封面 |
| 3:4 | 720×1280 | 竖图封面（推荐） |
| 9:16 | 1080×1920 | 全屏背景 |

## 支持的风格

- `<3d cartoon>` - 3D 卡通
- `<anime>` - 动漫
- `<oil painting>` - 油画
- `<watercolor>` - 水彩
- `<sketch>` - 素描
- `<chinese painting>` - 国画
- `<flat illustration>` - 扁平插画（推荐）
- `<photography>` - 摄影
- `<portrait>` - 人像
- `<auto>` - 自动

## 使用示例

### 技术分享封面
```bash
python3 scripts/generate.py \
  --prompt "AI 人工智能技术分享封面，科技感，蓝色渐变" \
  --style "flat illustration" \
  --size "720*1280"
```

### 学习日常
```bash
python3 scripts/generate.py \
  --prompt "温馨的学习场景，可爱插画风格，暖色调" \
  --style "anime" \
  --size "1024*1024"
```

### 知识卡片背景
```bash
python3 scripts/generate.py \
  --prompt "简约渐变背景，纯色，适合文字叠加" \
  --style "auto" \
  --size "1024*1024"
```

## 输出

- 图片保存在 `/tmp/xhs_image_*.png`
- 返回图片路径供后续使用

## 错误处理

- API 限流：自动重试
- 生成失败：返回错误信息
- 网络问题：检查连接
