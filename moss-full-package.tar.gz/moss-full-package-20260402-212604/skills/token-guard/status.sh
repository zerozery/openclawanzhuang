#!/bin/bash
# Token Guard 状态检查

QUOTA_FILE="/root/.openclaw/workspace/skills/token-guard/quota.json"
CONFIG_FILE="/root/.openclaw/openclaw.json"

echo "=== Token Guard 状态 ==="
echo ""

# 读取配置
DAILY_LIMIT=$(jq -r '.tokenGuard.dailyLimit' "$CONFIG_FILE" 2>/dev/null || echo "100000")
CACHE_ENABLED=$(jq -r '.tokenGuard.cache.enabled' "$CONFIG_FILE" 2>/dev/null || echo "true")

# 读取使用情况
TODAY=$(date +%Y-%m-%d)
TOKENS_USED=$(jq -r ".dailyUsage[\"$TODAY\"].tokens // 0" "$QUOTA_FILE" 2>/dev/null || echo "0")
REQUESTS=$(jq -r ".dailyUsage[\"$TODAY\"].requests // 0" "$QUOTA_FILE" 2>/dev/null || echo "0")
CACHE_SIZE=$(jq -r '.cache | length' "$QUOTA_FILE" 2>/dev/null || echo "0")

echo "📊 今日使用"
echo "   Token: $TOKENS_USED / $DAILY_LIMIT"
echo "   请求数：$REQUESTS"
echo ""
echo "💾 缓存"
echo "   状态：$([ "$CACHE_ENABLED" = "true" ] && echo "✅ 启用" || echo "❌ 禁用")"
echo "   条目：$CACHE_SIZE"
echo ""
echo "🛡️ 保护"
echo "   状态：✅ 启用"
echo "   限额：$DAILY_LIMIT tokens/天"
echo ""

# 计算剩余
REMAINING=$((DAILY_LIMIT - TOKENS_USED))
PERCENT=$((TOKENS_USED * 100 / DAILY_LIMIT))

if [ $PERCENT -gt 90 ]; then
    echo "⚠️  警告：Token 用量已超过 ${PERCENT}%，剩余 $REMAINING"
elif [ $PERCENT -gt 70 ]; then
    echo "📈 Token 用量已达 ${PERCENT}%"
else
    echo "✅ Token 用量正常 (${PERCENT}%)"
fi
