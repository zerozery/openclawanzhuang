# Token Guard Skill

## 触发条件

当检测到以下情况时自动激活：

1. 短时间内多次 API 调用
2. Token 消耗接近限额
3. 重复相似的查询

## 核心逻辑

### 1. Token 估算

```javascript
function estimateTokens(text) {
  // 中文约 1.5 字符/token，英文约 4 字符/token
  const chinese = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
  const english = text.length - chinese;
  return Math.ceil(chinese / 1.5 + english / 4);
}
```

### 2. 配额跟踪

- 记录每日 Token 消耗
- 存储于 `~/.openclaw/token-guard/quota.json`
- 每日 0 点重置

### 3. 请求节流

- 限制每分钟请求数
- 超额时排队或拒绝

### 4. 响应缓存

- Key: 查询内容的 hash
- Value: LLM 响应 + 时间戳
- TTL: 1 小时（可配置）

## 配置项

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `enabled` | true | 是否启用 |
| `dailyLimit` | 100000 | 每日 Token 限额 |
| `requestLimit` | 10 | 每分钟请求数限制 |
| `windowMs` | 60000 | 节流窗口 (ms) |
| `cache.enabled` | true | 启用缓存 |
| `cache.ttl` | 3600 | 缓存 TTL (秒) |

## 文件结构

```
skills/token-guard/
├── README.md
├── SKILL.md
├── index.js (可选，自动化脚本)
└── quota.json (运行时生成)
```
