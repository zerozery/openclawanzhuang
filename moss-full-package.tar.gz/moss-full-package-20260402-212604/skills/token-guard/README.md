# Token Guard 🛡️

防止 LLM API Token 超额消耗，提供配额管理、请求节流和响应缓存。

## 功能

- **Token 估算** - 请求前估算 Token 数量
- **配额跟踪** - 跟踪 API 使用量
- **请求节流** - 避免短时间大量请求
- **响应缓存** - 相同请求返回缓存结果
- **自动降级** - 超额时切换到便宜模型

## 配置

在 `openclaw.json` 中添加：

```json
{
  "tokenGuard": {
    "enabled": true,
    "dailyLimit": 100000,
    "requestLimit": 10,
    "windowMs": 60000,
    "cache": {
      "enabled": true,
      "ttl": 3600
    }
  }
}
```

## 使用

自动生效，无需手动调用。

## 状态检查

```bash
openclaw token-guard status
```
