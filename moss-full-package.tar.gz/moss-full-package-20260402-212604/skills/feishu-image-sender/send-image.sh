#!/bin/bash
#
# 飞书图片发送脚本
# 用法：./send-image.sh --target "ou_xxx" --file "/path/to/image.png" [--message "描述"]
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=""
FILE=""
MESSAGE=""

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --target)
            TARGET="$2"
            shift 2
            ;;
        --file)
            FILE="$2"
            shift 2
            ;;
        --message)
            MESSAGE="$2"
            shift 2
            ;;
        --help)
            echo "用法：$0 --target <用户 ID> --file <图片路径> [--message <描述>]"
            echo ""
            echo "选项:"
            echo "  --target   飞书用户 ID (ou_xxx) 或群组 ID"
            echo "  --file     本地图片路径"
            echo "  --message  附带的文字消息（可选）"
            echo "  --help     显示帮助信息"
            exit 0
            ;;
        *)
            echo "未知参数：$1"
            echo "使用 --help 查看帮助"
            exit 1
            ;;
    esac
done

# 验证必填参数
if [[ -z "$TARGET" ]]; then
    echo "❌ 错误：--target 是必填参数"
    exit 1
fi

if [[ -z "$FILE" ]]; then
    echo "❌ 错误：--file 是必填参数"
    exit 1
fi

if [[ ! -f "$FILE" ]]; then
    echo "❌ 错误：文件不存在：$FILE"
    exit 1
fi

# 检测操作系统并选择正确的 base64 命令
detect_base64_cmd() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "base64 -i"
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        echo "base64 -w 0"
    else
        if base64 -i /dev/null 2>/dev/null; then
            echo "base64 -i"
        else
            echo "base64 -w 0"
        fi
    fi
}

BASE64_CMD=$(detect_base64_cmd)

# 获取文件 MIME 类型
get_content_type() {
    local file="$1"
    local ext="${file##*.}"
    case "$ext" in
        png|PNG) echo "image/png" ;;
        jpg|jpeg|JPG|JPEG) echo "image/jpeg" ;;
        gif|GIF) echo "image/gif" ;;
        webp|WEBP) echo "image/webp" ;;
        *)
            if command -v file &> /dev/null; then
                local mime=$(file -b --mime-type "$file")
                if [[ "$mime" == image/* ]]; then
                    echo "$mime"
                    return
                fi
            fi
            echo "image/png"
            ;;
    esac
}

CONTENT_TYPE=$(get_content_type "$FILE")
FILENAME=$(basename "$FILE")

echo "📸 准备发送图片到飞书..."
echo "   目标：$TARGET"
echo "   文件：$FILENAME"
echo "   类型：$CONTENT_TYPE"
[[ -n "$MESSAGE" ]] && echo "   消息：$MESSAGE"

BASE64_DATA=$($BASE64_CMD "$FILE")

CMD="openclaw message send --channel feishu --target \"$TARGET\" --buffer \"$BASE64_DATA\" --filename \"$FILENAME\" --content-type \"$CONTENT_TYPE\""
[[ -n "$MESSAGE" ]] && CMD="$CMD --message \"$MESSAGE\""

echo "🚀 发送中..."
eval $CMD

if [[ $? -eq 0 ]]; then
    echo "✅ 图片发送成功！"
else
    echo "❌ 发送失败，请检查飞书配置和网络连接"
    exit 1
fi
