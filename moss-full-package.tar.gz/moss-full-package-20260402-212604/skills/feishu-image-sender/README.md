# 飞书图片发送 Skill

通过飞书 API 发送本地图片到指定用户或群组。

## 🚀 快速安装

```bash
git clone https://github.com/zerozery/feishu-image-sender.git
cd feishu-image-sender
chmod +x send-image.sh
```

## 📸 使用

### 发送图片
```bash
./send-image.sh --target "ou_xxx" --file "/path/to/image.png"
```

### 发送带描述的图片
```bash
./send-image.sh --target "ou_xxx" --file "/path/to/image.png" --message "这是图片描述"
```

### 查看帮助
```bash
./send-image.sh --help
```

## ⚙️ 配置

确保 `openclaw.json` 中飞书通道已配置：

```json
{
  "channels": {
    "feishu": {
      "enabled": true,
      "appId": "cli_xxx",
      "appSecret": "xxx"
    }
  }
}
```

## 📋 参数说明

| 参数 | 说明 | 必填 |
|------|------|------|
| `--target` | 飞书用户 ID (ou_xxx) 或群组 ID | ✅ |
| `--file` | 本地图片路径 | ✅ |
| `--message` | 附带文字消息 | ❌ |

## 🖼️ 支持格式

- PNG (`image/png`)
- JPEG (`image/jpeg`)
- GIF (`image/gif`)
- WebP (`image/webp`)

## 🔧 故障排查

### 发送失败
1. 检查飞书应用配置（appId/appSecret）
2. 确认用户 ID 正确
3. 检查网络连接

### 图片无法显示
1. 确认文件格式正确
2. 检查文件大小（飞书限制 20MB）
3. 尝试转换为 PNG 格式

## 📄 许可证

MIT
