#!/usr/bin/env python3
"""
飞书图片发送 - 使用飞书官方 API 的 image 消息类型
确保图片直接显示而不是附件

用法：
    python3 send_feishu_image.py <图片路径> <用户 ID> [消息]
"""
import requests
import json
import sys
import os

# 飞书应用配置
APP_ID = os.getenv('FEISHU_APP_ID', 'cli_a92ae27e36385cc2')
APP_SECRET = os.getenv('FEISHU_APP_SECRET', 'AMzY9W7kiXWRdhWnr1FBDem0mv4E8LNw')
BASE_URL = "https://open.feishu.cn/open-apis"


def send_image_feishu(image_path, target_user, message=""):
    """
    通过飞书 API 发送图片（使用 image 消息类型）
    
    步骤：
    1. 获取 tenant_access_token
    2. 上传图片获取 image_key
    3. 发送 image 类型消息
    """
    # 1. 获取 token
    print("🔄 获取访问令牌...")
    token_resp = requests.post(
        f"{BASE_URL}/auth/v3/tenant_access_token/internal/",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}
    )
    token_data = token_resp.json()
    
    if token_data.get('code') != 0:
        print(f"❌ 获取 token 失败：{token_data}")
        return False
    
    token = token_data['tenant_access_token']
    headers = {"Authorization": f"Bearer {token}"}
    
    # 2. 上传图片获取 image_key
    print(f"📸 上传图片：{os.path.basename(image_path)}")
    with open(image_path, 'rb') as f:
        image_resp = requests.post(
            f"{BASE_URL}/im/v1/images",
            headers=headers,
            files={'image': f},
            data={'image_type': 'message'}
        )
    
    image_data = image_resp.json()
    if image_data.get('code') != 0:
        print(f"❌ 上传图片失败：{image_data}")
        return False
    
    image_key = image_data['data']['image_key']
    print(f"✅ 图片上传成功，image_key: {image_key}")
    
    # 3. 发送图片消息（使用 image 类型）
    print(f"📤 发送给用户：{target_user}")
    
    content = json.dumps({"image_key": image_key})
    
    message_resp = requests.post(
        f"{BASE_URL}/im/v1/messages",
        headers=headers,
        params={'receive_id_type': 'open_id'},
        json={
            "receive_id": target_user,
            "content": content,
            "msg_type": "image"
        }
    )
    
    message_data = message_resp.json()
    if message_data.get('code') != 0:
        print(f"❌ 发送消息失败：{message_data}")
        return False
    
    print(f"✅ 图片发送成功！message_id: {message_data['data']['message_id']}")
    
    # 如果有附加消息，再发一条文字消息
    if message:
        text_resp = requests.post(
            f"{BASE_URL}/im/v1/messages",
            headers=headers,
            params={'receive_id_type': 'open_id'},
            json={
                "receive_id": target_user,
                "content": json.dumps({"text": message}),
                "msg_type": "text"
            }
        )
        if text_resp.json().get('code') == 0:
            print(f"✅ 附加消息已发送")
    
    return True


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("用法：python3 send_feishu_image.py <图片路径> <用户 ID> [消息]")
        print()
        print("示例:")
        print("  python3 send_feishu_image.py image.png ou_xxx")
        print("  python3 send_feishu_image.py image.png ou_xxx '这是图片描述'")
        sys.exit(1)
    
    image_path = sys.argv[1]
    target_user = sys.argv[2]
    message = sys.argv[3] if len(sys.argv) > 3 else ""
    
    if not os.path.exists(image_path):
        print(f"❌ 文件不存在：{image_path}")
        sys.exit(1)
    
    success = send_image_feishu(image_path, target_user, message)
    sys.exit(0 if success else 1)
