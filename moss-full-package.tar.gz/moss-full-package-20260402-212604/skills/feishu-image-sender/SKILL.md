---
name: feishu-image-sender
description: 飞书图片发送技能。当用户要求发送图片、发图、传图、分享图片时自动触发。使用飞书官方 API 的 image 消息类型，确保图片直接显示而不是附件。
metadata: {"clawdbot":{"emoji":"📸"}}
triggers:
  - 发送图片
  - 发图片
  - 发图
  - 传图片
  - 传图
  - 分享图片
  - 发张照片
  - 发个图片
  - 把图片发
  - 图片发我
  - 图片发你
  - 飞书图片
  - 飞书发图
  - 发送图片到飞书
  - feishu image
  - 飞书图片发送
  - send image
  - send photo
priority: 95
---

# 飞书图片发送

通过飞书官方 API 发送本地图片到指定用户或群组，**使用 image 消息类型确保图片直接显示**。

## 自动触发场景

当用户说以下话时，本技能会自动触发：
- "发送图片"、"发图片"、"发图"、"传图片"
- "分享图片"、"发张照片"、"发个图片"
- "把图片发我"、"图片发你"
- "飞书图片"、"飞书发图"

## 快速使用

### 方式 1：使用 Python 脚本（推荐）

```bash
python3 scripts/send_feishu_image.py <图片路径> <用户 ID> [消息]

# 示例
python3 scripts/send_feishu_image.py image.png ou_xxx
python3 scripts/send_feishu_image.py image.png ou_xxx "这是图片描述"
```

### 方式 2：直接调用 API

```python
import requests
import json

# 1. 获取 token
token = requests.post(
    "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal/",
    json={"app_id": "cli_xxx", "app_secret": "xxx"}
).json()['tenant_access_token']

headers = {"Authorization": f"Bearer {token}"}

# 2. 上传图片获取 image_key
with open('image.png', 'rb') as f:
    image_key = requests.post(
        "https://open.feishu.cn/open-apis/im/v1/images",
        headers=headers,
        files={'image': f},
        data={'image_type': 'message'}
    ).json()['data']['image_key']

# 3. 发送 image 类型消息
requests.post(
    "https://open.feishu.cn/open-apis/im/v1/messages",
    headers=headers,
    params={'receive_id_type': 'open_id'},
    json={
        "receive_id": "ou_xxx",
        "content": json.dumps({"image_key": image_key}),
        "msg_type": "image"  # ⚠️ 关键：使用 image 类型
    }
)
```

## ⚠️ 重要：为什么用 image 类型

**错误方式**（会变成附件 📎）：
```python
# ❌ 使用 media 参数或 base64
openclaw message send --media image.png --content-type image/png
```

**正确方式**（直接显示图片）：
```python
# ✅ 使用 image 消息类型
{
    "msg_type": "image",
    "content": {"image_key": "img_xxx"}
}
```

## 配置

飞书应用配置在 `~/.openclaw/openclaw.json`：

```json
{
  "channels": {
    "feishu": {
      "enabled": true,
      "appId": "cli_xxx",
      "appSecret": "xxx",
      "domain": "feishu",
      "groupPolicy": "open"
    }
  }
}
```

## 参数说明

| 参数 | 说明 | 必填 |
|------|------|------|
| 图片路径 | 本地图片文件路径 | ✅ |
| 用户 ID | 飞书用户 ID (ou_xxx) 或群组 ID | ✅ |
| 消息 | 附加文字消息（单独发送） | ❌ |

## 支持的图片格式

- PNG (`image/png`)
- JPEG (`image/jpeg`)
- GIF (`image/gif`)
- WebP (`image/webp`)

**建议**：图片大小控制在 5MB 以内，过大可能上传失败。

## 完整示例

```bash
# 发送图片
python3 scripts/send_feishu_image.py /tmp/image.png ou_387beeed74b9770a92c3d8705f25280b

# 发送带描述的图片
python3 scripts/send_feishu_image.py photo.jpg ou_xxx "这是今天的照片"

# 在 Python 代码中使用
from send_feishu_image import send_image_feishu
send_image_feishu("image.png", "ou_xxx", "图片描述")
```

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| code: 10014 | app_id 不存在 | 检查配置中的 appId |
| code: 99991663 | 图片过大 | 压缩图片到 5MB 以内 |
| code: 99991661 | 无权限 | 检查应用权限设置 |
| 网络错误 | 连接超时 | 检查网络连接 |

## 与 OpenClaw message 工具的区别

| 特性 | 本技能 | message 工具 |
|------|--------|-------------|
| 消息类型 | image | file/attachment |
| 显示效果 | 直接显示图片 | 显示为附件 📎 |
| 推荐场景 | 图片分享 | 文件传输 |

**结论**：发送图片请用本技能，不要用 message 工具的 media 参数。

---

*📸 技能由 MOSS 维护，使用飞书官方 image 消息 API*
