---
name: remind-me
description: 智能提醒技能。支持一次性提醒、周期性提醒、基于时间的提醒。可设置、查询、取消提醒。
---

# 提醒助手

设置和管理提醒事项。

## 快速开始

```bash
# 设置提醒
python3 scripts/remind.py "明天早上 9 点开会" --time "2026-03-03 09:00"

# 查看所有提醒
python3 scripts/remind.py --list

# 取消提醒
python3 scripts/remind.py --cancel <id>
```

## 使用场景

1. **一次性提醒** - 会议、约会、截止日期
2. **周期性提醒** - 每天/每周/每月重复
3. **相对时间提醒** - "30 分钟后"、"2 小时后"

## 提醒存储

提醒保存在 `~/.openclaw/workspace/memory/reminders.json`

## 推送方式

- 飞书消息
- 系统通知
- 邮件（可选）
