#!/usr/bin/env python3
"""
提醒管理脚本
支持一次性提醒、周期性提醒
"""

import json
import os
import sys
from datetime import datetime, timedelta
import argparse

REMINDERS_FILE = os.path.expanduser("~/.openclaw/workspace/memory/reminders.json")

def load_reminders():
    """加载提醒列表"""
    if not os.path.exists(REMINDERS_FILE):
        return []
    with open(REMINDERS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_reminders(reminders):
    """保存提醒列表"""
    os.makedirs(os.path.dirname(REMINDERS_FILE), exist_ok=True)
    with open(REMINDERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(reminders, f, ensure_ascii=False, indent=2)

def add_reminder(message, time_str, repeat=None):
    """添加提醒"""
    reminders = load_reminders()
    
    # 解析时间
    if time_str.startswith('+'):
        # 相对时间，如 +30m, +2h
        minutes = int(time_str[1:].replace('m', '').replace('h', '0').replace('d', '00'))
        if 'h' in time_str:
            minutes = int(time_str[1:].replace('h', '')) * 60
        elif 'd' in time_str:
            minutes = int(time_str[1:].replace('d', '')) * 24 * 60
        remind_time = datetime.now() + timedelta(minutes=minutes)
    else:
        # 绝对时间
        remind_time = datetime.strptime(time_str, "%Y-%m-%d %H:%M")
    
    reminder = {
        "id": len(reminders) + 1,
        "message": message,
        "time": remind_time.strftime("%Y-%m-%d %H:%M"),
        "repeat": repeat,
        "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "status": "pending"
    }
    
    reminders.append(reminder)
    save_reminders(reminders)
    
    print(f"✅ 提醒已设置：{message}")
    print(f"   时间：{remind_time.strftime('%Y-%m-%d %H:%M')}")
    if repeat:
        print(f"   重复：{repeat}")
    
    return reminder

def list_reminders():
    """列出所有提醒"""
    reminders = load_reminders()
    
    if not reminders:
        print("📭 暂无提醒")
        return
    
    print(f"📋 提醒列表 (共 {len(reminders)} 条)\n")
    
    for r in reminders:
        status_icon = "⏰" if r["status"] == "pending" else "✅" if r["status"] == "done" else "❌"
        print(f"{status_icon} #{r['id']} - {r['message']}")
        print(f"   时间：{r['time']}")
        if r.get('repeat'):
            print(f"   重复：{r['repeat']}")
        print()

def cancel_reminder(reminder_id):
    """取消提醒"""
    reminders = load_reminders()
    
    for r in reminders:
        if r["id"] == reminder_id:
            r["status"] = "cancelled"
            save_reminders(reminders)
            print(f"✅ 提醒已取消：{r['message']}")
            return
    
    print(f"❌ 未找到提醒 #{reminder_id}")

def check_due_reminders():
    """检查到期的提醒"""
    reminders = load_reminders()
    now = datetime.now()
    due_reminders = []
    
    for r in reminders:
        if r["status"] != "pending":
            continue
        
        remind_time = datetime.strptime(r["time"], "%Y-%m-%d %H:%M")
        if remind_time <= now:
            due_reminders.append(r)
            r["status"] = "done"
            
            # 如果是周期性提醒，创建下一个
            if r.get("repeat"):
                next_time = calculate_next_time(remind_time, r["repeat"])
                new_reminder = {
                    "id": len(reminders) + 1,
                    "message": r["message"],
                    "time": next_time.strftime("%Y-%m-%d %H:%M"),
                    "repeat": r["repeat"],
                    "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "status": "pending"
                }
                reminders.append(new_reminder)
    
    save_reminders(reminders)
    return due_reminders

def calculate_next_time(current, repeat):
    """计算下次提醒时间"""
    if repeat == "daily":
        return current + timedelta(days=1)
    elif repeat == "weekly":
        return current + timedelta(weeks=1)
    elif repeat == "monthly":
        return current.replace(day=current.day + 1)  # 简化处理
    return current

def main():
    parser = argparse.ArgumentParser(description="提醒管理")
    parser.add_argument("message", nargs="?", help="提醒内容")
    parser.add_argument("--time", "-t", help="提醒时间 (YYYY-MM-DD HH:MM 或 +30m/+2h/+1d)")
    parser.add_argument("--repeat", "-r", choices=["daily", "weekly", "monthly"], help="重复周期")
    parser.add_argument("--list", "-l", action="store_true", help="列出所有提醒")
    parser.add_argument("--cancel", "-c", type=int, help="取消提醒 ID")
    parser.add_argument("--check", action="store_true", help="检查到期提醒")
    
    args = parser.parse_args()
    
    if args.list:
        list_reminders()
    elif args.cancel:
        cancel_reminder(args.cancel)
    elif args.check:
        due = check_due_reminders()
        if due:
            print(f"⏰ 到期提醒 ({len(due)} 条):")
            for r in due:
                print(f"   - {r['message']}")
        else:
            print("✅ 无到期提醒")
    elif args.message and args.time:
        add_reminder(args.message, args.time, args.repeat)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
