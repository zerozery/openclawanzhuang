#!/bin/bash
# Media Analyzer 安装脚本

echo "🌿 正在安装 Media Analyzer 技能..."

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPTS_DIR="$SKILL_DIR/scripts"

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 未找到 Python3，请先安装 Python 3.8+"
    exit 1
fi

echo "✅ Python 版本：$(python3 --version)"

# 安装依赖
echo ""
echo "📦 正在安装 Python 依赖..."

# 可选：创建虚拟环境
# python3 -m venv "$SKILL_DIR/venv"
# source "$SKILL_DIR/venv/bin/activate"

pip3 install -r "$SKILL_DIR/requirements.txt"

if [ $? -eq 0 ]; then
    echo "✅ 依赖安装完成！"
else
    echo "❌ 依赖安装失败，请检查网络或手动安装"
    exit 1
fi

# 设置脚本权限
echo ""
echo "🔧 设置脚本执行权限..."
chmod +x "$SCRIPTS_DIR"/*.py

# 测试安装
echo ""
echo "🧪 测试安装..."

# 测试 EasyOCR
python3 -c "import easyocr; print('✅ EasyOCR OK')" 2>/dev/null || echo "⚠️ EasyOCR 安装失败"

# 测试 youtube-transcript-api
python3 -c "from youtube_transcript_api import YouTubeTranscriptApi; print('✅ YouTube Transcript OK')" 2>/dev/null || echo "⚠️ YouTube Transcript 安装失败"

# 测试 whisper-timestamped
python3 -c "import whisper_timestamped; print('✅ Whisper OK')" 2>/dev/null || echo "⚠️ Whisper 安装失败（可选）"

echo ""
echo "=========================================="
echo "🎉 Media Analyzer 安装完成！"
echo "=========================================="
echo ""
echo "📚 使用方法："
echo ""
echo "  # OCR 文字提取"
echo "  python3 $SCRIPTS_DIR/ocr_extract.py <图片路径>"
echo ""
echo "  # YouTube 字幕提取"
echo "  python3 $SCRIPTS_DIR/video_subtitle.py --youtube <URL>"
echo ""
echo "  # 本地视频转录"
echo "  python3 $SCRIPTS_DIR/video_subtitle.py --file <视频路径>"
echo ""
echo "=========================================="
echo ""
