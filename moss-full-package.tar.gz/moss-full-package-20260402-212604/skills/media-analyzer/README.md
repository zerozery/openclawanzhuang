# Media Analyzer 🌿

图像和视频内容分析技能 - 让 AI 能从视觉内容中学习

**当前版本**: v0.3  
**最后更新**: 2026-03-07

---

## 🚀 快速开始

### 1. 一键解析视频（推荐）

```bash
cd ~/.openclaw/workspace/skills/media-analyzer

# 抖音视频
python3 scripts/parse_video.py --douyin "https://v.douyin.com/xxx/"

# YouTube 视频
python3 scripts/parse_video.py --youtube "https://youtube.com/watch?v=xxx"

# 本地视频
python3 scripts/parse_video.py --file video.mp4
```

**自动完成**：下载 → 转录 → 分析 → 生成笔记

---

## 📚 功能说明

### 一键解析脚本 ⭐

`parse_video.py` 是推荐使用的一站式工具：

```bash
# 基础用法
python3 scripts/parse_video.py --douyin "https://v.douyin.com/Cpg_xm7YOPc/"

# 指定 Whisper 模型
python3 scripts/parse_video.py --douyin "URL" --model small

# 指定输出目录
python3 scripts/parse_video.py --douyin "URL" --output ~/Videos/

# 保留视频文件
python3 scripts/parse_video.py --douyin "URL" --keep

# JSON 输出
python3 scripts/parse_video.py --douyin "URL" --json
```

**输出内容**：
- 📁 工作目录（包含所有中间文件）
- 📄 学习笔记（JSON 格式）
- 📝 内容摘要（终端显示）

---

### 分步操作

#### 下载视频
```bash
python3 scripts/download_douyin.py "https://v.douyin.com/xxx/"
python3 scripts/download_douyin.py "URL" --output video.mp4
```

#### 提取字幕
```bash
# YouTube 字幕
python3 scripts/video_subtitle.py --youtube "URL"
python3 scripts/video_subtitle.py --youtube "URL" --output subs.srt

# 本地视频转录
python3 scripts/video_subtitle.py --file video.mp4
python3 scripts/video_subtitle.py --file video.mp4 --model small
```

#### 分析内容
```bash
python3 scripts/analyze_video.py --subtitle subs.srt
python3 scripts/analyze_video.py --subtitle subs.srt --simple
```

#### OCR 识别
```bash
python3 scripts/ocr_extract.py image.jpg
python3 scripts/ocr_extract.py image.jpg --json
```

---

## 🎯 使用场景

### 场景 1：学习抖音教程
```bash
python3 scripts/parse_video.py --douyin "https://v.douyin.com/xxx/"
```
→ 自动生成学习笔记，包含关键词、关键点、时间线

### 场景 2：提取会议记录
```bash
python3 scripts/parse_video.py --file meeting.mp4 --output ~/Meetings/
```
→ 生成会议纪要和待办事项

### 场景 3：识别截图文字
```bash
python3 scripts/ocr_extract.py error_screenshot.png
```
→ 提取错误信息，方便搜索解决方案

### 场景 4：YouTube 视频学习
```bash
python3 scripts/parse_video.py --youtube "https://youtube.com/watch?v=xxx"
```
→ 提取字幕 + 生成总结

---

## ⚙️ 配置选项

### Whisper 模型选择

| 模型 | 速度 | 准确度 | 推荐场景 |
|------|------|--------|----------|
| tiny | 最快 | 一般 | 快速测试 |
| base | 快 | 好 | 日常使用 ⭐ |
| small | 中等 | 很好 | 重要内容 |
| medium | 慢 | 优秀 | 专业需求 |

```bash
python3 scripts/parse_video.py --douyin "URL" --model small
```

### 输出控制

```bash
# 保留视频文件
python3 scripts/parse_video.py --douyin "URL" --keep

# 指定输出目录
python3 scripts/parse_video.py --douyin "URL" --output ~/Videos/

# JSON 输出（便于程序处理）
python3 scripts/parse_video.py --douyin "URL" --json
```

---

## 📁 文件结构

```
media-analyzer/
├── SKILL.md              # 技能说明（AI 读取）
├── README.md             # 人类可读文档
├── requirements.txt      # Python 依赖
├── install.sh            # 安装脚本
└── scripts/
    ├── parse_video.py         # ⭐ 一键解析（推荐）
    ├── learn_from_video.py    # 完整学习工作流
    ├── download_douyin.py     # 抖音视频下载
    ├── video_subtitle.py      # 字幕提取/转录
    ├── ocr_extract.py         # OCR 文字识别
    └── analyze_video.py       # 内容分析总结
```

---

## 🔄 更新日志

### v0.3 (2026-03-07)
- ✅ 新增 `parse_video.py` 一键解析脚本
- ✅ 整合下载、转录、分析流程
- ✅ 支持 JSON 输出
- ✅ 优化终端显示

### v0.2 (2026-03-07)
- ✅ 新增抖音视频下载
- ✅ 新增一键学习工作流
- ✅ 新增内容分析总结

### v0.1 (2026-03-06)
- ✅ 基础 OCR 功能
- ✅ YouTube 字幕提取

---

## ⚠️ 常见问题

### Q: 抖音视频下载失败？
A: 可能原因：
- 视频需要 cookies 认证
- 链接格式不正确
- 网络问题

**解决方案**：
1. 手动下载视频后使用 `--file` 参数
2. 尝试不同的链接格式

### Q: Whisper 转录很慢？
A: 这是正常的。建议使用 `base` 或 `small` 模型平衡速度和质量。

90 秒视频转录时间参考：
- tiny: ~10 秒
- base: ~20 秒
- small: ~40 秒
- medium: ~90 秒

### Q: OCR 识别不准确？
A: 尝试：
- 确保图片清晰
- 调整图片对比度
- 使用高分辨率截图

### Q: 输出内容太长？
A: 使用 `--simple` 参数或查看 JSON 输出：
```bash
python3 scripts/analyze_video.py --subtitle subs.srt --simple
```

---

## 📊 性能参考

**测试环境**: 云服务器（CPU）

| 任务 | 耗时 |
|------|------|
| 下载 90 秒抖音视频 | ~10 秒 |
| Whisper 转录（base） | ~20 秒 |
| 内容分析 | ~2 秒 |
| **总计** | **~32 秒** |

---

## 📚 学习资源

- [EasyOCR 文档](https://github.com/JaidedAI/EasyOCR)
- [Whisper 官方文档](https://github.com/openai/whisper)
- [yt-dlp 使用说明](https://github.com/yt-dlp/yt-dlp)
- [youtube-transcript-api](https://github.com/jdepoix/youtube-transcript-api)

---

*🌿 技能由 MOSS 创建和维护*
