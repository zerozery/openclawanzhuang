---
name: media-analyzer
description: 图像和视频内容分析技能。支持 OCR 文字识别、抖音/YouTube 视频下载、语音转录、内容总结、学习笔记生成。用于从图片和视频中提取知识、学习视频内容。
---

# Media Analyzer - 图像视频分析技能

> 🌿 持续迭代中 | 目标：让 AI 能从视觉内容中学习

---

## 🚀 快速使用（推荐）

### 一键解析视频
```bash
# 抖音视频
python3 scripts/parse_video.py --douyin "https://v.douyin.com/xxx/"

# YouTube 视频
python3 scripts/parse_video.py --youtube "https://youtube.com/watch?v=xxx"

# 本地视频
python3 scripts/parse_video.py --file video.mp4

# 指定输出目录
python3 scripts/parse_video.py --douyin "URL" --output ~/Videos/
```

**自动完成**：
1. ✅ 下载视频
2. ✅ 语音转录（Whisper）
3. ✅ 内容分析
4. ✅ 生成学习笔记

---

## 核心能力

### 🖼️ 图像分析
1. **OCR 文字识别** - 从图片提取文字（支持中文/英文）
2. **图像内容理解** - 描述图片内容、场景、物体
3. **图表分析** - 解读数据图表、流程图
4. **截图分析** - 理解界面截图、操作步骤

### 🎬 视频分析
1. **视频下载** - 支持抖音、YouTube 等平台
2. **字幕提取** - 下载在线字幕或本地转录
3. **语音转文字** - Whisper 语音识别
4. **内容总结** - 生成视频内容摘要
5. **知识点提取** - 从教学视频提取结构化知识
6. **学习笔记** - 自动生成学习记录

---

## 使用场景

### 图像分析
- 用户发送截图 → 分析界面/操作步骤
- 用户发送文档照片 → OCR 提取文字
- 用户发送图表 → 解读数据趋势
- 用户发送代码截图 → 识别并解释代码

### 视频学习
- 用户发送抖音链接 → 下载 + 提取字幕 + 总结
- 用户发送 YouTube 链接 → 提取字幕 + 总结内容
- 用户发送教学视频 → 提取知识点和步骤
- 用户发送会议录像 → 生成会议纪要
- 用户发送课程视频 → 整理学习笔记

---

## 脚本工具

| 脚本 | 功能 | 状态 |
|------|------|------|
| `parse_video.py` | ⭐ 一键解析（推荐） | ✅ 完成 |
| `learn_from_video.py` | 完整学习工作流 | ✅ 完成 |
| `download_douyin.py` | 抖音视频下载 | ✅ 完成 |
| `video_subtitle.py` | 字幕提取/转录 | ✅ 完成 |
| `ocr_extract.py` | OCR 文字识别 | ✅ 完成 |
| `analyze_video.py` | 内容分析总结 | ✅ 完成 |

---

## 详细用法

### 1. 一键解析（parse_video.py）

**最简单的方式**，自动完成所有步骤：

```bash
# 基础用法
python3 scripts/parse_video.py --douyin "https://v.douyin.com/Cpg_xm7YOPc/"

# 指定 Whisper 模型（base/small/medium）
python3 scripts/parse_video.py --douyin "URL" --model small

# 指定输出目录
python3 scripts/parse_video.py --douyin "URL" --output ~/Videos/

# 保留视频文件
python3 scripts/parse_video.py --douyin "URL" --keep

# JSON 输出
python3 scripts/parse_video.py --douyin "URL" --json
```

**输出内容**：
- 📁 工作目录（包含视频、字幕、笔记）
- 📄 学习笔记（JSON 格式）
- 📝 终端显示内容摘要

---

### 2. 分步操作

#### 下载视频
```bash
python3 scripts/download_douyin.py "https://v.douyin.com/xxx/"
```

#### 提取字幕
```bash
# YouTube 字幕
python3 scripts/video_subtitle.py --youtube "URL"

# 本地视频转录
python3 scripts/video_subtitle.py --file video.mp4 --output subs.srt
```

#### 分析内容
```bash
python3 scripts/analyze_video.py --subtitle subs.srt --simple
```

#### OCR 识别
```bash
python3 scripts/ocr_extract.py image.jpg
```

---

## 视频学习工作流

```
用户发送视频链接
       ↓
1. 下载视频（yt-dlp 或 直接下载）
       ↓
2. Whisper 语音转录
       ↓
3. 解析字幕（SRT 格式）
       ↓
4. 内容分段 + 关键词提取
       ↓
5. 生成总结 + 知识点
       ↓
6. 输出学习笔记
```

---

## 依赖安装

```bash
# 进入技能目录
cd ~/.openclaw/workspace/skills/media-analyzer

# 安装所有依赖
pip install -r requirements.txt

# 或单独安装
pip install easyocr yt-dlp whisper-timestamped youtube-transcript-api
```

**系统依赖**：
```bash
# Ubuntu/Debian
sudo apt-get install -y ffmpeg

# CentOS/RHEL
sudo yum install -y ffmpeg
```

---

## 配置说明

### Whisper 模型选择

| 模型 | 速度 | 准确度 | 推荐场景 |
|------|------|--------|----------|
| tiny | 最快 | 一般 | 快速测试 |
| base | 快 | 好 | 日常使用 ⭐ |
| small | 中等 | 很好 | 重要内容 |
| medium | 慢 | 优秀 | 专业需求 |

```bash
python3 scripts/parse_video.py --douyin "URL" --model small
```

### 输出控制

```bash
# 保留视频文件
python3 scripts/parse_video.py --douyin "URL" --keep

# 指定输出目录
python3 scripts/parse_video.py --douyin "URL" --output ~/Videos/

# JSON 输出（便于程序处理）
python3 scripts/parse_video.py --douyin "URL" --json
```

---

## 输出示例

### 终端输出
```
======================================================================
  步骤 1: 下载视频
======================================================================
🔄 尝试使用 yt-dlp 下载...
✅ 视频流下载成功 (19.0MB)

======================================================================
  步骤 2: 语音转录
======================================================================
🔄 正在转录语音（模型：base）...
✅ 转录完成（358 字）

======================================================================
  步骤 3: 内容分析
======================================================================
🔍 正在分析视频内容...

============================================================
📊 视频内容总结
============================================================

视频共 3 个片段，主要内容包括：AI、胡金铨、电影美学...

🔑 关键词：AI, 电影，胡金铨，武侠，美学

📌 关键点：
  1. [00:00:05] 今天教大家用 AI 复刻胡金铨导演...
  2. [00:00:15] 第一步，打开 Midjourney...
  3. [00:00:30] 风格关键词：武侠、水墨...
============================================================

======================================================================
  ✅ 解析完成！
======================================================================

📁 工作目录：/tmp/video_parse_20260307_220000
📄 学习笔记：/tmp/video_parse_20260307_220000/learning_notes.json
📝 字幕文件：/tmp/video_parse_20260307_220000/subtitles.srt
```

### JSON 输出
```json
{
  "success": true,
  "source_url": "https://v.douyin.com/xxx/",
  "platform": "douyin",
  "created_at": "2026-03-07T22:00:00",
  "work_dir": "/tmp/video_parse_xxx",
  "steps": {
    "download": true,
    "transcribe": true,
    "analyze": true
  },
  "full_text": "为什么你的 AI 视频没有胡金铨电影的空灵肃杀感...",
  "analysis": "视频共 3 个片段，主要内容包括：AI、胡金铨、电影美学..."
}
```

---

## 迭代计划

### ✅ v0.3（当前版本）
- [x] 一键解析脚本
- [x] 抖音视频下载
- [x] Whisper 语音转录
- [x] 内容分析总结
- [x] 学习笔记生成

### 🔄 v0.4（下一步）
- [ ] B 站视频支持
- [ ] YouTube 字幕直接下载
- [ ] 关键帧提取
- [ ] 多模态图像理解

### 📅 v1.0（目标）
- [ ] 知识库集成
- [ ] 跨视频知识关联
- [ ] 问答式学习
- [ ] 代码截图识别

---

## 注意事项

1. **抖音下载** - 部分视频需要 cookies 才能下载，失败时可手动下载后使用 `--file` 分析
2. **转录时间** - Whisper 转录速度与视频长度成正比（90 秒视频约 20-30 秒）
3. **隐私保护** - 本地处理优先，临时文件默认清理
4. **版权尊重** - 视频内容仅用于个人学习

---

## 常见问题

### Q: 抖音视频下载失败？
A: 部分视频需要 cookies。可以：
1. 手动下载视频后使用 `--file` 参数
2. 或等待 yt-dlp 更新支持

### Q: 转录速度太慢？
A: 使用更小的模型：
```bash
python3 scripts/parse_video.py --douyin "URL" --model tiny
```

### Q: 识别不准确？
A: 尝试更大的模型：
```bash
python3 scripts/parse_video.py --douyin "URL" --model small
```

---

*🌿 技能由 MOSS 维护，持续迭代中*
