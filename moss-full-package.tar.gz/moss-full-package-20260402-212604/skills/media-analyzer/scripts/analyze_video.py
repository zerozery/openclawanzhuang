#!/usr/bin/env python3
"""
视频内容分析与总结脚本
从视频字幕/转录文本中提取知识点、生成总结

用法：
    python3 analyze_video.py --subtitle <字幕文件>
    python3 analyze_video.py --text <文本内容>
    python3 analyze_video.py --youtube <YouTube URL>
"""

import sys
import os
import json
import argparse
import re
from datetime import datetime


def parse_srt(srt_content):
    """
    解析 SRT 字幕格式
    
    Returns:
        list: [{start, end, text}]
    """
    subtitles = []
    blocks = re.split(r'\n\s*\n', srt_content.strip())
    
    for block in blocks:
        lines = block.strip().split('\n')
        if len(lines) >= 3:
            try:
                # 跳过序号
                time_line = lines[1]
                text = '\n'.join(lines[2:])
                
                # 解析时间
                time_match = re.match(r'(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{3})', time_line)
                if time_match:
                    start = time_match.group(1)
                    end = time_match.group(2)
                    subtitles.append({
                        'start': start,
                        'end': end,
                        'text': text.strip()
                    })
            except:
                continue
    
    return subtitles


def time_to_seconds(time_str):
    """时间字符串转秒数"""
    match = re.match(r'(\d{2}):(\d{2}):(\d{2})[,\.](\d{3})', time_str)
    if match:
        h, m, s, ms = map(int, match.groups())
        return h * 3600 + m * 60 + s + ms / 1000
    return 0


def segment_content(subtitles, segment_seconds=60):
    """
    将字幕按时间段分段
    
    Args:
        subtitles: 字幕列表
        segment_seconds: 每段时长（秒）
    
    Returns:
        list: [{start_time, end_time, text, keywords}]
    """
    if not subtitles:
        return []
    
    segments = []
    current_segment = {
        'start_time': subtitles[0].get('start', '00:00:00'),
        'end_time': '',
        'text': '',
        'sentences': []
    }
    current_start_sec = 0
    
    for sub in subtitles:
        start_sec = time_to_seconds(sub.get('start', '00:00:00'))
        
        # 如果超过分段时长，开始新段落
        if start_sec - current_start_sec >= segment_seconds and current_segment['text']:
            current_segment['end_time'] = sub.get('start', '')
            current_segment['text'] = current_segment['text'].strip()
            segments.append(current_segment)
            
            current_segment = {
                'start_time': sub.get('start', ''),
                'end_time': '',
                'text': '',
                'sentences': []
            }
            current_start_sec = start_sec
        
        current_segment['text'] += sub['text'] + ' '
        current_segment['sentences'].append(sub['text'])
    
    # 添加最后一段
    if current_segment['text']:
        current_segment['end_time'] = subtitles[-1].get('end', '')
        current_segment['text'] = current_segment['text'].strip()
        segments.append(current_segment)
    
    return segments


def extract_keywords(text, top_k=10):
    """
    提取关键词（简单版本，基于词频）
    实际使用中可以用更高级的 NLP 模型
    """
    # 中文分词（简化版，按标点和空格分割）
    words = re.split(r'[，。！？；：、\s]+', text)
    
    # 过滤停用词和短词
    stopwords = {'的', '了', '是', '在', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'}
    words = [w for w in words if len(w) > 1 and w not in stopwords]
    
    # 统计词频
    word_freq = {}
    for word in words:
        word_freq[word] = word_freq.get(word, 0) + 1
    
    # 返回 top_k
    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    return [w[0] for w in sorted_words[:top_k]]


def generate_summary(segments, full_text):
    """
    生成视频内容总结
    
    Returns:
        dict: {
            "overview": str,
            "key_points": list,
            "timeline": list,
            "keywords": list
        }
    """
    # 提取关键词
    keywords = extract_keywords(full_text)
    
    # 生成时间线
    timeline = []
    for seg in segments:
        # 提取该段的第一句作为摘要
        first_sentence = seg['sentences'][0] if seg['sentences'] else ''
        if first_sentence:
            timeline.append({
                'time': seg['start_time'],
                'content': first_sentence[:50] + ('...' if len(first_sentence) > 50 else '')
            })
    
    # 生成关键点（简化版：取每段的开头）
    key_points = []
    for i, seg in enumerate(segments[:10], 1):  # 最多 10 个关键点
        if seg['text']:
            first_sentence = seg['sentences'][0] if seg['sentences'] else seg['text'][:100]
            key_points.append(f"{i}. [{seg['start_time']}] {first_sentence}")
    
    # 概述
    overview = f"视频共{len(segments)}个片段，主要内容包括：" + "、".join(keywords[:5])
    
    return {
        'overview': overview,
        'key_points': key_points,
        'timeline': timeline,
        'keywords': keywords
    }


def analyze_video_content(subtitle_path=None, text_content=None):
    """
    分析视频内容
    
    Args:
        subtitle_path: SRT 字幕文件路径
        text_content: 直接传入文本内容
    
    Returns:
        dict: 分析结果
    """
    subtitles = []
    full_text = ""
    
    # 加载字幕或文本
    if subtitle_path:
        if not os.path.exists(subtitle_path):
            return {
                "success": False,
                "error": f"文件不存在：{subtitle_path}"
            }
        
        with open(subtitle_path, 'r', encoding='utf-8') as f:
            srt_content = f.read()
        
        subtitles = parse_srt(srt_content)
        full_text = ' '.join([sub['text'] for sub in subtitles])
        
    elif text_content:
        full_text = text_content
        # 简单分段
        paragraphs = [p.strip() for p in text_content.split('\n') if p.strip()]
        subtitles = [{'start': '', 'end': '', 'text': p} for p in paragraphs]
    
    else:
        return {
            "success": False,
            "error": "请提供字幕文件或文本内容"
        }
    
    # 分段
    segments = segment_content(subtitles)
    
    # 生成总结
    summary = generate_summary(segments, full_text)
    
    return {
        "success": True,
        "metadata": {
            "total_segments": len(segments),
            "total_chars": len(full_text),
            "duration_estimate": f"{len(segments)} 分钟" if segments else "未知"
        },
        "full_text": full_text,
        "summary": summary,
        "segments": segments
    }


def main():
    parser = argparse.ArgumentParser(description='视频内容分析工具')
    parser.add_argument('--subtitle', '-s', help='SRT 字幕文件路径')
    parser.add_argument('--text', '-t', help='文本内容（直接传入）')
    parser.add_argument('--file', '-f', help='文本文件路径')
    parser.add_argument('--output', '-o', help='输出文件路径（JSON）')
    parser.add_argument('--simple', action='store_true', help='简化输出模式')
    
    args = parser.parse_args()
    
    # 加载文本
    text_content = None
    if args.file:
        if not os.path.exists(args.file):
            print(f"❌ 文件不存在：{args.file}")
            sys.exit(1)
        with open(args.file, 'r', encoding='utf-8') as f:
            text_content = f.read()
    
    # 分析
    print("🔍 正在分析视频内容...")
    result = analyze_video_content(args.subtitle, text_content or args.text)
    
    # 输出
    if result['success']:
        if args.simple:
            print("\n" + "="*60)
            print("📊 视频内容总结")
            print("="*60)
            print(f"\n{result['summary']['overview']}\n")
            print("🔑 关键词：" + ", ".join(result['summary']['keywords'][:10]))
            print("\n📌 关键点：")
            for point in result['summary']['key_points'][:5]:
                print(f"  {point}")
            print("="*60)
        else:
            output = {
                'metadata': result['metadata'],
                'summary': result['summary'],
                # 不包含完整文本和分段，避免输出过长
            }
            print(json.dumps(output, ensure_ascii=False, indent=2))
        
        # 保存完整结果
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"\n💾 完整结果已保存：{args.output}")
            
    else:
        print(f"❌ 分析失败：{result.get('error', '未知错误')}")
        sys.exit(1)


if __name__ == '__main__':
    main()
