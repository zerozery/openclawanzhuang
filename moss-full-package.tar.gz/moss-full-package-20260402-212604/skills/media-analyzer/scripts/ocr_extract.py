#!/usr/bin/env python3
"""
OCR 文字提取脚本
使用 EasyOCR 从图片中提取文字（支持中文/英文）

用法：
    python3 ocr_extract.py <图片路径>
    python3 ocr_extract.py --url <图片 URL>
"""

import sys
import os
import json
import argparse

try:
    import easyocr
except ImportError:
    print("❌ 未安装 easyocr，请先安装：pip install easyocr")
    sys.exit(1)


def extract_text_from_image(image_path, languages=None):
    """
    从图片提取文字
    
    Args:
        image_path: 图片文件路径
        languages: 语言列表，默认 ['ch_sim', 'en']（简体中文 + 英文）
    
    Returns:
        dict: {
            "success": bool,
            "text": str,  # 完整文字
            "lines": list,  # 按行分割
            "details": list  # 详细信息（位置、置信度）
        }
    """
    if languages is None:
        languages = ['ch_sim', 'en']
    
    if not os.path.exists(image_path):
        return {
            "success": False,
            "error": f"文件不存在：{image_path}"
        }
    
    try:
        # 初始化 OCR 读取器（首次加载较慢）
        print("🔄 正在初始化 OCR 引擎（首次运行较慢，请耐心等待）...")
        reader = easyocr.Reader(languages, gpu=False)
        
        print("🔍 正在识别文字...")
        result = reader.readtext(image_path)
        
        # 提取文字
        lines = [r[1] for r in result]
        full_text = '\n'.join(lines)
        
        # 详细信息
        details = []
        for bbox, text, confidence in result:
            details.append({
                "text": text,
                "confidence": round(confidence, 3),
                "bbox": bbox  # 边界框坐标
            })
        
        return {
            "success": True,
            "text": full_text,
            "lines": lines,
            "details": details,
            "count": len(result)
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def main():
    parser = argparse.ArgumentParser(description='OCR 文字提取工具')
    parser.add_argument('image_path', nargs='?', help='图片文件路径')
    parser.add_argument('--url', help='图片 URL（需先下载）')
    parser.add_argument('--lang', default='ch_sim,en', help='语言，默认 ch_sim,en')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    
    args = parser.parse_args()
    
    if not args.image_path and not args.url:
        parser.print_help()
        sys.exit(1)
    
    image_path = args.image_path
    
    # 如果是 URL，需要先下载（简化处理）
    if args.url:
        print(f"⚠️ URL 下载功能待实现，当前仅支持本地文件")
        sys.exit(1)
    
    # 解析语言
    languages = [lang.strip() for lang in args.lang.split(',')]
    
    # 执行 OCR
    result = extract_text_from_image(image_path, languages)
    
    # 输出结果
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        if result['success']:
            print(f"\n✅ 识别完成！共 {result['count']} 行文字\n")
            print("=" * 50)
            print(result['text'])
            print("=" * 50)
        else:
            print(f"❌ 识别失败：{result.get('error', '未知错误')}")
            sys.exit(1)


if __name__ == '__main__':
    main()
