#!/usr/bin/env python3
"""
抖音视频下载脚本
使用 yt-dlp 下载抖音视频（无水印）

用法：
    python3 download_douyin.py <抖音视频链接>
    python3 download_douyin.py --url <URL> --output <输出路径>
"""

import sys
import os
import json
import argparse
import re

try:
    import yt_dlp
except ImportError:
    print("❌ 未安装 yt-dlp，请先安装：pip install yt-dlp")
    sys.exit(1)


def extract_video_id(url):
    """从抖音链接提取视频 ID"""
    # 支持多种抖音链接格式
    patterns = [
        r'/video/(\d+)',
        r'/share/video/(\d+)',
        r'v\.douyin\.com/(\w+)/',
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None


def download_douyin_video(url, output_template='%(id)s.%(ext)s', download_subtitle=False):
    """
    下载抖音视频
    
    Args:
        url: 抖音视频链接
        output_template: 输出文件模板
        download_subtitle: 是否下载字幕
    
    Returns:
        dict: {
            "success": bool,
            "video_path": str,
            "info": dict,  # 视频信息
            "subtitle_path": str or None
        }
    """
    video_id = extract_video_id(url)
    if not video_id:
        return {
            "success": False,
            "error": f"无法从链接提取视频 ID: {url}"
        }
    
    # yt-dlp 配置
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': output_template,
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'extract_flat': False,
    }
    
    # 如果需要字幕
    if download_subtitle:
        ydl_opts['writesubtitles'] = True
        ydl_opts['writeautomaticsub'] = True
        ydl_opts['subtitleslangs'] = ['zh-Hans', 'zh-Hant', 'en']
    
    try:
        print(f"🎬 正在获取视频信息...")
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # 提取信息
            info = ydl.extract_info(url, download=True)
            
            # 获取下载的文件路径
            video_path = info.get('filepath', f"{video_id}.mp4")
            
            # 字幕路径
            subtitle_path = None
            if download_subtitle and 'subtitles' in info:
                subtitle_path = f"{video_id}.zh-Hans.srt"
            
            return {
                "success": True,
                "video_path": video_path,
                "info": {
                    "id": info.get('id', video_id),
                    "title": info.get('title', 'Unknown'),
                    "uploader": info.get('uploader', 'Unknown'),
                    "duration": info.get('duration', 0),
                    "view_count": info.get('view_count', 0),
                    "like_count": info.get('like_count', 0),
                    "description": info.get('description', ''),
                },
                "subtitle_path": subtitle_path
            }
            
    except Exception as e:
        return {
            "success": False,
            "error": f"下载失败：{str(e)}"
        }


def get_video_info_only(url):
    """仅获取视频信息，不下载"""
    try:
        with yt_dlp.YoutubeDL({'quiet': True, 'extract_flat': False}) as ydl:
            info = ydl.extract_info(url, download=False)
            return {
                "success": True,
                "info": {
                    "id": info.get('id'),
                    "title": info.get('title'),
                    "uploader": info.get('uploader'),
                    "duration": info.get('duration'),
                    "url": info.get('webpage_url'),
                    "thumbnail": info.get('thumbnail'),
                    "description": info.get('description'),
                }
            }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def main():
    parser = argparse.ArgumentParser(description='抖音视频下载工具')
    parser.add_argument('url', nargs='?', help='抖音视频链接')
    parser.add_argument('--url', '-u', dest='url_opt', help='抖音视频链接（备用）')
    parser.add_argument('--output', '-o', default='douyin_%(id)s.%(ext)s', help='输出文件模板')
    parser.add_argument('--info', action='store_true', help='仅获取信息，不下载')
    parser.add_argument('--subtitle', action='store_true', help='下载字幕')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    
    args = parser.parse_args()
    
    url = args.url or args.url_opt
    if not url:
        parser.print_help()
        sys.exit(1)
    
    if args.info:
        print("📊 获取视频信息...")
        result = get_video_info_only(url)
    else:
        print(f"📥 下载抖音视频：{url}")
        result = download_douyin_video(url, args.output, args.subtitle)
    
    # 输出结果
    if result['success']:
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            if args.info:
                print("\n✅ 视频信息：")
                print(f"  ID: {result['info'].get('id')}")
                print(f"  标题：{result['info'].get('title')}")
                print(f"  作者：{result['info'].get('uploader')}")
                print(f"  时长：{result['info'].get('duration', 0)}秒")
            else:
                print(f"\n✅ 下载完成！")
                print(f"  视频路径：{result['video_path']}")
                if result.get('subtitle_path'):
                    print(f"  字幕路径：{result['subtitle_path']}")
                print(f"\n📊 视频信息：")
                print(f"  标题：{result['info'].get('title')}")
                print(f"  作者：{result['info'].get('uploader')}")
                print(f"  时长：{result['info'].get('duration', 0)}秒")
    else:
        print(f"❌ 失败：{result.get('error', '未知错误')}")
        sys.exit(1)


if __name__ == '__main__':
    main()
