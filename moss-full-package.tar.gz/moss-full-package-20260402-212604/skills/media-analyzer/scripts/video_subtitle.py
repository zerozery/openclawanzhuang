#!/usr/bin/env python3
"""
视频字幕提取脚本
支持：
1. YouTube 在线字幕下载
2. 本地视频 Whisper 语音转文字

用法：
    # YouTube 视频
    python3 video_subtitle.py --youtube <视频 URL>
    
    # 本地视频文件
    python3 video_subtitle.py --file <视频路径>
"""

import sys
import os
import json
import argparse
import re


def extract_youtube_video_id(url):
    """从 YouTube URL 提取视频 ID"""
    patterns = [
        r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]+)',
        r'youtube\.com\/shorts\/([a-zA-Z0-9_-]+)'
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None


def download_youtube_subtitles(video_id, languages=None):
    """
    下载 YouTube 字幕
    
    Args:
        video_id: YouTube 视频 ID
        languages: 语言列表，默认 ['zh-Hans', 'zh-Hant', 'en']
    
    Returns:
        dict: {
            "success": bool,
            "subtitles": list,  # [{text, start, duration}]
            "full_text": str,
            "language": str
        }
    """
    if languages is None:
        languages = ['zh-Hans', 'zh-Hant', 'en']
    
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
        from youtube_transcript_api.formatters import SRTFormatter
    except ImportError:
        return {
            "success": False,
            "error": "未安装 youtube-transcript-api，请运行：pip install youtube-transcript-api"
        }
    
    try:
        # 尝试获取字幕
        transcript = YouTubeTranscriptApi.list_transcripts(video_id)
        
        # 优先获取手动字幕
        try:
            subtitle = transcript.find_manually_created_transcript(languages)
        except:
            #  fallback 到自动生成的字幕
            try:
                subtitle = transcript.find_generated_transcript(languages)
            except:
                # 尝试所有语言
                subtitle = transcript.find_transcript(languages)
        
        # 获取字幕内容
        subtitle_data = subtitle.fetch()
        
        # 格式化
        full_text = '\n'.join([item['text'] for item in subtitle_data])
        
        return {
            "success": True,
            "subtitles": subtitle_data,
            "full_text": full_text,
            "language": subtitle.language_code,
            "video_id": video_id
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"无法获取字幕：{str(e)}\n可能原因：视频没有字幕、视频是私有的、或需要登录"
        }


def transcribe_local_video(video_path, model_size="base"):
    """
    使用 Whisper 转录本地视频
    
    Args:
        video_path: 视频文件路径
        model_size: Whisper 模型大小 (tiny, base, small, medium, large)
    
    Returns:
        dict: {
            "success": bool,
            "segments": list,  # [{text, start, end}]
            "full_text": str
        }
    """
    try:
        import whisper_timestamped as whisper
    except ImportError:
        return {
            "success": False,
            "error": "未安装 whisper-timestamped，请运行：pip install whisper-timestamped"
        }
    
    if not os.path.exists(video_path):
        return {
            "success": False,
            "error": f"文件不存在：{video_path}"
        }
    
    try:
        print(f"🔄 正在加载 Whisper 模型 ({model_size})...")
        audio = whisper.load_audio(video_path)
        model = whisper.load_model(model_size, device="cpu")
        
        print("🔍 正在转录语音（可能需要较长时间）...")
        result = model.transcribe(audio, language=None)  # None=自动检测
        
        segments = result['segments']
        full_text = ''.join([seg['text'] for seg in segments])
        
        return {
            "success": True,
            "segments": segments,
            "full_text": full_text,
            "language": result.get('language', 'unknown')
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def format_srt(subtitles):
    """将字幕格式化为 SRT 格式"""
    srt_lines = []
    for i, item in enumerate(subtitles, 1):
        start = item.get('start', item.get('offset', 0))
        duration = item.get('duration', 3)
        end = start + duration
        text = item['text']
        
        # 转换时间格式
        start_str = format_timestamp(start)
        end_str = format_timestamp(end)
        
        srt_lines.append(f"{i}\n{start_str} --> {end_str}\n{text}\n")
    
    return '\n'.join(srt_lines)


def format_timestamp(seconds):
    """秒数转换为 SRT 时间戳格式"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def main():
    parser = argparse.ArgumentParser(description='视频字幕提取工具')
    parser.add_argument('--youtube', help='YouTube 视频 URL')
    parser.add_argument('--file', help='本地视频文件路径')
    parser.add_argument('--model', default='base', help='Whisper 模型大小 (tiny/base/small/medium/large)')
    parser.add_argument('--output', help='输出文件路径（SRT 格式）')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    
    args = parser.parse_args()
    
    result = None
    
    if args.youtube:
        video_id = extract_youtube_video_id(args.youtube)
        if not video_id:
            print(f"❌ 无法从 URL 提取视频 ID: {args.youtube}")
            sys.exit(1)
        print(f"📺 正在获取 YouTube 字幕 (ID: {video_id})...")
        result = download_youtube_subtitles(video_id)
        
    elif args.file:
        print(f"🎬 正在转录本地视频：{args.file}")
        result = transcribe_local_video(args.file, args.model)
        
    else:
        parser.print_help()
        sys.exit(1)
    
    # 输出结果
    if result['success']:
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"\n✅ 转录完成！")
            print(f"语言：{result.get('language', '未知')}")
            print(f"\n{'='*50}")
            print(result['full_text'][:1000] + "..." if len(result['full_text']) > 1000 else result['full_text'])
            print(f"{'='*50}")
        
        # 保存 SRT 文件
        if args.output and 'subtitles' in result:
            srt_content = format_srt(result['subtitles'])
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(srt_content)
            print(f"\n💾 SRT 字幕已保存：{args.output}")
            
    else:
        print(f"❌ 失败：{result.get('error', '未知错误')}")
        sys.exit(1)


if __name__ == '__main__':
    main()
