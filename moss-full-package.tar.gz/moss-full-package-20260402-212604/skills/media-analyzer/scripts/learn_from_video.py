#!/usr/bin/env python3
"""
视频学习工作流 - 一键提取视频内容并生成学习笔记

用法：
    python3 learn_from_video.py <视频链接>
    python3 learn_from_video.py --douyin <抖音链接>
    python3 learn_from_video.py --youtube <YouTube 链接>
    python3 learn_from_video.py --file <本地视频文件>
"""

import sys
import os
import json
import argparse
import subprocess
from datetime import datetime


def run_command(cmd, description=""):
    """运行命令并返回结果"""
    if description:
        print(f"🔄 {description}...")
    
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=True,
        text=True
    )
    
    return {
        'success': result.returncode == 0,
        'stdout': result.stdout,
        'stderr': result.stderr
    }


def download_and_analyze(video_url, platform='auto', output_dir='.', keep_video=False):
    """
    下载视频并分析内容
    
    Args:
        video_url: 视频链接
        platform: 平台类型 (douyin/youtube/auto)
        output_dir: 输出目录
        keep_video: 是否保留视频文件
    
    Returns:
        dict: 学习笔记
    """
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    work_dir = os.path.join(output_dir, f'video_learn_{timestamp}')
    os.makedirs(work_dir, exist_ok=True)
    
    notes = {
        'created_at': datetime.now().isoformat(),
        'source_url': video_url,
        'platform': platform,
        'steps': []
    }
    
    # 步骤 1: 下载视频
    print("\n" + "="*60)
    print("📥 步骤 1: 下载视频")
    print("="*60)
    
    if platform == 'douyin' or platform == 'auto':
        download_script = os.path.join(os.path.dirname(__file__), 'download_douyin.py')
        video_path = os.path.join(work_dir, 'video.mp4')
        cmd = f'python3 "{download_script}" "{video_url}" --output "{video_path}" --subtitle'
        
        result = run_command(cmd, "正在下载抖音视频")
        if result['success']:
            notes['steps'].append({
                'step': 'download',
                'status': 'success',
                'video_path': video_path
            })
            print("✅ 视频下载完成")
        else:
            notes['steps'].append({
                'step': 'download',
                'status': 'failed',
                'error': result['stderr']
            })
            print(f"❌ 下载失败：{result['stderr']}")
            return notes
    
    # 步骤 2: 提取字幕/转录
    print("\n" + "="*60)
    print("📝 步骤 2: 提取字幕/语音转录")
    print("="*60)
    
    subtitle_script = os.path.join(os.path.dirname(__file__), 'video_subtitle.py')
    subtitle_path = os.path.join(work_dir, 'subtitles.srt')
    
    # 检查是否有下载的字幕
    downloaded_subtitle = os.path.join(work_dir, 'video.zh-Hans.srt')
    if os.path.exists(downloaded_subtitle):
        os.rename(downloaded_subtitle, subtitle_path)
        print("✅ 使用已下载的字幕")
        notes['steps'].append({
            'step': 'subtitle',
            'status': 'success',
            'subtitle_path': subtitle_path,
            'method': 'downloaded'
        })
    else:
        # 使用 Whisper 转录
        cmd = f'python3 "{subtitle_script}" --file "{video_path}" --output "{subtitle_path}"'
        result = run_command(cmd, "正在转录语音（可能需要较长时间）")
        
        if result['success'] and os.path.exists(subtitle_path):
            notes['steps'].append({
                'step': 'subtitle',
                'status': 'success',
                'subtitle_path': subtitle_path,
                'method': 'whisper'
            })
            print("✅ 语音转录完成")
        else:
            notes['steps'].append({
                'step': 'subtitle',
                'status': 'failed',
                'error': result['stderr']
            })
            print(f"❌ 转录失败：{result['stderr']}")
            # 继续尝试下一步
    
    # 步骤 3: 分析内容
    print("\n" + "="*60)
    print("🧠 步骤 3: 分析视频内容")
    print("="*60)
    
    analyze_script = os.path.join(os.path.dirname(__file__), 'analyze_video.py')
    notes_path = os.path.join(work_dir, 'learning_notes.json')
    
    if os.path.exists(subtitle_path):
        cmd = f'python3 "{analyze_script}" --subtitle "{subtitle_path}" --output "{notes_path}"'
        result = run_command(cmd, "正在生成学习笔记")
        
        if result['success']:
            notes['steps'].append({
                'step': 'analyze',
                'status': 'success',
                'notes_path': notes_path
            })
            print("✅ 学习笔记生成完成")
            
            # 读取并显示摘要
            with open(notes_path, 'r', encoding='utf-8') as f:
                analysis = json.load(f)
            
            notes['summary'] = analysis.get('summary', {})
            notes['full_text'] = analysis.get('full_text', '')[:500] + '...'  # 截取部分
            
        else:
            notes['steps'].append({
                'step': 'analyze',
                'status': 'failed',
                'error': result['stderr']
            })
            print(f"❌ 分析失败：{result['stderr']}")
    else:
        print("⚠️ 跳过内容分析（无字幕）")
        notes['steps'].append({
            'step': 'analyze',
            'status': 'skipped',
            'reason': 'no_subtitle'
        })
    
    # 清理
    if not keep_video and os.path.exists(video_path):
        print("\n🗑️  清理临时文件...")
        os.remove(video_path)
    
    # 保存学习记录
    record_path = os.path.join(work_dir, 'session.json')
    with open(record_path, 'w', encoding='utf-8') as f:
        json.dump(notes, f, ensure_ascii=False, indent=2)
    
    print("\n" + "="*60)
    print("✅ 学习完成！")
    print("="*60)
    print(f"\n📁 工作目录：{work_dir}")
    print(f"📄 学习笔记：{notes_path if os.path.exists(notes_path) else '未生成'}")
    print(f"📋 会话记录：{record_path}")
    
    # 显示摘要
    if 'summary' in notes:
        print("\n" + "="*60)
        print("📊 内容摘要")
        print("="*60)
        print(f"\n{notes['summary'].get('overview', '无概述')}\n")
        keywords = notes['summary'].get('keywords', [])
        if keywords:
            print(f"🔑 关键词：{', '.join(keywords[:10])}")
        key_points = notes['summary'].get('key_points', [])
        if key_points:
            print("\n📌 关键点：")
            for point in key_points[:5]:
                print(f"  {point}")
    
    return notes


def main():
    parser = argparse.ArgumentParser(description='视频学习工具 - 一键提取视频内容并生成笔记')
    parser.add_argument('url', nargs='?', help='视频链接')
    parser.add_argument('--url', '-u', dest='url_opt', help='视频链接（备用）')
    parser.add_argument('--douyin', help='抖音视频链接')
    parser.add_argument('--youtube', help='YouTube 视频链接')
    parser.add_argument('--file', help='本地视频文件路径')
    parser.add_argument('--output', '-o', default='.', help='输出目录')
    parser.add_argument('--keep', action='store_true', help='保留视频文件')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    
    args = parser.parse_args()
    
    # 确定视频来源
    video_url = args.douyin or args.youtube or args.url or args.url_opt
    
    if not video_url and not args.file:
        parser.print_help()
        sys.exit(1)
    
    # 确定平台
    platform = 'auto'
    if args.douyin or 'douyin' in (video_url or '') or 'iesdouyin' in (video_url or ''):
        platform = 'douyin'
    elif args.youtube or 'youtube' in (video_url or '') or 'youtu.be' in (video_url or ''):
        platform = 'youtube'
    
    if args.file:
        print(f"🎬 分析本地视频：{args.file}")
        # 直接分析（跳过下载）
        subtitle_script = os.path.join(os.path.dirname(__file__), 'video_subtitle.py')
        analyze_script = os.path.join(os.path.dirname(__file__), 'analyze_video.py')
        
        subtitle_path = args.file.rsplit('.', 1)[0] + '.srt'
        cmd = f'python3 "{subtitle_script}" --file "{args.file}" --output "{subtitle_path}"'
        run_command(cmd, "正在转录语音")
        
        if os.path.exists(subtitle_path):
            cmd = f'python3 "{analyze_script}" --subtitle "{subtitle_path}" --simple'
            run_command(cmd, "正在分析内容")
        return
    
    # 下载并分析
    notes = download_and_analyze(video_url, platform, args.output, args.keep)
    
    if args.json:
        print("\n" + json.dumps(notes, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
