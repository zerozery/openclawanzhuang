#!/bin/bash
#
# 飞书图片发送 Skill 安装包
# 用法：下载后直接运行 ./feishu-image-sender-installer.sh
#
# 生成方式：将此脚本分发给其他 OpenClaw 用户，运行即可自动安装技能
#

set -e

SKILL_NAME="feishu-image-sender"
SKILLS_DIR="$HOME/.openclaw/workspace/skills"
TEMP_DIR=$(mktemp -d)

echo "🔧 开始安装 $SKILL_NAME..."

# 清理临时目录
cleanup() {
    rm -rf "$TEMP_DIR"
}
trap cleanup EXIT

# 检查 OpenClaw 是否安装
if ! command -v openclaw &> /dev/null; then
    echo "❌ 错误：未找到 openclaw 命令"
    echo "   请先安装 OpenClaw: https://docs.openclaw.ai"
    exit 1
fi

# 创建 skills 目录
if [[ ! -d "$SKILLS_DIR" ]]; then
    echo "📁 创建 skills 目录：$SKILLS_DIR"
    mkdir -p "$SKILLS_DIR"
fi

# 检查是否已安装
TARGET_DIR="$SKILLS_DIR/$SKILL_NAME"
if [[ -d "$TARGET_DIR" ]]; then
    echo "⚠️  技能已存在：$TARGET_DIR"
    read -p "是否覆盖安装？(y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "❌ 取消安装"
        exit 0
    fi
    echo "🗑️  删除旧版本..."
    rm -rf "$TARGET_DIR"
fi

# 创建技能目录
echo "📦 创建技能目录..."
mkdir -p "$TARGET_DIR"

# 写入 SKILL.md
cat > "$TARGET_DIR/SKILL.md" << 'SKILL_EOF'
---
name: feishu-image-sender
description: 飞书图片发送技能。支持发送本地图片到飞书用户或群组，自动处理 base64 编码。
metadata: {"clawdbot":{"emoji":"📸"}}
triggers:
  - 飞书图片
  - 飞书发图
  - 发送图片到飞书
  - feishu image
  - 飞书图片发送
priority: 90
---

# 飞书图片发送

通过飞书 API 发送本地图片到指定用户或群组。

## 快速使用

### 方式 1：使用 openclaw message 命令

```bash
openclaw message send \
  --channel feishu \
  --target "ou_xxx" \
  --message "图片描述" \
  --media "/path/to/image.png" \
  --content-type "image/png"
```

### 方式 2：使用本技能的脚本

```bash
./send-image.sh --target "ou_xxx" --file "/path/to/image.png" --message "可选描述"
```

## 配置

在 `openclaw.json` 中确保飞书通道已配置：

```json
{
  "channels": {
    "feishu": {
      "enabled": true,
      "appId": "cli_xxx",
      "appSecret": "xxx",
      "domain": "feishu",
      "groupPolicy": "open"
    }
  }
}
```

## 参数说明

| 参数 | 说明 | 必填 |
|------|------|------|
| `--target` | 飞书用户 ID (ou_xxx) 或群组 ID | ✅ |
| `--file` | 本地图片路径 | ✅ |
| `--message` | 附带文字消息 | ❌ |

## 支持的图片格式

- PNG (`image/png`)
- JPEG (`image/jpeg`)
- GIF (`image/gif`)
- WebP (`image/webp`)

## 错误处理

- 文件不存在：检查路径是否正确
- 权限不足：确保飞书应用有发送消息权限
- 频率限制：等待后重试

## 示例

```bash
# 发送 PNG 图片
./send-image.sh --target "ou_387beeed74b9770a92c3d8705f25280b" --file "./image.png"

# 发送带描述的图片
./send-image.sh --target "ou_xxx" --file "./photo.jpg" --message "这是今天的照片"
```
SKILL_EOF

# 写入 send-image.sh
cat > "$TARGET_DIR/send-image.sh" << 'SCRIPT_EOF'
#!/bin/bash
#
# 飞书图片发送脚本
# 用法：./send-image.sh --target "ou_xxx" --file "/path/to/image.png" [--message "描述"]
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=""
FILE=""
MESSAGE=""

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --target)
            TARGET="$2"
            shift 2
            ;;
        --file)
            FILE="$2"
            shift 2
            ;;
        --message)
            MESSAGE="$2"
            shift 2
            ;;
        --help)
            echo "用法：$0 --target <用户 ID> --file <图片路径> [--message <描述>]"
            echo ""
            echo "选项:"
            echo "  --target   飞书用户 ID (ou_xxx) 或群组 ID"
            echo "  --file     本地图片路径"
            echo "  --message  附带的文字消息（可选）"
            echo "  --help     显示帮助信息"
            exit 0
            ;;
        *)
            echo "未知参数：$1"
            echo "使用 --help 查看帮助"
            exit 1
            ;;
    esac
done

# 验证必填参数
if [[ -z "$TARGET" ]]; then
    echo "❌ 错误：--target 是必填参数"
    exit 1
fi

if [[ -z "$FILE" ]]; then
    echo "❌ 错误：--file 是必填参数"
    exit 1
fi

if [[ ! -f "$FILE" ]]; then
    echo "❌ 错误：文件不存在：$FILE"
    exit 1
fi

# 检测操作系统并选择正确的 base64 命令
detect_base64_cmd() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "base64 -i"
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        echo "base64 -w 0"
    else
        # 尝试两种方式
        if base64 -i /dev/null 2>/dev/null; then
            echo "base64 -i"
        else
            echo "base64 -w 0"
        fi
    fi
}

BASE64_CMD=$(detect_base64_cmd)

# 获取文件 MIME 类型
get_content_type() {
    local file="$1"
    local ext="${file##*.}"
    case "$ext" in
        png|PNG)
            echo "image/png"
            ;;
        jpg|jpeg|JPG|JPEG)
            echo "image/jpeg"
            ;;
        gif|GIF)
            echo "image/gif"
            ;;
        webp|WEBP)
            echo "image/webp"
            ;;
        *)
            # 尝试使用 file 命令
            if command -v file &> /dev/null; then
                local mime=$(file -b --mime-type "$file")
                if [[ "$mime" == image/* ]]; then
                    echo "$mime"
                    return
                fi
            fi
            # 默认 PNG
            echo "image/png"
            ;;
    esac
}

CONTENT_TYPE=$(get_content_type "$FILE")
FILENAME=$(basename "$FILE")

echo "📸 准备发送图片到飞书..."
echo "   目标：$TARGET"
echo "   文件：$FILENAME"
echo "   类型：$CONTENT_TYPE"
[[ -n "$MESSAGE" ]] && echo "   消息：$MESSAGE"

# 读取并编码文件
BASE64_DATA=$($BASE64_CMD "$FILE")

# 构建 openclaw message 命令
CMD="openclaw message send --channel feishu --target \"$TARGET\" --buffer \"$BASE64_DATA\" --filename \"$FILENAME\" --content-type \"$CONTENT_TYPE\""

[[ -n "$MESSAGE" ]] && CMD="$CMD --message \"$MESSAGE\""

# 执行发送
echo "🚀 发送中..."
eval $CMD

if [[ $? -eq 0 ]]; then
    echo "✅ 图片发送成功！"
else
    echo "❌ 发送失败，请检查飞书配置和网络连接"
    exit 1
fi
SCRIPT_EOF

# 写入 README.md
cat > "$TARGET_DIR/README.md" << 'README_EOF'
# 飞书图片发送 Skill

通过飞书 API 发送本地图片到指定用户或群组。

## 使用

### 方式 1：命令行脚本

```bash
# 进入技能目录
cd ~/.openclaw/workspace/skills/feishu-image-sender/

# 发送图片
./send-image.sh --target "ou_xxx" --file "/path/to/image.png"

# 发送带描述的图片
./send-image.sh --target "ou_xxx" --file "/path/to/image.png" --message "这是图片描述"
```

### 方式 2：OpenClaw message 命令

```bash
openclaw message send \
  --channel feishu \
  --target "ou_xxx" \
  --media "/path/to/image.png" \
  --content-type "image/png"
```

## 配置

确保 `openclaw.json` 中飞书通道已配置：

```json
{
  "channels": {
    "feishu": {
      "enabled": true,
      "appId": "cli_xxx",
      "appSecret": "xxx"
    }
  }
}
```

## 获取飞书用户 ID

1. 打开飞书，进入与机器人的聊天
2. 查看 URL 或开发者工具中的用户 ID
3. 或使用飞书 API 查询

用户 ID 格式：`ou_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

## 支持格式

- PNG
- JPEG
- GIF
- WebP

## 故障排查

### 发送失败

1. 检查飞书应用配置（appId/appSecret）
2. 确认用户 ID 正确
3. 检查网络连接

### 图片无法显示

1. 确认文件格式正确
2. 检查文件大小（飞书限制 20MB）
3. 尝试转换为 PNG 格式

## 许可证

MIT
README_EOF

# 设置执行权限
echo "🔐 设置执行权限..."
chmod +x "$TARGET_DIR/send-image.sh"

# 验证安装
echo "🔍 验证安装..."
if [[ -f "$TARGET_DIR/SKILL.md" ]] && [[ -f "$TARGET_DIR/send-image.sh" ]]; then
    echo "✅ 安装成功！"
    echo ""
    echo "📚 使用方法："
    echo "   cd $TARGET_DIR"
    echo "   ./send-image.sh --target \"ou_xxx\" --file \"/path/to/image.png\""
    echo ""
    echo "📖 查看帮助："
    echo "   ./send-image.sh --help"
    echo ""
    echo "📝 文档：$TARGET_DIR/README.md"
else
    echo "❌ 安装失败，文件不完整"
    exit 1
fi
