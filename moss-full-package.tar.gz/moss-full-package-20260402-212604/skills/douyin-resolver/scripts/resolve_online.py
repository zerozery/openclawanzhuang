#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音无水印视频解析器 - 在线 API 版
使用免费的第三方解析 API
"""

import requests
import json
import sys
import argparse
import re

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
}

# 免费解析 API 列表 (无需 token)
ONLINE_APIS = [
    {
        'name': 'API 1',
        'url': 'https://api.qiaopu.com/douyin/parse',
        'method': 'GET',
        'params': lambda url: {'url': url},
        'extract': lambda data: extract_from_response(data),
    },
    {
        'name': 'API 2',
        'url': 'https://douyin.wuqiut.cn/api/douyin',
        'method': 'GET',
        'params': lambda url: {'url': url},
        'extract': lambda data: extract_from_response(data),
    },
]

def extract_video_id(url):
    """从链接中提取 video_id"""
    if 'v.douyin.com' in url:
        try:
            resp = requests.get(url, headers=HEADERS, allow_redirects=True, timeout=15)
            url = resp.url
        except:
            pass
    
    patterns = [r'/video/(\d+)', r'/note/(\d+)']
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1), url
    return None, url

def extract_from_response(data):
    """从 API 响应中提取视频信息"""
    if not isinstance(data, dict):
        return None
    
    video_info = {
        'video_id': '',
        'title': '',
        'author': '',
        'create_time': '',
        'statistics': {},
        'duration': 0,
        'desc': '',
        'video_url': '',
        'cover_url': '',
    }
    
    # 尝试常见字段
    video_info['video_id'] = data.get('video_id', data.get('aweme_id', ''))
    video_info['title'] = data.get('title', data.get('desc', ''))
    video_info['desc'] = data.get('desc', data.get('title', ''))
    
    # 作者
    author = data.get('author', {})
    if isinstance(author, dict):
        video_info['author'] = author.get('nickname', author.get('unique_id', ''))
    elif isinstance(author, str):
        video_info['author'] = author
    
    # 统计数据
    stats = data.get('statistics', data.get('stats', {}))
    if isinstance(stats, dict):
        video_info['statistics'] = {
            'digg_count': stats.get('digg_count', stats.get('digg_count', 0)),
            'comment_count': stats.get('comment_count', 0),
            'share_count': stats.get('share_count', 0),
            'collect_count': stats.get('collect_count', 0),
        }
    
    # 时长
    video_info['duration'] = data.get('duration', 0)
    
    # 视频 URL
    video = data.get('video', {})
    if isinstance(video, dict):
        play_addr = video.get('play_addr', {})
        if isinstance(play_addr, dict):
            url_list = play_addr.get('url_list', [])
            if isinstance(url_list, list) and url_list:
                video_info['video_url'] = url_list[0]
        
        if not video_info['video_url']:
            video_info['video_url'] = video.get('play_addr', '')
    
    # 无水印地址
    if not video_info['video_url']:
        video_info['video_url'] = data.get('video_url', data.get('wmplay', data.get('nwm_video_url', '')))
    
    # 封面
    video_info['cover_url'] = data.get('cover', data.get('dynamic_cover', ''))
    
    if video_info['video_url'] or video_info['author']:
        return video_info
    
    return None

def parse_with_online_api(url, api_config):
    """使用在线 API 解析"""
    try:
        api_url = api_config['url']
        params = api_config['params'](url)
        
        resp = requests.get(api_url, params=params, headers=HEADERS, timeout=15)
        
        if resp.status_code == 200:
            data = resp.json()
            return api_config['extract'](data)
    except Exception as e:
        print(f"  {api_config['name']} 失败：{e}")
    
    return None

def format_duration(seconds):
    if not seconds:
        return "未知"
    minutes = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{minutes}:{secs:02d}"

def format_number(num):
    if not num:
        return "0"
    num = int(num)
    if num >= 100000000:
        return f"{num / 100000000:.1f}亿"
    elif num >= 10000:
        return f"{num / 10000:.1f}万"
    else:
        return str(num)

def main():
    parser = argparse.ArgumentParser(description='抖音无水印视频解析器 (在线 API 版)')
    parser.add_argument('url', help='抖音视频链接')
    parser.add_argument('--output', '-o', help='下载视频文件')
    parser.add_argument('--json', action='store_true', help='仅输出 JSON')
    args = parser.parse_args()
    
    video_id, original_url = extract_video_id(args.url)
    if not video_id:
        print("❌ 无法提取 video_id")
        sys.exit(1)
    
    if not args.json:
        print(f"🔍 解析视频：{video_id}")
        print("-" * 50)
    
    video_info = None
    
    # 尝试在线 API
    for api_config in ONLINE_APIS:
        if not args.json:
            print(f"  尝试 {api_config['name']}...")
        video_info = parse_with_online_api(original_url, api_config)
        if video_info and (video_info.get('video_url') or video_info.get('author')):
            if not args.json:
                print(f"  ✅ {api_config['name']} 成功!")
            break
    
    if not video_info:
        video_info = {
            'video_id': video_id,
            'title': '',
            'author': '未知',
            'desc': '',
            'statistics': {},
            'duration': 0,
            'video_url': '',
        }
        if not args.json:
            print("⚠️  解析失败")
    
    if args.json:
        print(json.dumps(video_info, ensure_ascii=False, indent=2))
        return
    
    print("\n📹 视频信息:")
    print(f"  ID: {video_info.get('video_id')}")
    print(f"  标题：{video_info.get('title') or '无'}")
    print(f"  作者：{video_info.get('author')}")
    print(f"  简介：{video_info.get('desc') or '无'}")
    print(f"  时长：{format_duration(video_info.get('duration'))}")
    
    print("\n📊 互动数据:")
    stats = video_info.get('statistics', {})
    print(f"  👍 {format_number(stats.get('digg_count', 0))}")
    print(f"  💬 {format_number(stats.get('comment_count', 0))}")
    print(f"  ⭐ {format_number(stats.get('collect_count', 0))}")
    
    print("\n🔗 视频地址:")
    if video_info.get('video_url'):
        print(f"  {video_info['video_url']}")
    else:
        print(f"  https://www.douyin.com/video/{video_id}")
    
    print("\n" + "=" * 50)
    print(json.dumps(video_info, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
