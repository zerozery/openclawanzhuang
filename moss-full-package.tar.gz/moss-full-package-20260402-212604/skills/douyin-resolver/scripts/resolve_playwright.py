#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音无水印视频解析器 - Playwright 版本
使用浏览器自动化获取视频信息，更可靠
"""

import asyncio
import json
import re
import sys
import argparse
from playwright.async_api import async_playwright

async def resolve_douyin_video(url):
    """使用 Playwright 解析抖音视频"""
    
    video_info = {
        'video_id': '',
        'title': '',
        'author': '',
        'create_time': '',
        'statistics': {
            'digg_count': 0,
            'comment_count': 0,
            'share_count': 0,
            'collect_count': 0,
        },
        'duration': 0,
        'desc': '',
        'video_url': '',
        'cover_url': '',
    }
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            viewport={'width': 1920, 'height': 1080},
        )
        page = await context.new_page()
        
        try:
            # 访问抖音链接
            print(f"🌐 正在访问：{url}")
            await page.goto(url, wait_until='networkidle', timeout=30000)
            
            # 等待页面加载
            await page.wait_for_timeout(5000)
            
            # 获取页面 HTML
            html = await page.content()
            
            # 提取 video_id
            video_id_match = re.search(r'/video/(\d+)', url)
            if video_id_match:
                video_info['video_id'] = video_id_match.group(1)
            else:
                # 从当前 URL 提取
                current_url = page.url
                video_id_match = re.search(r'/video/(\d+)', current_url)
                if video_id_match:
                    video_info['video_id'] = video_id_match.group(1)
            
            # 尝试提取 JSON 数据
            json_data = await page.evaluate('''() => {
                const scripts = document.querySelectorAll('script');
                for (let script of scripts) {
                    if (script.id === 'RENDER_DATA' || script.textContent.includes('videoInfo')) {
                        return script.textContent;
                    }
                }
                return null;
            }''')
            
            if json_data:
                try:
                    # 清理并解析 JSON
                    json_str = json_data.strip()
                    if json_str.startswith('<'):
                        json_str = re.sub(r'^.*?>', '', json_str)
                    if json_str.endswith('</'):
                        json_str = re.sub(r'</.*$', '', json_str)
                    
                    from urllib.parse import unquote
                    json_str = unquote(json_str)
                    data = json.loads(json_str)
                    
                    # 导航到视频数据
                    if 'app' in data:
                        video_data = data['app'].get('video', {})
                    elif 'video' in data:
                        video_data = data['video']
                    else:
                        video_data = data
                    
                    if video_data:
                        # 提取标题
                        video_info['title'] = video_data.get('title', '')
                        
                        # 提取描述
                        video_info['desc'] = video_data.get('desc', '')
                        
                        # 提取作者
                        author = video_data.get('author', {})
                        if isinstance(author, dict):
                            video_info['author'] = author.get('nickname', author.get('unique_id', ''))
                        else:
                            video_info['author'] = str(author)
                        
                        # 提取统计数据
                        stats = video_data.get('statistics', {})
                        video_info['statistics'] = {
                            'digg_count': stats.get('digg_count', 0),
                            'comment_count': stats.get('comment_count', 0),
                            'share_count': stats.get('share_count', 0),
                            'collect_count': stats.get('collect_count', 0),
                        }
                        
                        # 提取时长
                        video_info['duration'] = video_data.get('duration', 0)
                        
                        # 提取视频 URL
                        video_obj = video_data.get('video', {})
                        if isinstance(video_obj, dict):
                            play_addr = video_obj.get('play_addr', {})
                            if isinstance(play_addr, dict):
                                url_list = play_addr.get('url_list', [])
                                if url_list:
                                    video_info['video_url'] = url_list[0]
                            
                            if not video_info['video_url']:
                                download_addr = video_obj.get('download_addr', {})
                                if isinstance(download_addr, dict):
                                    url_list = download_addr.get('url_list', [])
                                    if url_list:
                                        video_info['video_url'] = url_list[0]
                        
                        # 提取封面
                        cover = video_data.get('cover', {})
                        if isinstance(cover, dict):
                            url_list = cover.get('url_list', [])
                            if url_list:
                                video_info['cover_url'] = url_list[0]
                
                except Exception as e:
                    print(f"解析 JSON 失败：{e}")
            
            # 如果 JSON 解析失败，尝试从页面元素提取
            if not video_info['author']:
                author = await page.evaluate('''() => {
                    const el = document.querySelector('[data-e2e="author-name"]');
                    return el ? el.textContent : null;
                }''')
                if author:
                    video_info['author'] = author.strip()
            
            if not video_info['desc']:
                desc = await page.evaluate('''() => {
                    const el = document.querySelector('[data-e2e="desc"]');
                    return el ? el.textContent : null;
                }''')
                if desc:
                    video_info['desc'] = desc.strip()
            
            # 尝试获取视频 URL
            if not video_info['video_url']:
                video_url = await page.evaluate('''() => {
                    const video = document.querySelector('video');
                    return video ? video.src : null;
                }''')
                if video_url:
                    video_info['video_url'] = video_url
            
            # 尝试获取统计数据
            if video_info['statistics']['digg_count'] == 0:
                digg = await page.evaluate('''() => {
                    const el = document.querySelector('[data-e2e="like-count"]');
                    return el ? el.textContent : null;
                }''')
                if digg:
                    # 转换数字格式（如 1.2 万 -> 12000）
                    digg = digg.strip()
                    if '万' in digg:
                        video_info['statistics']['digg_count'] = int(float(digg.replace('万', '')) * 10000)
                    elif '亿' in digg:
                        video_info['statistics']['digg_count'] = int(float(digg.replace('亿', '')) * 100000000)
                    else:
                        video_info['statistics']['digg_count'] = int(digg)
        
        except Exception as e:
            print(f"解析过程中出错：{e}")
        
        finally:
            await browser.close()
    
    return video_info

def format_duration(seconds):
    """格式化视频时长"""
    if not seconds:
        return "未知"
    minutes = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{minutes}:{secs:02d}"

def format_number(num):
    """格式化数字（如 12000 -> 1.2 万）"""
    if not num:
        return "0"
    num = int(num)
    if num >= 100000000:
        return f"{num / 100000000:.1f}亿"
    elif num >= 10000:
        return f"{num / 10000:.1f}万"
    else:
        return str(num)

async def main():
    parser = argparse.ArgumentParser(description='抖音无水印视频解析器 (Playwright 版)')
    parser.add_argument('url', help='抖音视频链接或 video_id')
    parser.add_argument('--output', '-o', help='下载视频到指定文件')
    parser.add_argument('--json', action='store_true', help='仅输出 JSON')
    args = parser.parse_args()
    
    # 处理 video_id
    if args.url.isdigit():
        url = f"https://www.douyin.com/video/{args.url}"
    else:
        url = args.url
    
    if not args.json:
        print(f"🔍 正在解析视频...")
        print("-" * 50)
    
    # 解析视频
    video_info = await resolve_douyin_video(url)
    
    if args.json:
        print(json.dumps(video_info, ensure_ascii=False, indent=2))
        return
    
    # 输出结果
    print("\n📹 视频信息：")
    print(f"  视频 ID: {video_info.get('video_id', 'N/A')}")
    print(f"  标题：{video_info.get('title', 'N/A') or '无标题'}")
    print(f"  作者：{video_info.get('author', 'N/A')}")
    print(f"  发布时间：{video_info.get('create_time', 'N/A') or '未知'}")
    print(f"  时长：{format_duration(video_info.get('duration', 0))}")
    print(f"  简介：{video_info.get('desc', 'N/A') or '无简介'}")
    
    print("\n📊 互动数据：")
    stats = video_info.get('statistics', {})
    print(f"  👍 点赞：{format_number(stats.get('digg_count', 0))}")
    print(f"  💬 评论：{format_number(stats.get('comment_count', 0))}")
    print(f"  ⭐ 收藏：{format_number(stats.get('collect_count', 0))}")
    print(f"  🔗 分享：{format_number(stats.get('share_count', 0))}")
    
    print("\n🔗 视频地址：")
    video_url = video_info.get('video_url', '')
    if video_url:
        print(f"  无水印下载：{video_url}")
    else:
        print(f"  原始链接：https://www.douyin.com/video/{video_info.get('video_id', '')}")
    
    # 如果指定了输出文件，下载视频
    if args.output and video_url:
        print(f"\n⬇️  正在下载视频到：{args.output}")
        try:
            import requests
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            resp = requests.get(video_url, headers=headers, stream=True, timeout=60)
            with open(args.output, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)
            print(f"✅ 下载完成：{args.output}")
        except Exception as e:
            print(f"❌ 下载失败：{e}")
    
    print("\n" + "=" * 50)
    print("JSON 输出：")
    print(json.dumps(video_info, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    asyncio.run(main())
