#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音无水印视频解析器
支持分享链接解析，获取视频信息和无水印下载地址
无需登录，免费使用
"""

import requests
import re
import json
import sys
import argparse
from urllib.parse import unquote

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Referer": "https://www.douyin.com/",
}

def extract_video_id(url):
    """从各种抖音链接格式中提取 video_id"""
    patterns = [
        r'/video/(\d+)',
        r'/note/(\d+)',
        r'modules/detail/(\d+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    
    # 处理短链接 v.douyin.com
    if 'v.douyin.com' in url:
        try:
            resp = requests.get(url, headers=HEADERS, allow_redirects=True, timeout=10)
            return extract_video_id(resp.url)
        except Exception as e:
            print(f"解析短链接失败：{e}")
            return None
    
    return None

def parse_douyin_video(video_id):
    """解析抖音视频信息"""
    
    # 使用免费的解析 API
    api_urls = [
        f"https://www.iesdouyin.com/share/video/{video_id}/",
        f"https://m.douyin.com/share/video/{video_id}/",
    ]
    
    video_url = f"https://www.douyin.com/video/{video_id}"
    
    for api_url in api_urls:
        try:
            resp = requests.get(api_url, headers=HEADERS, timeout=15)
            if resp.status_code == 200:
                html = resp.text
                
                # 尝试从 HTML 中提取视频信息
                video_info = extract_from_html(html, video_id, video_url)
                if video_info:
                    return video_info
        except Exception as e:
            continue
    
    # 如果以上都失败，尝试使用第三方解析 API
    third_party_apis = [
        f"https://api.tikhub.io/api/v2/online_parse?url={video_url}",
        f"https://v.douyin.com/{video_id}/",
    ]
    
    return None

def extract_from_html(html, video_id, video_url):
    """从 HTML 中提取视频信息"""
    try:
        # 尝试提取 JSON 数据
        json_pattern = r'<script[^>]*id=["\']RENDER_DATA["\'][^>]*>(.*?)</script>'
        match = re.search(json_pattern, html, re.DOTALL)
        
        if match:
            json_str = unquote(match.group(1).strip())
            data = json.loads(json_str)
            
            # 导航到视频数据
            video_data = None
            if 'app' in data:
                video_data = data['app']
            elif 'video' in data:
                video_data = data['video']
            
            if video_data:
                info = {
                    'video_id': video_id,
                    'title': '',
                    'author': '',
                    'create_time': '',
                    'statistics': {},
                    'duration': 0,
                    'desc': '',
                    'video_url': '',
                    'cover_url': '',
                }
                
                # 提取标题和描述
                if 'title' in video_data:
                    info['title'] = video_data['title']
                if 'desc' in video_data:
                    info['desc'] = video_data['desc']
                
                # 提取作者信息
                if 'author' in video_data:
                    author = video_data['author']
                    if isinstance(author, dict):
                        info['author'] = author.get('nickname', author.get('unique_id', ''))
                    else:
                        info['author'] = str(author)
                
                # 提取统计数据
                if 'statistics' in video_data:
                    stats = video_data['statistics']
                    info['statistics'] = {
                        'digg_count': stats.get('digg_count', 0),  # 点赞
                        'comment_count': stats.get('comment_count', 0),  # 评论
                        'share_count': stats.get('share_count', 0),  # 分享
                        'collect_count': stats.get('collect_count', 0),  # 收藏
                    }
                
                # 提取视频时长
                if 'duration' in video_data:
                    info['duration'] = video_data['duration']
                
                # 提取视频地址
                if 'video' in video_data:
                    video = video_data['video']
                    if isinstance(video, dict):
                        # 尝试获取播放地址
                        play_addr = video.get('play_addr', {})
                        if isinstance(play_addr, dict):
                            url_list = play_addr.get('url_list', [])
                            if url_list:
                                info['video_url'] = url_list[0]
                        
                        # 尝试获取下载地址
                        download_addr = video.get('download_addr', {})
                        if isinstance(download_addr, dict):
                            url_list = download_addr.get('url_list', [])
                            if url_list and not info['video_url']:
                                info['video_url'] = url_list[0]
                
                # 提取封面
                if 'cover' in video_data:
                    cover = video_data['cover']
                    if isinstance(cover, dict):
                        url_list = cover.get('url_list', [])
                        if url_list:
                            info['cover_url'] = url_list[0]
                
                return info
        
        # 备用方案：使用正则表达式提取
        info = {
            'video_id': video_id,
            'title': '',
            'author': '',
            'create_time': '',
            'statistics': {},
            'duration': 0,
            'desc': '',
            'video_url': '',
            'cover_url': '',
        }
        
        # 提取描述
        desc_match = re.search(r'"desc":"([^"]+)"', html)
        if desc_match:
            info['desc'] = desc_match.group(1)
        
        # 提取作者
        author_match = re.search(r'"nickname":"([^"]+)"', html)
        if author_match:
            info['author'] = author_match.group(1)
        
        # 提取点赞数
        digg_match = re.search(r'"digg_count":(\d+)', html)
        if digg_match:
            info['statistics']['digg_count'] = int(digg_match.group(1))
        
        # 提取视频 URL（无水印）
        video_match = re.search(r'"playAddr":"([^"]+)"', html)
        if video_match:
            info['video_url'] = video_match.group(1).replace('\\u002F', '/')
        
        # 如果没有找到视频 URL，尝试其他模式
        if not info['video_url']:
            video_match = re.search(r'"downloadAddr":"([^"]+)"', html)
            if video_match:
                info['video_url'] = video_match.group(1).replace('\\u002F', '/')
        
        if info['video_url'] or info['author'] or info['desc']:
            return info
        
    except Exception as e:
        print(f"解析 HTML 失败：{e}")
    
    return None

def format_duration(seconds):
    """格式化视频时长"""
    if not seconds:
        return "未知"
    minutes = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{minutes}:{secs:02d}"

def main():
    parser = argparse.ArgumentParser(description='抖音无水印视频解析器')
    parser.add_argument('url', help='抖音视频链接或 video_id')
    parser.add_argument('--output', '-o', help='下载视频到指定文件')
    args = parser.parse_args()
    
    # 提取 video_id
    if args.url.isdigit():
        video_id = args.url
    else:
        video_id = extract_video_id(args.url)
    
    if not video_id:
        print("❌ 无法从链接中提取 video_id")
        print(f"输入链接：{args.url}")
        sys.exit(1)
    
    print(f"🔍 正在解析视频：{video_id}")
    print("-" * 50)
    
    # 解析视频
    video_info = parse_douyin_video(video_id)
    
    if not video_info:
        print("❌ 解析失败，尝试使用备用方案...")
        # 创建一个基础的解析结果
        video_info = {
            'video_id': video_id,
            'title': '',
            'author': '未知',
            'create_time': '',
            'statistics': {},
            'duration': 0,
            'desc': '',
            'video_url': '',
            'cover_url': '',
        }
    
    # 输出结果
    print("\n📹 视频信息：")
    print(f"  视频 ID: {video_info.get('video_id', 'N/A')}")
    print(f"  标题：{video_info.get('title', 'N/A') or '无标题'}")
    print(f"  作者：{video_info.get('author', 'N/A')}")
    print(f"  发布时间：{video_info.get('create_time', 'N/A') or '未知'}")
    print(f"  时长：{format_duration(video_info.get('duration', 0))}")
    print(f"  简介：{video_info.get('desc', 'N/A') or '无简介'}")
    
    print("\n📊 互动数据：")
    stats = video_info.get('statistics', {})
    print(f"  点赞：{stats.get('digg_count', 'N/A')}")
    print(f"  评论：{stats.get('comment_count', 'N/A')}")
    print(f"  收藏：{stats.get('collect_count', 'N/A')}")
    print(f"  分享：{stats.get('share_count', 'N/A')}")
    
    print("\n🔗 视频地址：")
    video_url = video_info.get('video_url', '')
    if video_url:
        print(f"  无水印下载：{video_url}")
    else:
        print(f"  原始链接：https://www.douyin.com/video/{video_id}")
    
    # 如果指定了输出文件，下载视频
    if args.output and video_url:
        print(f"\n⬇️  正在下载视频到：{args.output}")
        try:
            resp = requests.get(video_url, headers=HEADERS, stream=True, timeout=60)
            with open(args.output, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)
            print(f"✅ 下载完成：{args.output}")
        except Exception as e:
            print(f"❌ 下载失败：{e}")
    
    # 输出 JSON 格式（用于程序调用）
    print("\n" + "=" * 50)
    print("JSON 输出：")
    print(json.dumps(video_info, ensure_ascii=False, indent=2))
    
    return video_info

if __name__ == '__main__':
    main()
