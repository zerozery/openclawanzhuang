#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音无水印视频解析器 - API 版
使用多个免费解析 API，提高成功率
"""

import requests
import re
import json
import sys
import argparse
import time

# 通用的 Headers
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Referer": "https://www.douyin.com/",
}

# 免费解析 API 列表
FREE_APIS = [
    # 方案 1: 使用抖音官方分享接口
    lambda video_id: f"https://www.iesdouyin.com/share/video/{video_id}/",
    # 方案 2: 移动端接口
    lambda video_id: f"https://m.douyin.com/share/video/{video_id}/",
    # 方案 3: 微头条接口
    lambda video_id: f"https://www.douyin.com/share/video/{video_id}/",
]

def extract_video_id(url):
    """从各种抖音链接格式中提取 video_id"""
    # 处理短链接 - 跟随重定向
    if 'v.douyin.com' in url:
        try:
            session = requests.Session()
            resp = session.get(url, headers=HEADERS, allow_redirects=True, timeout=15)
            url = resp.url
            print(f"  重定向到：{url}")
        except Exception as e:
            print(f"  短链接解析失败：{e}")
    
    # 从 URL 提取 video_id
    patterns = [
        r'/video/(\d+)',
        r'/note/(\d+)',
        r'modules/detail/(\d+)',
        r'video_id=(\d+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1), url
    
    return None, url

def parse_with_api(api_url):
    """使用特定 API 解析"""
    try:
        # 使用 Session 保持 Cookie
        session = requests.Session()
        
        resp = session.get(api_url, headers=HEADERS, timeout=15, allow_redirects=True)
        html = resp.text
        
        # 尝试提取 JSON 数据
        return extract_from_html(html)
    except Exception as e:
        print(f"  API 失败：{e}")
        return None

def extract_from_html(html):
    """从 HTML 中提取视频信息"""
    from urllib.parse import unquote
    
    video_info = {
        'video_id': '',
        'title': '',
        'author': '',
        'create_time': '',
        'statistics': {
            'digg_count': 0,
            'comment_count': 0,
            'share_count': 0,
            'collect_count': 0,
        },
        'duration': 0,
        'desc': '',
        'video_url': '',
        'cover_url': '',
    }
    
    # 方法 1: 提取 RENDER_DATA
    json_patterns = [
        r'<script[^>]*id=["\']RENDER_DATA["\'][^>]*>(.*?)</script>',
        r'<script[^>]*>\s*window\._ROUTER_DATA\s*=\s*(\{.*?\})\s*</script>',
        r'<script[^>]*>\s*window\.__INITIAL_STATE__\s*=\s*(\{.*?\})\s*</script>',
    ]
    
    for pattern in json_patterns:
        match = re.search(pattern, html, re.DOTALL | re.IGNORECASE)
        if match:
            try:
                json_str = match.group(1).strip()
                # 清理 HTML
                json_str = re.sub(r'^.*?>', '', json_str)
                json_str = re.sub(r'</.*$', '', json_str)
                json_str = unquote(json_str)
                
                data = json.loads(json_str)
                
                # 导航到视频数据
                video_data = navigate_json(data)
                if video_data:
                    return extract_from_data(video_data)
            except Exception as e:
                continue
    
    # 方法 2: 正则表达式提取
    return extract_with_regex(html)

def navigate_json(data):
    """在 JSON 中导航到视频数据"""
    if not isinstance(data, dict):
        return None
    
    # 尝试常见路径
    paths = [
        ['app', 'video'],
        ['video'],
        ['detail'],
        ['data'],
        ['result'],
    ]
    
    for path in paths:
        current = data
        for key in path:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                break
        else:
            if isinstance(current, dict):
                return current
    
    # 搜索包含视频信息的键
    for key, value in data.items():
        if isinstance(value, dict):
            if 'author' in value or 'desc' in value or 'statistics' in value:
                return value
    
    return data

def extract_from_data(data):
    """从数据字典中提取信息"""
    video_info = {
        'video_id': '',
        'title': '',
        'author': '',
        'create_time': '',
        'statistics': {
            'digg_count': 0,
            'comment_count': 0,
            'share_count': 0,
            'collect_count': 0,
        },
        'duration': 0,
        'desc': '',
        'video_url': '',
        'cover_url': '',
    }
    
    # 提取标题
    video_info['title'] = data.get('title', '')
    
    # 提取描述
    video_info['desc'] = data.get('desc', '')
    
    # 提取作者
    author = data.get('author', {})
    if isinstance(author, dict):
        video_info['author'] = author.get('nickname', author.get('unique_id', ''))
    elif isinstance(author, str):
        video_info['author'] = author
    
    # 提取统计数据
    stats = data.get('statistics', {})
    if isinstance(stats, dict):
        video_info['statistics'] = {
            'digg_count': stats.get('digg_count', 0),
            'comment_count': stats.get('comment_count', 0),
            'share_count': stats.get('share_count', 0),
            'collect_count': stats.get('collect_count', 0),
        }
    
    # 提取时长
    video_info['duration'] = data.get('duration', 0)
    
    # 提取视频 URL
    video_obj = data.get('video', {})
    if isinstance(video_obj, dict):
        play_addr = video_obj.get('play_addr', {})
        if isinstance(play_addr, dict):
            url_list = play_addr.get('url_list', [])
            if isinstance(url_list, list) and url_list:
                video_info['video_url'] = url_list[0]
        
        if not video_info['video_url']:
            download_addr = video_obj.get('download_addr', {})
            if isinstance(download_addr, dict):
                url_list = download_addr.get('url_list', [])
                if isinstance(url_list, list) and url_list:
                    video_info['video_url'] = url_list[0]
    
    # 提取封面
    cover = data.get('cover', {})
    if isinstance(cover, dict):
        url_list = cover.get('url_list', [])
        if isinstance(url_list, list) and url_list:
            video_info['cover_url'] = url_list[0]
    
    return video_info

def extract_with_regex(html):
    """使用正则表达式提取"""
    from urllib.parse import unquote
    
    video_info = {
        'video_id': '',
        'title': '',
        'author': '',
        'create_time': '',
        'statistics': {},
        'duration': 0,
        'desc': '',
        'video_url': '',
        'cover_url': '',
    }
    
    patterns = {
        'desc': r'"desc"\s*:\s*"([^"]*)"',
        'nickname': r'"nickname"\s*:\s*"([^"]*)"',
        'digg_count': r'"digg_count"\s*:\s*(\d+)',
        'comment_count': r'"comment_count"\s*:\s*(\d+)',
        'share_count': r'"share_count"\s*:\s*(\d+)',
        'collect_count': r'"collect_count"\s*:\s*(\d+)',
        'playAddr': r'"playAddr"\s*:\s*"([^"]*)"',
        'downloadAddr': r'"downloadAddr"\s*:\s*"([^"]*)"',
    }
    
    for key, pattern in patterns.items():
        match = re.search(pattern, html)
        if match:
            value = unquote(match.group(1))
            value = value.replace('\\u002F', '/')
            
            if key == 'desc':
                video_info['desc'] = value
            elif key == 'nickname':
                video_info['author'] = value
            elif key.endswith('_count'):
                stat_key = key.replace('_count', '_count')
                video_info['statistics'][stat_key] = int(value)
            elif key in ['playAddr', 'downloadAddr']:
                if not video_info['video_url']:
                    video_info['video_url'] = value
    
    # 检查是否有有效信息
    if video_info['author'] or video_info['desc'] or video_info['video_url']:
        return video_info
    
    return None

def format_duration(seconds):
    """格式化视频时长"""
    if not seconds:
        return "未知"
    minutes = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{minutes}:{secs:02d}"

def format_number(num):
    """格式化数字"""
    if not num:
        return "0"
    num = int(num)
    if num >= 100000000:
        return f"{num / 100000000:.1f}亿"
    elif num >= 10000:
        return f"{num / 10000:.1f}万"
    else:
        return str(num)

def main():
    parser = argparse.ArgumentParser(description='抖音无水印视频解析器 (API 版)')
    parser.add_argument('url', help='抖音视频链接或 video_id')
    parser.add_argument('--output', '-o', help='下载视频到指定文件')
    parser.add_argument('--json', action='store_true', help='仅输出 JSON')
    args = parser.parse_args()
    
    # 处理 video_id
    if args.url.isdigit():
        video_id = args.url
        original_url = f"https://www.douyin.com/video/{video_id}"
    else:
        video_id, original_url = extract_video_id(args.url)
        if not video_id:
            print("❌ 无法从链接中提取 video_id")
            sys.exit(1)
    
    if not args.json:
        print(f"🔍 正在解析视频：{video_id}")
        print("-" * 50)
    
    # 尝试多个 API
    video_info = None
    for i, api_factory in enumerate(FREE_APIS, 1):
        api_url = api_factory(video_id)
        if not args.json:
            print(f"  尝试 API {i}: {api_url[:60]}...")
        
        video_info = parse_with_api(api_url)
        if video_info and (video_info.get('author') or video_info.get('video_url')):
            if not args.json:
                print(f"  ✅ API {i} 成功!")
            break
        
        # 等待一下再试下一个
        time.sleep(0.5)
    
    # 如果都失败，创建基础结果
    if not video_info:
        video_info = {
            'video_id': video_id,
            'title': '',
            'author': '未知',
            'create_time': '',
            'statistics': {},
            'duration': 0,
            'desc': '',
            'video_url': '',
            'cover_url': '',
        }
        if not args.json:
            print("⚠️  所有 API 都失败，返回基础信息")
    
    # 确保 video_id 正确
    if not video_info.get('video_id'):
        video_info['video_id'] = video_id
    
    if args.json:
        print(json.dumps(video_info, ensure_ascii=False, indent=2))
        return
    
    # 输出结果
    print("\n📹 视频信息：")
    print(f"  视频 ID: {video_info.get('video_id', 'N/A')}")
    print(f"  标题：{video_info.get('title', 'N/A') or '无标题'}")
    print(f"  作者：{video_info.get('author', 'N/A')}")
    print(f"  发布时间：{video_info.get('create_time', 'N/A') or '未知'}")
    print(f"  时长：{format_duration(video_info.get('duration', 0))}")
    print(f"  简介：{video_info.get('desc', 'N/A') or '无简介'}")
    
    print("\n📊 互动数据：")
    stats = video_info.get('statistics', {})
    print(f"  👍 点赞：{format_number(stats.get('digg_count', 0))}")
    print(f"  💬 评论：{format_number(stats.get('comment_count', 0))}")
    print(f"  ⭐ 收藏：{format_number(stats.get('collect_count', 0))}")
    print(f"  🔗 分享：{format_number(stats.get('share_count', 0))}")
    
    print("\n🔗 视频地址：")
    video_url = video_info.get('video_url', '')
    if video_url:
        print(f"  无水印下载：{video_url}")
    else:
        print(f"  原始链接：https://www.douyin.com/video/{video_id}")
    
    # 如果指定了输出文件，下载视频
    if args.output and video_url:
        print(f"\n⬇️  正在下载视频到：{args.output}")
        try:
            resp = requests.get(video_url, headers=HEADERS, stream=True, timeout=60)
            with open(args.output, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)
            print(f"✅ 下载完成：{args.output}")
        except Exception as e:
            print(f"❌ 下载失败：{e}")
    
    print("\n" + "=" * 50)
    print("JSON 输出：")
    print(json.dumps(video_info, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
