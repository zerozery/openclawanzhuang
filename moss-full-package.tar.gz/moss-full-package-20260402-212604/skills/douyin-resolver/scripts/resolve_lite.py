#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音无水印视频解析器 - 轻量版
使用抖音官方移动 API，无需浏览器
"""

import requests
import re
import json
import sys
import argparse
from urllib.parse import urlparse, parse_qs

# 抖音移动端 Headers
MOBILE_HEADERS = {
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh-Hans;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}

# 桌面端 Headers
DESKTOP_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Referer": "https://www.douyin.com/",
}

def extract_video_id(url):
    """从各种抖音链接格式中提取 video_id"""
    # 处理短链接
    if 'v.douyin.com' in url or 'douyin.com' in url:
        try:
            # 跟随重定向
            resp = requests.get(url, headers=MOBILE_HEADERS, allow_redirects=True, timeout=15)
            final_url = resp.url
            
            # 从最终 URL 提取 video_id
            patterns = [
                r'/video/(\d+)',
                r'/note/(\d+)',
                r'modules/detail/(\d+)',
            ]
            
            for pattern in patterns:
                match = re.search(pattern, final_url)
                if match:
                    return match.group(1), final_url
        except Exception as e:
            print(f"解析短链接失败：{e}")
    
    return None, url

def parse_mobile_page(url):
    """解析抖音移动端页面"""
    try:
        resp = requests.get(url, headers=MOBILE_HEADERS, timeout=15)
        html = resp.text
        
        return extract_info_from_html(html)
    except Exception as e:
        print(f"移动端解析失败：{e}")
        return None

def parse_desktop_page(url):
    """解析抖音桌面端页面"""
    try:
        resp = requests.get(url, headers=DESKTOP_HEADERS, timeout=15)
        html = resp.text
        
        return extract_info_from_html(html)
    except Exception as e:
        print(f"桌面端解析失败：{e}")
        return None

def extract_info_from_html(html):
    """从 HTML 中提取视频信息"""
    import re
    from urllib.parse import unquote
    
    video_info = {
        'video_id': '',
        'title': '',
        'author': '',
        'create_time': '',
        'statistics': {
            'digg_count': 0,
            'comment_count': 0,
            'share_count': 0,
            'collect_count': 0,
        },
        'duration': 0,
        'desc': '',
        'video_url': '',
        'cover_url': '',
    }
    
    # 尝试 1: 提取 RENDER_DATA JSON
    json_pattern = r'<script[^>]*id=["\']RENDER_DATA["\'][^>]*>(.*?)</script>'
    match = re.search(json_pattern, html, re.DOTALL | re.IGNORECASE)
    
    if match:
        try:
            json_str = match.group(1).strip()
            # 清理 HTML 标签
            json_str = re.sub(r'^.*?>', '', json_str)
            json_str = re.sub(r'</.*$', '', json_str)
            # URL 解码
            json_str = unquote(json_str)
            
            data = json.loads(json_str)
            
            # 导航到视频数据
            video_data = None
            if 'app' in data:
                video_data = data['app'].get('video', {})
            elif 'video' in data:
                video_data = data['video']
            elif 'detail' in data:
                video_data = data['detail']
            
            if video_data and isinstance(video_data, dict):
                # 提取标题
                video_info['title'] = video_data.get('title', '')
                
                # 提取描述
                video_info['desc'] = video_data.get('desc', '')
                
                # 提取作者
                author = video_data.get('author', {})
                if isinstance(author, dict):
                    video_info['author'] = author.get('nickname', author.get('unique_id', ''))
                elif isinstance(author, str):
                    video_info['author'] = author
                
                # 提取统计数据
                stats = video_data.get('statistics', {})
                if isinstance(stats, dict):
                    video_info['statistics'] = {
                        'digg_count': stats.get('digg_count', 0),
                        'comment_count': stats.get('comment_count', 0),
                        'share_count': stats.get('share_count', 0),
                        'collect_count': stats.get('collect_count', 0),
                    }
                
                # 提取时长
                video_info['duration'] = video_data.get('duration', 0)
                
                # 提取视频 URL
                video_obj = video_data.get('video', {})
                if isinstance(video_obj, dict):
                    play_addr = video_obj.get('play_addr', {})
                    if isinstance(play_addr, dict):
                        url_list = play_addr.get('url_list', [])
                        if url_list and isinstance(url_list, list):
                            video_info['video_url'] = url_list[0]
                    
                    if not video_info['video_url']:
                        download_addr = video_obj.get('download_addr', {})
                        if isinstance(download_addr, dict):
                            url_list = download_addr.get('url_list', [])
                            if url_list and isinstance(url_list, list):
                                video_info['video_url'] = url_list[0]
                
                # 提取封面
                cover = video_data.get('cover', {})
                if isinstance(cover, dict):
                    url_list = cover.get('url_list', [])
                    if url_list and isinstance(url_list, list):
                        video_info['cover_url'] = url_list[0]
                
                return video_info
        except Exception as e:
            print(f"JSON 解析失败：{e}")
    
    # 尝试 2: 使用正则表达式提取
    # 提取描述
    desc_match = re.search(r'"desc"\s*:\s*"([^"]*)"', html)
    if desc_match:
        video_info['desc'] = unquote(desc_match.group(1))
    
    # 提取作者
    author_match = re.search(r'"nickname"\s*:\s*"([^"]*)"', html)
    if author_match:
        video_info['author'] = unquote(author_match.group(1))
    
    # 提取点赞数
    digg_match = re.search(r'"digg_count"\s*:\s*(\d+)', html)
    if digg_match:
        video_info['statistics']['digg_count'] = int(digg_match.group(1))
    
    # 提取评论数
    comment_match = re.search(r'"comment_count"\s*:\s*(\d+)', html)
    if comment_match:
        video_info['statistics']['comment_count'] = int(comment_match.group(1))
    
    # 提取视频 URL
    video_match = re.search(r'"playAddr"\s*:\s*"([^"]*)"', html)
    if video_match:
        video_info['video_url'] = unquote(video_match.group(1).replace('\\u002F', '/'))
    
    if not video_info['video_url']:
        video_match = re.search(r'"downloadAddr"\s*:\s*"([^"]*)"', html)
        if video_match:
            video_info['video_url'] = unquote(video_match.group(1).replace('\\u002F', '/'))
    
    # 检查是否有有效信息
    if video_info['author'] or video_info['desc'] or video_info['video_url']:
        return video_info
    
    return None

def format_duration(seconds):
    """格式化视频时长"""
    if not seconds:
        return "未知"
    minutes = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{minutes}:{secs:02d}"

def format_number(num):
    """格式化数字"""
    if not num:
        return "0"
    num = int(num)
    if num >= 100000000:
        return f"{num / 100000000:.1f}亿"
    elif num >= 10000:
        return f"{num / 10000:.1f}万"
    else:
        return str(num)

def main():
    parser = argparse.ArgumentParser(description='抖音无水印视频解析器 (轻量版)')
    parser.add_argument('url', help='抖音视频链接或 video_id')
    parser.add_argument('--output', '-o', help='下载视频到指定文件')
    parser.add_argument('--json', action='store_true', help='仅输出 JSON')
    args = parser.parse_args()
    
    # 处理 video_id
    if args.url.isdigit():
        video_id = args.url
        url = f"https://www.douyin.com/video/{video_id}"
    else:
        video_id, url = extract_video_id(args.url)
        if not video_id:
            print("❌ 无法从链接中提取 video_id")
            sys.exit(1)
    
    if not args.json:
        print(f"🔍 正在解析视频：{video_id}")
        print("-" * 50)
    
    # 尝试多种解析方式
    video_info = None
    
    # 1. 先尝试移动端
    if not args.json:
        print("📱 尝试移动端解析...")
    video_info = parse_mobile_page(url)
    
    # 2. 如果失败，尝试桌面端
    if not video_info:
        if not args.json:
            print("💻 尝试桌面端解析...")
        video_info = parse_desktop_page(url)
    
    # 3. 如果都失败，创建一个基础结果
    if not video_info:
        video_info = {
            'video_id': video_id,
            'title': '',
            'author': '未知',
            'create_time': '',
            'statistics': {},
            'duration': 0,
            'desc': '',
            'video_url': '',
            'cover_url': '',
        }
        if not args.json:
            print("⚠️ 解析失败，返回基础信息")
    
    # 确保 video_id 正确
    if not video_info.get('video_id'):
        video_info['video_id'] = video_id
    
    if args.json:
        print(json.dumps(video_info, ensure_ascii=False, indent=2))
        return
    
    # 输出结果
    print("\n📹 视频信息：")
    print(f"  视频 ID: {video_info.get('video_id', 'N/A')}")
    print(f"  标题：{video_info.get('title', 'N/A') or '无标题'}")
    print(f"  作者：{video_info.get('author', 'N/A')}")
    print(f"  发布时间：{video_info.get('create_time', 'N/A') or '未知'}")
    print(f"  时长：{format_duration(video_info.get('duration', 0))}")
    print(f"  简介：{video_info.get('desc', 'N/A') or '无简介'}")
    
    print("\n📊 互动数据：")
    stats = video_info.get('statistics', {})
    print(f"  👍 点赞：{format_number(stats.get('digg_count', 0))}")
    print(f"  💬 评论：{format_number(stats.get('comment_count', 0))}")
    print(f"  ⭐ 收藏：{format_number(stats.get('collect_count', 0))}")
    print(f"  🔗 分享：{format_number(stats.get('share_count', 0))}")
    
    print("\n🔗 视频地址：")
    video_url = video_info.get('video_url', '')
    if video_url:
        print(f"  无水印下载：{video_url}")
    else:
        print(f"  原始链接：https://www.douyin.com/video/{video_id}")
    
    # 如果指定了输出文件，下载视频
    if args.output and video_url:
        print(f"\n⬇️  正在下载视频到：{args.output}")
        try:
            resp = requests.get(video_url, headers=DESKTOP_HEADERS, stream=True, timeout=60)
            with open(args.output, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)
            print(f"✅ 下载完成：{args.output}")
        except Exception as e:
            print(f"❌ 下载失败：{e}")
    
    print("\n" + "=" * 50)
    print("JSON 输出：")
    print(json.dumps(video_info, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
