#!/bin/bash
# 每周 Skills 探索 - 每周一 10:00 搜索 ClawHub/GitHub 上的新 skills

# 加载配置
source ~/.openclaw/workspace/scripts/env.sh 2>/dev/null || true

# 生成消息
MESSAGE="🔍 每周 Skills 探索报告

📅 日期：$(date +%Y-%m-%d)
🎯 任务：搜索 ClawHub/GitHub 上的新 skills

【本周重点】
1. AI 代理框架
2. 内容创作工具
3. 自动化工作流

【风险提示】
⚠️ 权限要求：是否需要 elevated tools
🔒 代码来源：官方/社区/个人
📊 社区活跃度：下载量/星标数
📅 最后更新时间

【推荐流程】
MOSS 推荐 → 用户审批 → 安装执行

需要我详细搜索某个方向的 skills 吗？随时告诉我！🌿"

# 发送到飞书
echo "$MESSAGE" | openclaw message send --target "user:ou_387beeed74b9770a92c3d8705f25280b" --channel feishu

# 记录日志
echo "$(date '+%Y-%m-%d %H:%M:%S') - 每周 Skills 探索已发送" >> /root/.openclaw/workspace/logs/skills-exploration.log
