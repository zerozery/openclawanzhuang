# Daily Finance News Fetcher

## 概述
这个脚本每天自动获取财经新闻，包括：
- 黄金价格走势
- 股市行情
- 大宗商品价格
- 财经大事预告

## 使用方法

### 方式1: 使用 OpenClaw Cron (推荐)
设置定时任务，每天早上9点自动获取新闻：

```bash
openclaw cron create --name finance-news --schedule "0 9 * * *" --command "node ~/.openclaw/workspace/scripts/fetch_news.mjs"
```

### 方式2: 手动运行
```bash
node ~/.openclaw/workspace/scripts/fetch_news.mjs
```

### 方式3: 配置 Tavily (获取更精准的新闻)
1. 访问 https://tavily.com 获取免费 API key
2. 配置环境变量:
   ```bash
   export TAVILY_API_KEY=your_api_key
   ```
3. 使用 Tavily 搜索获取精准新闻:
   ```bash
   node ~/.openclaw/workspace/skills/tavily-search/scripts/search.mjs "黄金价格 股市行情" --topic news -n 10
   ```

## 数据源

1. **财联社 (CLS.CN)** - 财经新闻和事件日历
2. **生意社 (100PPI)** - 大宗商品价格
3. **新浪财经** - 股票基金行情
4. **东方财富** - A股港股美股数据

## 注意事项

- 本脚本仅供信息参考，不构成投资建议
- 股市有风险，投资需谨慎
- 数据可能存在延迟
