#!/bin/bash
# OpenClaw 配置验证脚本
# 用法：./validate-config.sh [配置文件路径]

CONFIG_FILE=${1:-"$HOME/.openclaw/openclaw.json"}

echo "🔍 验证配置文件：$CONFIG_FILE"

# 检查文件存在
if [ ! -f "$CONFIG_FILE" ]; then
    echo "❌ 文件不存在：$CONFIG_FILE"
    exit 1
fi

# JSON 语法验证
if command -v jq &> /dev/null; then
    if jq empty "$CONFIG_FILE" 2>/dev/null; then
        echo "✅ JSON 语法正确"
    else
        echo "❌ JSON 语法错误"
        jq . "$CONFIG_FILE" 2>&1 | head -5
        exit 1
    fi
elif command -v node &> /dev/null; then
    if node -e "JSON.parse(require('fs').readFileSync('$CONFIG_FILE'))" 2>/dev/null; then
        echo "✅ JSON 语法正确"
    else
        echo "❌ JSON 语法错误"
        exit 1
    fi
else
    echo "⚠️  未找到 jq 或 node，跳过语法检查"
fi

# 检查关键字段
echo ""
echo "📋 关键配置检查:"

# 检查 gateway 配置
if grep -q '"gateway"' "$CONFIG_FILE"; then
    echo "  ✅ gateway 配置存在"
else
    echo "  ⚠️  gateway 配置缺失"
fi

# 检查 channels 配置
if grep -q '"channels"' "$CONFIG_FILE"; then
    echo "  ✅ channels 配置存在"
else
    echo "  ⚠️  channels 配置缺失"
fi

# 检查 models 配置
if grep -q '"models"' "$CONFIG_FILE"; then
    echo "  ✅ models 配置存在"
else
    echo "  ⚠️  models 配置缺失"
fi

echo ""
echo "✅ 配置验证完成"
exit 0
