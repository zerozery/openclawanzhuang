#!/bin/bash
# OpenClaw 图片服务器 - 稳定启动脚本

PID_FILE="/tmp/image-server.pid"
LOG_FILE="/tmp/image-server.log"

# 检查是否已在运行
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if ps -p $OLD_PID > /dev/null 2>&1; then
        echo "ℹ️  服务器已在运行 (PID: $OLD_PID)"
        exit 0
    fi
fi

# 启动服务器
cd /tmp
nohup python3 -m http.server 8080 > "$LOG_FILE" 2>&1 &
NEW_PID=$!

# 保存 PID
echo $NEW_PID > "$PID_FILE"

# 等待启动
sleep 2

# 检查是否启动成功
if ps -p $NEW_PID > /dev/null 2>&1; then
    echo "✅ 图片服务器已启动"
    echo "📁 目录：/tmp"
    echo "🌐 访问：http://localhost:8080"
    echo "📊 PID: $NEW_PID"
    echo ""
    echo "停止命令：kill $NEW_PID"
else
    echo "❌ 启动失败"
    exit 1
fi
