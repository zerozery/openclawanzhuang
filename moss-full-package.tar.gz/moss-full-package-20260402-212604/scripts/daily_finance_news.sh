#!/bin/bash
# 每日财经新闻获取脚本
# 获取时间: $(date '+%Y-%m-%d %H:%M:%S')

echo "📊 每日财经新闻简报 - $(date '+%Y年%m月%d日')"
echo "================================================"
echo ""

# 财联社 - 财经日历
echo "📅 【近期财经大事预告】"
curl -s "https://www.cls.cn/" 2>/dev/null | grep -oP '(?<=<title>)[^<]+' | head -1
echo ""

# 生意社 - 大宗商品
echo "📈 【大宗商品价格】"
echo "查看: https://www.100ppi.com/"
echo ""

# 新浪财经
echo "💹 【股市行情】"
echo "查看: https://finance.sina.com.cn/stock/"
echo ""

echo "================================================"
echo "数据来源: 财联社、生意社、新浪财经"
