# 飞书财经新闻推送配置

## 配置步骤

### 1. 获取飞书目标ID

你需要提供以下之一：
- **个人聊天**: 你的飞书 open_id
- **群聊**: 群聊的 chat_id

获取方法：
1. 在飞书开发者后台: https://open.feishu.cn/app
2. 查看机器人所在的群聊或用户信息

### 2. 配置到脚本

编辑 `~/.openclaw/workspace/scripts/daily_finance_news_feishu_sender.mjs`

找到这行：
```javascript
const FEISHU_TARGET = process.env.FEISHU_TARGET || '';
```

改为你的目标ID：
```javascript
const FEISHU_TARGET = process.env.FEISHU_TARGET || '你的_chat_id_或_open_id';
```

### 3. 测试发送

```bash
cd ~/.openclaw/workspace && node scripts/daily_finance_news_feishu_sender.mjs
```

## 当前状态

- ✅ Tavily API 已配置
- ✅ 定时任务已设置（每天早上9点）
- ⏳ 等待飞书目标ID

## 手动查看新闻

新闻报告也会保存到：
```
/root/.openclaw/workspace/reports/daily_finance_news.txt
```

你可以随时查看这个文件获取最新新闻。
