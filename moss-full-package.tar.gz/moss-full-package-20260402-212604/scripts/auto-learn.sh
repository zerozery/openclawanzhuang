#!/bin/bash
# MOSS 自主学习脚本 - 每日技能搜索和推荐
# 用法：./auto-learn.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE="$HOME/.openclaw/workspace"
LEARNINGS_DIR="$WORKSPACE/.learnings"
REPORT_FILE="$LEARNINGS_DIR/auto-learn-$(date +%Y%m%d).md"

# 搜索关键词列表（围绕变现目标）
SEARCH_KEYWORDS=(
    "video"
    "content"
    "social"
    "image"
    "automation"
    "xiaohongshu"
    "douyin"
    "self-improvement"
)

echo "🌿 MOSS 自主学习 - $(date)"
echo "======================================"

# 创建报告
cat > "$REPORT_FILE" << EOF
# MOSS 自主学习报告

**日期**: $(date +%Y-%m-%d %H:%M)
**目标**: 围绕变现目标的技能发现和安装

---

## 搜索进度

EOF

for keyword in "${SEARCH_KEYWORDS[@]}"; do
    echo "🔍 搜索：$keyword"
    echo "" >> "$REPORT_FILE"
    echo "### 关键词：$keyword" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    
    # 搜索技能
    result=$(clawhub search "$keyword" 2>&1 | head -15) || {
        echo "⚠️  Rate limit 或网络错误，跳过..." >> "$REPORT_FILE"
        echo "⚠️  Rate limit，继续下一个..." 
        continue
    }
    
    echo "$result" >> "$REPORT_FILE"
    echo "✅ 完成"
    sleep 5  # 避免 rate limit
done

echo ""
echo "📊 生成报告：$REPORT_FILE"
echo "✅ 自主学习完成"

# 显示报告摘要
echo ""
echo "======================================"
echo "今日发现（前 5 个）:"
grep -E "^[a-z]" "$REPORT_FILE" | head -5 || echo "暂无结果"
