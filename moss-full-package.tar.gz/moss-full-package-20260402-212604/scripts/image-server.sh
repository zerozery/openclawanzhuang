#!/bin/bash
# OpenClaw 图片 HTTP 服务器
# 用法：./image-server.sh [端口]

PORT=${1:-8080}
IMAGE_DIR="/tmp"

echo "🖼️  OpenClaw 图片 HTTP 服务器"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📁 图片目录：$IMAGE_DIR"
echo "🌐 访问地址："
echo "   本地：http://localhost:$PORT"
echo "   远程：http://$(hostname -I | awk '{print $1}'):$PORT"
echo ""
echo "📸 当前图片："
ls -lh $IMAGE_DIR/*.png $IMAGE_DIR/*.jpg $IMAGE_DIR/*.jpeg $IMAGE_DIR/*.gif 2>/dev/null | awk '{print "   " $9 " (" $5 ")"}' || echo "   (暂无图片)"
echo ""
echo "💡 提示："
echo "   - 将图片复制到 $IMAGE_DIR 后刷新页面"
echo "   - 按 Ctrl+C 停止服务器"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

cd $IMAGE_DIR
python3 -m http.server $PORT
