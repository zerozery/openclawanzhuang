#!/bin/bash
# OpenClaw 配置备份脚本
# 用法：./backup-config.sh [备注]

BACKUP_DIR="$HOME/.openclaw/backups"
CONFIG_FILE="$HOME/.openclaw/openclaw.json"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
NOTE=${1:-"manual"}

# 创建备份目录
mkdir -p "$BACKUP_DIR"

# 备份配置文件
if [ -f "$CONFIG_FILE" ]; then
    cp "$CONFIG_FILE" "$BACKUP_DIR/openclaw.$TIMESTAMP.$NOTE.json"
    echo "✅ 配置已备份：$BACKUP_DIR/openclaw.$TIMESTAMP.$NOTE.json"
    
    # 保留最近 10 个备份
    ls -t "$BACKUP_DIR"/openclaw.*.json | tail -n +11 | xargs -r rm
    echo "🧹 已清理旧备份（保留最近 10 个）"
else
    echo "❌ 配置文件不存在：$CONFIG_FILE"
    exit 1
fi
