#!/bin/bash
# Auto Memory Capture - 自动捕获会话关键信息到记忆文件

WORKSPACE="/root/.openclaw/workspace"
MEMORY_DIR="$WORKSPACE/memory"
TODAY=$(date +%Y-%m-%d)
TODAY_FILE="$MEMORY_DIR/${TODAY}.md"
SESSION_HISTORY="$WORKSPACE/logs/session-history.txt"

echo "=== Auto Memory Capture ==="
echo "时间：$(date)"
echo "目标文件：$TODAY_FILE"
echo ""

# 确保今日记忆文件存在
if [ ! -f "$TODAY_FILE" ]; then
    echo "# ${TODAY} 记忆日志" > "$TODAY_FILE"
    echo "" >> "$TODAY_FILE"
    echo "文件已创建"
fi

# 读取会话历史（最近 50 行）
if [ -f "$SESSION_HISTORY" ]; then
    RECENT=$(tail -50 "$SESSION_HISTORY")
    
    # 调用 LLM 提取关键信息
    echo "正在分析会话历史..."
    
    # 使用 sessions_send 提取关键信息
    PROMPT="从以下会话历史中提取关键信息（决策、待办、学习收获、重要事实），用简洁的 bullet points 格式：

$RECENT

输出格式：
## 会话摘要 $(date +%H:%M)
- [关键信息 1]
- [关键信息 2]
- ..."

    RESULT=$(sessions_send --message "$PROMPT" 2>&1 | tail -20)
    
    if [ -n "$RESULT" ]; then
        echo "" >> "$TODAY_FILE"
        echo "$RESULT" >> "$TODAY_FILE"
        echo "✓ 已更新记忆文件"
    else
        echo "⚠️  无关键信息可提取"
    fi
else
    echo "⚠️  未找到会话历史文件"
fi

echo ""
echo "=== 完成 ==="
