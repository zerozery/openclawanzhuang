#!/bin/bash
# 快速启动图片查看器
# 用法：./view-image.sh /path/to/image.png

IMAGE_PATH="${1:-/tmp/xhs_image.png}"

if [ ! -f "$IMAGE_PATH" ]; then
    echo "❌ 图片不存在：$IMAGE_PATH"
    exit 1
fi

# 创建临时 HTML
cat > /tmp/viewer.html << EOF
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>🖼️ $IMAGE_PATH</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            background: #1a1a2e;
            color: #eee;
            font-family: system-ui;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }
        h1 { margin-bottom: 20px; font-size: 1.5em; }
        .image-container {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.5);
        }
        img {
            max-width: 90vw;
            max-height: 80vh;
            display: block;
        }
        .info {
            margin-top: 15px;
            color: #888;
            font-size: 14px;
        }
        .btn {
            margin-top: 15px;
            padding: 10px 20px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover { background: #45a049; }
    </style>
</head>
<body>
    <h1>🖼️ 图片查看器</h1>
    <div class="image-container">
        <img src="file://$IMAGE_PATH" alt="图片加载中..." onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22><text x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 fill=%22%23888%22>无法加载</text></svg>'">
    </div>
    <div class="info">
        <p>路径：$IMAGE_PATH</p>
        <p>大小：$(ls -lh "$IMAGE_PATH" | awk '{print $5}')</p>
        <p>尺寸：$(file "$IMAGE_PATH" 2>/dev/null || echo "未知")</p>
    </div>
    <a href="file://$IMAGE_PATH" download class="btn">⬇️ 下载原图</a>
</body>
</html>
EOF

echo "✅ 图片查看器已创建"
echo "📄 HTML 文件：/tmp/viewer.html"
echo "🖼️ 图片路径：$IMAGE_PATH"
echo ""
echo "🌐 用浏览器打开："
echo "   firefox /tmp/viewer.html"
echo "   或 chromium-browser /tmp/viewer.html"
echo ""
echo "🔗 或者启动 HTTP 服务器："
echo "   cd /tmp && python3 -m http.server 8080"
echo "   然后访问：http://localhost:8080/viewer.html"
