#!/bin/bash
# 内容创作进度提醒 - 每天 18:00 检查当日任务完成情况

# 加载配置
source ~/.openclaw/workspace/scripts/env.sh 2>/dev/null || true

# 检查今日是否已发布内容
TODAY=$(date +%Y-%m-%d)
LOG_FILE="/root/.openclaw/workspace/logs/content-publish.log"

# 统计今日发布数量
if [ -f "$LOG_FILE" ]; then
    COUNT=$(grep -c "$TODAY" "$LOG_FILE" 2>/dev/null || echo "0")
else
    COUNT=0
fi

# 生成消息
if [ "$COUNT" -eq 0 ]; then
    MESSAGE="🌿 晚上好，玄柯！

【内容创作提醒】
📅 日期：$TODAY
📝 今日发布：0 篇
⏰ 发布时间：建议 20:00 前

【待办事项】
- 准备明日内容（1 篇）
- 回复评论互动
- 追踪数据表现

【本周进度】
目标：7 篇
已完成：待统计

需要我帮你生成内容吗？随时说一声！💪"
else
    MESSAGE="🌿 晚上好，玄柯！

【今日总结】
📅 日期：$TODAY
📝 今日发布：$COUNT 篇

辛苦啦！继续加油～ 💪"
fi

# 发送到飞书
echo "$MESSAGE" | openclaw message send --target "user:ou_387beeed74b9770a92c3d8705f25280b" --channel feishu

# 记录日志
echo "$(date '+%Y-%m-%d %H:%M:%S') - 进度提醒已发送 (发布：$COUNT 篇)" >> /root/.openclaw/workspace/logs/content-reminder.log
