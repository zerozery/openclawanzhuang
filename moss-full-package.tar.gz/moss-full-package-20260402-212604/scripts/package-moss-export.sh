#!/bin/bash
# MOSS 环境导出打包脚本
# 用于创建完整的 Windows 安装包

set -e

echo "========================================"
echo "  MOSS 环境导出打包"
echo "========================================"
echo ""

EXPORT_DIR="/root/.openclaw/exports/moss-package"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
PACKAGE_NAME="moss-full-package-${TIMESTAMP}"

# 创建导出目录
echo "[1/5] 创建导出目录..."
rm -rf "$EXPORT_DIR"
mkdir -p "$EXPORT_DIR/$PACKAGE_NAME"

# 复制核心配置文件
echo "[2/5] 复制核心配置..."
CORE_FILES=(
    "SOUL.md"
    "USER.md"
    "MEMORY.md"
    "IDENTITY.md"
    "AGENTS.md"
    "HEARTBEAT.md"
    "TOOLS.md"
    "OPERATIONS.md"
)

for file in "${CORE_FILES[@]}"; do
    if [ -f "/root/.openclaw/workspace/$file" ]; then
        cp "/root/.openclaw/workspace/$file" "$EXPORT_DIR/$PACKAGE_NAME/"
        echo "  ✓ $file"
    fi
done

# 复制 memory 目录
echo "[3/5] 复制记忆文件..."
if [ -d "/root/.openclaw/workspace/memory" ]; then
    cp -r "/root/.openclaw/workspace/memory" "$EXPORT_DIR/$PACKAGE_NAME/"
    echo "  ✓ memory/ 目录"
fi

# 复制 skills 目录
echo "[4/5] 复制技能库..."
if [ -d "/root/.openclaw/workspace/skills" ]; then
    # 排除 node_modules 和大文件
    rsync -av --exclude 'node_modules' --exclude '*.pyc' --exclude '__pycache__' \
        "/root/.openclaw/workspace/skills" "$EXPORT_DIR/$PACKAGE_NAME/"
    echo "  ✓ skills/ 目录"
fi

# 复制 scripts 目录
echo "[5/5] 复制脚本工具..."
if [ -d "/root/.openclaw/workspace/scripts" ]; then
    cp -r "/root/.openclaw/workspace/scripts" "$EXPORT_DIR/$PACKAGE_NAME/"
    echo "  ✓ scripts/ 目录"
fi

# 创建 README
cat > "$EXPORT_DIR/$PACKAGE_NAME/README.md" << 'EOF'
# MOSS 完整环境包

这是 MOSS（玄柯的 AI 伙伴）的完整工作环境导出。

## 使用方法

### 方式 1：自动安装（推荐）
1. 运行 `install-moss-full.bat`（Windows）
2. 脚本会自动下载并配置所有文件

### 方式 2：手动部署
1. 将 `workspace` 目录复制到 `~/.openclaw/workspace`
2. 确保权限正确
3. 运行 `openclaw` 启动

## 包含内容

- ✅ 核心配置（SOUL.md, USER.md, MEMORY.md 等）
- ✅ 记忆文件（memory/ 目录）
- ✅ 技能库（skills/ 目录）
- ✅ 脚本工具（scripts/ 目录）

## 注意事项

1. 敏感信息（API keys）已排除，需要手动配置
2. 大型依赖（node_modules）需要重新安装
3. 首次启动会自动下载所需依赖

## 配置 API

编辑 `workspace/.env` 文件，添加你的 API 密钥：

```
# 示例
FEISHU_APP_ID=your_app_id
FEISHU_APP_SECRET=your_app_secret
```

---
导出时间：$(date)
MOSS v1.0 - 玄柯的 AI 伙伴
EOF

# 创建压缩包
echo ""
echo "[6/6] 创建压缩包..."
cd "$EXPORT_DIR"
tar -czf "$PACKAGE_NAME.tar.gz" "$PACKAGE_NAME"
echo "  ✓ $PACKAGE_NAME.tar.gz"

# 显示结果
echo ""
echo "========================================"
echo "  导出完成！"
echo "========================================"
echo ""
echo "📦 包位置：$EXPORT_DIR/$PACKAGE_NAME.tar.gz"
echo "📊 包大小：$(du -h "$EXPORT_DIR/$PACKAGE_NAME.tar.gz" | cut -f1)"
echo ""
echo "📁 包含文件:"
ls -la "$EXPORT_DIR/$PACKAGE_NAME/"
echo ""
