// 每日财经新闻获取脚本
// 使用方法: node fetch_news.mjs

import { execSync } from 'child_process';

const today = new Date().toLocaleDateString('zh-CN', { 
  year: 'numeric', 
  month: 'long', 
  day: 'numeric',
  weekday: 'long'
});

console.log(`\n📊 每日财经简报 - ${today}`);
console.log('='.repeat(50));

// 数据源列表
const sources = [
  { name: '财联社', url: 'https://www.cls.cn/', type: '财经日历' },
  { name: '生意社', url: 'https://www.100ppi.com/', type: '大宗商品' },
  { name: '新浪财经', url: 'https://finance.sina.com.cn/', type: '股票基金' },
];

console.log('\n📰 推荐关注的新闻源:');
sources.forEach((s, i) => {
  console.log(`  ${i+1}. ${s.name} - ${s.type}`);
  console.log(`     ${s.url}`);
});

console.log('\n💡 建议查看的关键词:');
const keywords = [
  '黄金价格', '国际油价', '美元指数', '美联储', '央行政策',
  'A股行情', '港股走势', '美股动态', '基金净值',
  '地缘政治', '战争冲突', '贸易摩擦', '产业政策',
  '新能源', '半导体', '航天军工', '人工智能'
];
keywords.forEach(k => process.stdout.write(`「${k}」 `));

console.log('\n\n⚠️  提示:');
console.log('  • 以上信息仅供参考，不构成投资建议');
console.log('  • 建议使用 Tavily 搜索获取更精准的新闻');
console.log('  • 配置方法: export TAVILY_API_KEY=your_key');
console.log('='.repeat(50));
