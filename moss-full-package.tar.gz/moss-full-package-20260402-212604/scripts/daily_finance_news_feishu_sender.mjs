// 每日财经新闻获取并直接推送到飞书
// 使用方法: node daily_finance_news_feishu_sender.mjs

const TAVILY_API_KEY = process.env.TAVILY_API_KEY || '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';

// 飞书目标配置 - 请填写你的 chat_id 或 open_id
// 获取方法: https://open.feishu.cn/app
const FEISHU_TARGET = process.env.FEISHU_TARGET || 'user:ou_387beeed74b9770a92c3d8705f25280b';

// 获取今日日期
const today = new Date().toLocaleDateString('zh-CN', { 
  year: 'numeric', 
  month: 'long', 
  day: 'numeric',
  weekday: 'long'
});

// 搜索关键词列表
const searchQueries = [
  { query: "黄金价格 最新走势 地缘政治", title: "🥇 黄金市场", emoji: "🥇" },
  { query: "A股 股市 最新消息 政策", title: "📈 A股行情", emoji: "📈" },
  { query: "国际油价 大宗商品 最新", title: "⛽ 大宗商品", emoji: "⛽" },
  { query: "美联储 央行 利率政策", title: "🏦 央行政策", emoji: "🏦" },
  { query: "AI 人工智能 大模型 最新技术突破 2026", title: "🤖 AI 技术前沿", emoji: "🤖" },
  { query: "GitHub trending hot repositories AI tools", title: "🔥 GitHub 热点", emoji: "🔥" }
];

async function fetchNewsWithTavily(query, maxResults = 5) {
  try {
    const response = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        api_key: TAVILY_API_KEY,
        query: query,
        search_depth: "advanced",
        topic: "news",
        max_results: maxResults,
        include_answer: true,
        include_images: false
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error(`获取新闻失败 [${query}]:`, error.message);
    return null;
  }
}

function formatNewsSection(title, data, emoji) {
  if (!data || !data.results || data.results.length === 0) {
    return `${emoji} ${title}\n暂无相关新闻\n`;
  }
  
  let section = `${emoji} ${title}\n`;
  
  // 添加AI总结（如果有）
  if (data.answer) {
    // 简化总结，避免太长
    const summary = data.answer.length > 200 
      ? data.answer.substring(0, 200) + '...' 
      : data.answer;
    section += `${summary}\n\n`;
  }
  
  // 添加新闻源（最多2条）
  data.results.slice(0, 2).forEach((result, index) => {
    section += `${index + 1}. ${result.title}\n`;
  });
  
  return section;
}

async function generateNewsReport() {
  console.log(`📊 正在生成 ${today} 的财经简报...\n`);
  
  let fullReport = `📰 每日早报 - ${today}\n`;
  fullReport += `${'='.repeat(30)}\n\n`;
  
  for (const item of searchQueries) {
    console.log(`正在获取: ${item.title}...`);
    const data = await fetchNewsWithTavily(item.query);
    fullReport += formatNewsSection(item.title, data, item.emoji);
    fullReport += `\n`;
    
    // 延迟一下避免请求过快
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  fullReport += `${'='.repeat(30)}\n`;
  fullReport += `💡 提示: 以上信息仅供参考，不构成投资建议\n`;
  fullReport += `🤖 由 MOSS 自动推送 | 🕘 每天上午9点更新\n`;
  
  return fullReport;
}

// 发送到飞书
async function sendToFeishu(message) {
  // 检查是否配置了目标ID
  if (!FEISHU_TARGET) {
    console.log('⚠️  未配置飞书目标ID，跳过发送');
    console.log('   请在脚本中设置 FEISHU_TARGET 或设置环境变量');
    console.log('   获取方法: https://open.feishu.cn/app');
    return false;
  }
  
  try {
    const { execSync } = await import('child_process');
    
    // 使用 openclaw message 命令发送到飞书
    const result = execSync(
      `openclaw message send --channel feishu --target "${FEISHU_TARGET}" --message "${message.replace(/"/g, '\\"')}"`,
      { encoding: 'utf-8', timeout: 30000 }
    );
    
    console.log('✅ 消息已发送到飞书');
    return true;
  } catch (error) {
    console.error('❌ 发送到飞书失败:', error.message);
    return false;
  }
}

// 主函数
async function main() {
  const report = await generateNewsReport();
  
  // 打印到控制台
  console.log('\n========== 生成的简报 ==========\n');
  console.log(report);
  console.log('\n================================\n');
  
  // 发送到飞书
  console.log('正在发送到飞书...');
  const sent = await sendToFeishu(report);
  
  if (!sent) {
    // 如果发送失败，保存到文件
    const fs = await import('fs');
    const reportPath = '/root/.openclaw/workspace/reports/daily_finance_news.txt';
    const dir = '/root/.openclaw/workspace/reports';
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(reportPath, report, 'utf-8');
    console.log(`报告已保存到: ${reportPath}`);
  }
}

main().catch(console.error);
