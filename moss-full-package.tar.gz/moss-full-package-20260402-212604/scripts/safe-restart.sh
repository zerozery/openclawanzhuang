#!/bin/bash
# OpenClaw 安全重启脚本
# 用法：./safe-restart.sh [备注]

NOTE=${1:-"manual"}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "🦞 OpenClaw 安全重启流程"
echo "========================"
echo ""

# 步骤 1: 备份配置
echo "📦 步骤 1/4: 备份当前配置..."
"$SCRIPT_DIR/backup-config.sh" "$NOTE"
if [ $? -ne 0 ]; then
    echo "❌ 备份失败，中止重启"
    exit 1
fi
echo ""

# 步骤 2: 验证配置
echo "🔍 步骤 2/4: 验证配置合法性..."
"$SCRIPT_DIR/validate-config.sh"
if [ $? -ne 0 ]; then
    echo "❌ 配置验证失败，中止重启"
    exit 1
fi
echo ""

# 步骤 3: 重启网关
echo "🔄 步骤 3/4: 重启网关服务..."
openclaw gateway restart
if [ $? -ne 0 ]; then
    echo "❌ 重启命令执行失败"
    exit 1
fi

# 等待网关启动
echo "⏳ 等待网关启动..."
sleep 5
echo ""

# 步骤 4: 验证服务
echo "✅ 步骤 4/4: 验证服务状态..."
openclaw status --json > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 重启成功！"
    echo ""
    echo "备份位置：~/.openclaw/backups/"
    echo "如需恢复：cp ~/.openclaw/backups/openclaw.*.json ~/.openclaw/openclaw.json"
else
    echo ""
    echo "⚠️  网关状态检查失败，请手动检查："
    echo "   openclaw status"
    echo "   openclaw logs"
fi
