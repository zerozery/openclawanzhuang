// 每日财经新闻获取并推送到飞书
// 使用方法: node daily_finance_news_feishu.mjs

const TAVILY_API_KEY = process.env.TAVILY_API_KEY || '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';

// 获取今日日期
const today = new Date().toLocaleDateString('zh-CN', { 
  year: 'numeric', 
  month: 'long', 
  day: 'numeric',
  weekday: 'long'
});

// 搜索关键词列表
const searchQueries = [
  { query: "黄金价格 最新走势 地缘政治", title: "🥇 黄金市场" },
  { query: "A股 股市 最新消息 政策", title: "📈 A股行情" },
  { query: "国际油价 大宗商品 最新", title: "⛽ 大宗商品" },
  { query: "美联储 央行 利率政策", title: "🏦 央行政策" }
];

async function fetchNewsWithTavily(query, maxResults = 5) {
  try {
    const response = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        api_key: TAVILY_API_KEY,
        query: query,
        search_depth: "advanced",
        topic: "news",
        max_results: maxResults,
        include_answer: true,
        include_images: false
      })
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error(`获取新闻失败 [${query}]:`, error.message);
    return null;
  }
}

function formatNewsSection(title, data) {
  if (!data || !data.results || data.results.length === 0) {
    return `${title}\n暂无相关新闻\n`;
  }
  
  let section = `${title}\n`;
  
  // 添加AI总结（如果有）
  if (data.answer) {
    section += `💡 ${data.answer}\n\n`;
  }
  
  // 添加新闻源
  section += `📰 相关报道:\n`;
  data.results.slice(0, 3).forEach((result, index) => {
    section += `  ${index + 1}. ${result.title}\n`;
    if (result.content) {
      const summary = result.content.length > 100 
        ? result.content.substring(0, 100) + '...' 
        : result.content;
      section += `     ${summary}\n`;
    }
    section += `     🔗 ${result.url}\n\n`;
  });
  
  return section;
}

async function generateNewsReport() {
  console.log(`📊 正在生成 ${today} 的财经简报...\n`);
  
  let fullReport = `📊 每日财经简报 - ${today}\n`;
  fullReport += `${'='.repeat(40)}\n\n`;
  
  for (const item of searchQueries) {
    console.log(`正在获取: ${item.title}...`);
    const data = await fetchNewsWithTavily(item.query);
    fullReport += formatNewsSection(item.title, data);
    fullReport += `\n`;
    
    // 延迟一下避免请求过快
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  fullReport += `${'='.repeat(40)}\n`;
  fullReport += `💡 提示: 以上信息仅供参考，不构成投资建议\n`;
  fullReport += `🤖 由 MOSS 自动推送\n`;
  
  return fullReport;
}

// 输出到控制台（可以通过飞书webhook发送）
async function main() {
  const report = await generateNewsReport();
  console.log(report);
  
  // 将报告保存到文件
  const fs = await import('fs');
  const reportPath = '/root/.openclaw/workspace/reports/daily_finance_news.txt';
  
  // 确保目录存在
  const dir = '/root/.openclaw/workspace/reports';
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  fs.writeFileSync(reportPath, report, 'utf-8');
  console.log(`\n✅ 报告已保存到: ${reportPath}`);
}

main().catch(console.error);
