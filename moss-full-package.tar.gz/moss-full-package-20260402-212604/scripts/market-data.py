#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
市场数据查询脚本 - 用于投资早报
功能：获取黄金价格、沪深 300、纳斯达克 100 等实时行情
数据源：新浪财经、东方财富
"""

import json
import urllib.request
import urllib.error
from datetime import datetime

# 设置请求头，避免被反爬
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
}

def fetch_url(url, timeout=10):
    """获取 URL 内容"""
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return response.read().decode('utf-8', errors='ignore')
    except Exception as e:
        return None

def parse_sina_stock(code):
    """
    解析新浪财经股票行情
    code: 股票代码 (如 sh000300, gb_NDX)
    返回：{name, price, change, change_percent, time}
    """
    url = f"http://hq.sinajs.cn/list={code}"
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=5) as response:
            data = response.read().decode('gbk', errors='ignore')
        
        # 格式：var hq_str_sh000300="名称，开盘，昨收，当前，最高，最低，..."
        if '=' in data and '"' in data:
            parts = data.split('=')[1].strip('"').split(',')
            if len(parts) >= 32:
                name = parts[0]
                current = float(parts[3]) if parts[3] else 0
                open_price = float(parts[1]) if parts[1] else 0
                yesterday = float(parts[2]) if parts[2] else 0
                high = float(parts[4]) if parts[4] else 0
                low = float(parts[5]) if parts[5] else 0
                
                change = current - yesterday
                change_percent = (change / yesterday * 100) if yesterday else 0
                
                return {
                    'name': name,
                    'price': current,
                    'change': change,
                    'change_percent': change_percent,
                    'high': high,
                    'low': low,
                    'open': open_price,
                    'yesterday': yesterday
                }
    except Exception as e:
        pass
    
    return None

def get_gold_prices():
    """
    获取黄金价格
    返回：{international, domestic}
    """
    result = {
        'international': None,  # COMEX 黄金 (美元/盎司)
        'domestic': None  # 沪金主连 (元/克)
    }
    
    # 1. 获取 COMEX 黄金 (通过东方财富)
    try:
        url = "https://quote.eastmoney.com/center/hjsc.html"
        html = fetch_url(url)
        if html:
            # 搜索 COMEX 黄金价格
            import re
            # 查找类似 "COMEX 黄金.*?(\d+\.\d+)" 的模式
            match = re.search(r'COMEX 黄金.*?(\d{3,4}\.\d{1,2})', html)
            if match:
                result['international'] = {
                    'price': float(match.group(1)),
                    'unit': '美元/盎司',
                    'source': '东方财富'
                }
    except:
        pass
    
    # 2. 获取沪金主连 (通过新浪财经)
    try:
        # 沪金主连代码：nf_AU0
        data = fetch_url("http://hq.sinajs.cn/list=nf_AU0")
        if data:
            parts = data.split('=')[1].strip('"').split(',')
            if len(parts) >= 10:
                current = float(parts[7]) if parts[7] else 0
                yesterday = float(parts[6]) if parts[6] else 0
                change = current - yesterday
                change_percent = (change / yesterday * 100) if yesterday else 0
                
                result['domestic'] = {
                    'price': current,
                    'change': change,
                    'change_percent': change_percent,
                    'unit': '元/克',
                    'source': '新浪财经'
                }
    except:
        pass
    
    return result

def get_stock_indices():
    """
    获取股票指数
    返回：{hs300, ndx, sse, szse}
    """
    result = {}
    
    # 沪深 300 (sh000300)
    hs300 = parse_sina_stock('sh000300')
    if hs300:
        result['hs300'] = {
            'name': '沪深 300',
            'price': hs300['price'],
            'change': hs300['change'],
            'change_percent': hs300['change_percent'],
            'unit': '点',
            'source': '新浪财经'
        }
    
    # 纳斯达克 100 (gb_NDX)
    ndx = parse_sina_stock('gb_NDX')
    if ndx:
        result['ndx'] = {
            'name': '纳斯达克 100',
            'price': ndx['price'],
            'change': ndx['change'],
            'change_percent': ndx['change_percent'],
            'unit': '点',
            'source': '新浪财经'
        }
    
    # 纳斯达克综合 (gb_IXIC)
    ixic = parse_sina_stock('gb_IXIC')
    if ixic:
        result['nasdaq_composite'] = {
            'name': '纳斯达克综合',
            'price': ixic['price'],
            'change': ixic['change'],
            'change_percent': ixic['change_percent'],
            'unit': '点',
            'source': '新浪财经'
        }
    
    # 上证指数 (sh000001)
    sse = parse_sina_stock('sh000001')
    if sse:
        result['sse'] = {
            'name': '上证指数',
            'price': sse['price'],
            'change': sse['change'],
            'change_percent': sse['change_percent'],
            'unit': '点',
            'source': '新浪财经'
        }
    
    # 深证成指 (sz399001)
    szse = parse_sina_stock('sz399001')
    if szse:
        result['szse'] = {
            'name': '深证成指',
            'price': szse['price'],
            'change': szse['change'],
            'change_percent': szse['change_percent'],
            'unit': '点',
            'source': '新浪财经'
        }
    
    return result

def format_report():
    """生成格式化的市场数据报告"""
    report = []
    report.append("📊 市场数据报告")
    report.append(f"更新时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("=" * 50)
    report.append("")
    
    # 黄金价格
    report.append("🥇 黄金价格")
    gold = get_gold_prices()
    if gold['international']:
        g = gold['international']
        report.append(f"  • COMEX 黄金：${g['price']:.2f}/盎司 ({g['source']})")
    if gold['domestic']:
        g = gold['domestic']
        arrow = "↑" if g['change'] >= 0 else "↓"
        report.append(f"  • 沪金主连：{g['price']:.2f}元/克 {arrow}{abs(g['change_percent']):.2f}% ({g['source']})")
    report.append("")
    
    # 股票指数
    report.append("📈 股票指数")
    indices = get_stock_indices()
    
    # A 股
    if 'hs300' in indices:
        i = indices['hs300']
        arrow = "↑" if i['change'] >= 0 else "↓"
        report.append(f"  • {i['name']}: {i['price']:.2f}点 {arrow}{abs(i['change_percent']):.2f}%")
    
    if 'sse' in indices:
        i = indices['sse']
        arrow = "↑" if i['change'] >= 0 else "↓"
        report.append(f"  • {i['name']}: {i['price']:.2f}点 {arrow}{abs(i['change_percent']):.2f}%")
    
    if 'szse' in indices:
        i = indices['szse']
        arrow = "↑" if i['change'] >= 0 else "↓"
        report.append(f"  • {i['name']}: {i['price']:.2f}点 {arrow}{abs(i['change_percent']):.2f}%")
    
    # 美股
    report.append("")
    report.append("🇺🇸 美股指数")
    if 'ndx' in indices:
        i = indices['ndx']
        arrow = "↑" if i['change'] >= 0 else "↓"
        report.append(f"  • {i['name']}: {i['price']:.2f}点 {arrow}{abs(i['change_percent']):.2f}%")
    
    if 'nasdaq_composite' in indices:
        i = indices['nasdaq_composite']
        arrow = "↑" if i['change'] >= 0 else "↓"
        report.append(f"  • {i['name']}: {i['price']:.2f}点 {arrow}{abs(i['change_percent']):.2f}%")
    
    report.append("")
    report.append("=" * 50)
    
    return "\n".join(report)

def get_json_data():
    """获取 JSON 格式数据 (用于程序调用)"""
    data = {
        'timestamp': datetime.now().isoformat(),
        'gold': get_gold_prices(),
        'indices': get_stock_indices()
    }
    return json.dumps(data, ensure_ascii=False, indent=2)

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--json':
        # 输出 JSON 格式
        print(get_json_data())
    else:
        # 输出格式化报告
        print(format_report())
