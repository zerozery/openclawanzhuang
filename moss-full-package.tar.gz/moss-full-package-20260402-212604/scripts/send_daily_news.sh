#!/bin/bash
# 每日财经新闻推送到飞书
# 每天早上9点执行

# 设置环境变量
export TAVILY_API_KEY="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"

# 运行新闻获取脚本并保存到文件
cd /root/.openclaw/workspace
node scripts/daily_finance_news_feishu.mjs > /tmp/finance_news.log 2>&1

# 读取生成的报告内容
REPORT_FILE="/root/.openclaw/workspace/reports/daily_finance_news.txt"
if [ -f "$REPORT_FILE" ]; then
    REPORT_CONTENT=$(cat "$REPORT_FILE")
    
    # 使用飞书消息工具发送
    # 注意：这里假设飞书插件已配置
    openclaw message send --channel feishu --message "$REPORT_CONTENT" 2>/dev/null || echo "飞书发送失败，请检查飞书配置"
fi

echo "[$(date)] 财经新闻任务执行完成" >> /root/.openclaw/workspace/logs/finance_cron.log
