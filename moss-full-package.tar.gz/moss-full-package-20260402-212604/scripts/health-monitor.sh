#!/bin/bash
# OpenClaw 健康监控脚本
# 用法：./health-monitor.sh [--fix]

LOG_FILE="$HOME/.openclaw/logs/health-monitor.log"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

check_gateway() {
    if systemctl is-active --quiet openclaw-gateway 2>/dev/null; then
        return 0
    elif pgrep -f "openclaw.*gateway" > /dev/null 2>&1; then
        return 0
    else
        return 1
    fi
}

check_websocket() {
    local response=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:18789/ 2>/dev/null)
    if [ "$response" = "200" ] || [ "$response" = "101" ]; then
        return 0
    else
        return 1
    fi
}

# 主检查逻辑
log "=== 健康检查开始 ==="

# 1. 检查网关服务
if check_gateway; then
    log "✅ 网关服务运行正常"
else
    log "❌ 网关服务未运行，尝试重启..."
    if command -v openclaw &> /dev/null; then
        openclaw gateway restart
        sleep 5
        if check_gateway; then
            log "✅ 网关重启成功"
        else
            log "❌ 网关重启失败，需要人工干预"
        fi
    else
        log "❌ openclaw 命令不可用"
    fi
fi

# 2. 检查 WebSocket 端口
if check_websocket; then
    log "✅ WebSocket 端口可访问"
else
    log "⚠️  WebSocket 端口无法访问"
fi

# 3. 检查磁盘空间
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -lt 80 ]; then
    log "✅ 磁盘空间充足 (${DISK_USAGE}%)"
elif [ "$DISK_USAGE" -lt 90 ]; then
    log "⚠️  磁盘空间警告 (${DISK_USAGE}%)"
else
    log "❌ 磁盘空间不足 (${DISK_USAGE}%)"
fi

# 4. 检查内存
MEM_AVAILABLE=$(free -m | awk '/^Mem:/ {print $7}')
if [ "$MEM_AVAILABLE" -gt 500 ]; then
    log "✅ 内存充足 (${MEM_AVAILABLE}MB 可用)"
elif [ "$MEM_AVAILABLE" -gt 200 ]; then
    log "⚠️  内存警告 (${MEM_AVAILABLE}MB 可用)"
else
    log "❌ 内存不足 (${MEM_AVAILABLE}MB 可用)"
fi

# 5. 检查 cron 任务
CRON_FILE="$HOME/.openclaw/cron/jobs.json"
if [ -f "$CRON_FILE" ]; then
    JOB_COUNT=$(grep -c '"id"' "$CRON_FILE" 2>/dev/null || echo 0)
    log "✅ 定时任务配置存在 (${JOB_COUNT}个任务)"
else
    log "⚠️  定时任务配置文件不存在"
fi

log "=== 健康检查完成 ==="
echo ""

# 如果传入了 --fix 参数，尝试自动修复
if [ "$1" = "--fix" ]; then
    log "执行自动修复..."
    
    # 验证配置
    if [ -x "$HOME/.openclaw/workspace/scripts/validate-config.sh" ]; then
        "$HOME/.openclaw/workspace/scripts/validate-config.sh"
    fi
    
    # 备份配置
    if [ -x "$HOME/.openclaw/workspace/scripts/backup-config.sh" ]; then
        "$HOME/.openclaw/workspace/scripts/backup-config.sh" "auto-fix"
    fi
    
    log "自动修复完成"
fi
