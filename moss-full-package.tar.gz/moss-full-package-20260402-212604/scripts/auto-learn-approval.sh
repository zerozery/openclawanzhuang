#!/bin/bash
# MOSS 自主学习脚本 - 每两天执行一次
# 用法：./auto-learn-approval.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE="$HOME/.openclaw/workspace"
LEARNINGS_DIR="$WORKSPACE/.learnings"
REPORT_FILE="$LEARNINGS_DIR/skill-recommendations-$(date +%Y%m%d).md"

# 搜索关键词列表（围绕变现目标）
SEARCH_KEYWORDS=(
    "douyin"
    "video"
    "content"
    "xiaohongshu"
    "image"
    "automation"
)

# 高优先级技能列表（需要审批）
HIGH_PRIORITY_SKILLS=()

echo "🌿 MOSS 自主学习 - 技能推荐 ($(date))"
echo "======================================"

# 创建推荐报告
cat > "$REPORT_FILE" << EOF
# MOSS 技能推荐清单

**生成时间**: $(date +%Y-%m-%d %H:%M)
**目标**: 围绕变现目标的技能推荐

---

## 🔴 高优先级推荐（需要审批）

这些技能对当前目标（自媒体变现）有直接帮助：

EOF

# 搜索并评估技能
for keyword in "${SEARCH_KEYWORDS[@]}"; do
    echo "🔍 搜索：$keyword"
    
    # 搜索技能
    result=$(clawhub search "$keyword" 2>&1 | head -10) || {
        echo "⚠️  Rate limit，继续下一个..." 
        continue
    }
    
    # 简单评估：提取前 3 个技能
    echo "$result" | head -3 | while read -r line; do
        skill_name=$(echo "$line" | awk '{print $1}')
        if [ -n "$skill_name" ] && [ "$skill_name" != "-" ]; then
            echo "✅ 发现：$skill_name"
            # 检查是否已安装
            if ! clawhub list 2>&1 | grep -q "$skill_name"; then
                echo "   → 未安装，加入推荐清单"
                HIGH_PRIORITY_SKILLS+=("$skill_name")
            fi
        fi
    done
    
    sleep 3  # 避免 rate limit
done

# 生成推荐清单
if [ ${#HIGH_PRIORITY_SKILLS[@]} -gt 0 ]; then
    echo "" >> "$REPORT_FILE"
    for skill in "${HIGH_PRIORITY_SKILLS[@]}"; do
        # 获取技能详情
        skill_info=$(clawhub inspect "$skill" 2>&1 | head -10)
        echo "### $skill" >> "$REPORT_FILE"
        echo "" >> "$REPORT_FILE"
        echo "\`\`\`" >> "$REPORT_FILE"
        echo "$skill_info" >> "$REPORT_FILE"
        echo "\`\`\`" >> "$REPORT_FILE"
        echo "" >> "$REPORT_FILE"
    done
    
    echo "" >> "$REPORT_FILE"
    echo "---" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo "## 审批指令" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo "回复「安装」或「yes」确认安装上述技能" >> "$REPORT_FILE"
else
    echo "" >> "$REPORT_FILE"
    echo "暂无新技能推荐（可能已安装或无相关技能）" >> "$REPORT_FILE"
fi

echo ""
echo "📊 生成报告：$REPORT_FILE"
echo "✅ 自主学习完成"

# 显示推荐摘要
echo ""
echo "======================================"
echo "推荐技能数量：${#HIGH_PRIORITY_SKILLS[@]}"
if [ ${#HIGH_PRIORITY_SKILLS[@]} -gt 0 ]; then
    echo "推荐清单："
    printf '  - %s\n' "${HIGH_PRIORITY_SKILLS[@]}"
fi

# 输出报告路径（用于后续发送飞书）
echo ""
echo "报告路径：$REPORT_FILE"
