// 每日早报 - 纯中文源版（节省 token）
// 只从中文网站获取信息，无需翻译
const TAVILY_API_KEY = process.env.TAVILY_API_KEY || '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';
const FEISHU_TARGET = process.env.FEISHU_TARGET || 'user:ou_387beeed74b9770a92c3d8705f25280b';

const today = new Date().toLocaleDateString('zh-CN', { 
  year: 'numeric', month: 'long', day: 'numeric', weekday: 'long'
});

// 只从中文网站搜索 - 节省 token，无需翻译
const searchQueries = [
  { 
    query: "地缘政治 紧张局势 国际冲突 site:qq.com OR site:163.com OR site:huanqiu.com", 
    title: "🌍 国际局势", 
    emoji: "🌍",
    hint: "→ 影响：黄金、石油、国防股"
  },
  { 
    query: "中国 航天 卫星 发射 计划 长征 site:qq.com OR site:163.com OR site:spacechina.com", 
    title: "🚀 航天军工", 
    emoji: "🚀",
    hint: "→ 影响：航天、军工、通信股"
  },
  { 
    query: "AI 大模型 技术突破 融资 投资 site:36kr.com OR site:qq.com OR site:163.com", 
    title: "🤖 AI 前沿", 
    emoji: "🤖",
    hint: "→ 影响：AI 芯片、算力、应用股"
  },
  { 
    query: "固态电池 新能源 汽车 技术 政策 site:qq.com OR site:163.com", 
    title: "⚡ 新能源", 
    emoji: "⚡",
    hint: "→ 影响：锂电、整车、光伏股"
  },
  { 
    query: "半导体 芯片 国产替代 大基金 投资 site:qq.com OR site:163.com", 
    title: "💾 半导体", 
    emoji: "💾",
    hint: "→ 影响：芯片、设备、材料股"
  },
  { 
    query: "创新药 批准 临床 医药 site:qq.com OR site:163.com", 
    title: "💊 医药", 
    emoji: "💊",
    hint: "→ 影响：创新药、医疗器械股"
  }
];

async function fetchNews(query) {
  try {
    const res = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: TAVILY_API_KEY,
        query,
        search_depth: "advanced",
        topic: "news",
        max_results: 3,
        include_answer: false  // 不要 AI 总结，节省 token
      })
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (e) {
    return null;
  }
}

function formatSection(item, data) {
  if (!data || !data.results?.length) return `${item.emoji} ${item.title}\n暂无重要信号\n\n`;
  
  let section = `${item.emoji} ${item.title}\n`;
  
  // 只用新闻标题（最多 3 条，纯中文）
  data.results.slice(0, 3).forEach(r => {
    section += `• ${r.title}\n`;
  });
  
  // 添加影响提示
  section += `\n${item.hint}\n`;
  
  return section + '\n';
}

async function generateReport() {
  console.log(`📈 生成 ${today} 投资机会早报...\n`);
  
  let report = `📈 投资机会早报 - ${today}\n`;
  report += `${'='.repeat(35)}\n`;
  report += `💡 前瞻性信息 · 辅助决策参考\n\n`;
  
  for (const item of searchQueries) {
    console.log(`获取：${item.title}...`);
    const data = await fetchNews(item.query);
    const section = formatSection(item, data);
    report += section;
    await new Promise(r => setTimeout(r, 500));
  }
  
  report += `${'='.repeat(35)}\n`;
  report += `⚠️ 以上信息仅供参考，不构成投资建议\n`;
  report += `🤖 MOSS 自动推送 | 每天 9:00 更新\n`;
  
  return report;
}

async function sendToFeishu(msg) {
  try {
    const { execSync } = await import('child_process');
    execSync(
      `openclaw message send --channel feishu --target "${FEISHU_TARGET}" --message "${msg.replace(/"/g, '\\"')}"`,
      { encoding: 'utf-8', timeout: 30000 }
    );
    console.log('✅ 已发送');
    return true;
  } catch (e) {
    console.error('发送失败:', e.message);
    return false;
  }
}

(async () => {
  const report = await generateReport();
  console.log('\n========== 预览 ==========\n');
  console.log(report);
  await sendToFeishu(report);
})().catch(console.error);
