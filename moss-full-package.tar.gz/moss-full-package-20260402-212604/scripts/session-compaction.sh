#!/bin/bash
# Session Compaction - 精简会话历史，提取关键信息到记忆

WORKSPACE="/root/.openclaw/workspace"
MEMORY_DIR="$WORKSPACE/memory"
TODAY=$(date +%Y-%m-%d)
TODAY_FILE="$MEMORY_DIR/${TODAY}.md"

echo "=== Session Compaction ===" 
echo "时间：$(date)"
echo ""

# 获取当前会话状态
CONTEXT_INFO=$(session_status 2>&1 | grep "Context:")
echo "当前上下文：$CONTEXT_INFO"

# 如果上下文超过 100k，触发压缩
CONTEXT_USED=$(echo "$CONTEXT_INFO" | grep -oP '\d+(?=k/)')

if [ -n "$CONTEXT_USED" ] && [ "$CONTEXT_USED" -gt 100 ]; then
    echo "⚠️  上下文超过 100k，触发压缩..."
    
    # 提示用户确认
    echo ""
    echo "是否将当前会话的关键信息提取到记忆文件？"
    echo "这将："
    echo "  1. 提取关键决策/信息到 $TODAY_FILE"
    echo "  2. 精简会话历史（保留最近 10 轮对话）"
    echo ""
    read -p "确认执行？(y/n): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        # 调用记忆提取
        echo "正在提取关键信息..."
        
        # 这里可以调用 LLM 提取关键信息
        # sessions_send --message "请从当前会话中提取 3-5 个关键信息..."
        
        echo "✓ 压缩完成"
    else
        echo "已取消"
    fi
else
    echo "✅ 上下文使用正常，无需压缩"
fi
