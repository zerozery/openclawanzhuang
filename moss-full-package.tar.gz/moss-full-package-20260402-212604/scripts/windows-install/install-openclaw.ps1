# OpenClaw Windows 一键安装脚本
# 适用于 Windows 10/11
# 使用方法：右键以管理员身份运行，或在 PowerShell 中执行 .\install-openclaw.ps1

param(
    [switch]$Help,
    [switch]$SkipNode,
    [string]$InstallPath
)

# 帮助信息
if ($Help) {
    Write-Host @"
OpenClaw Windows 一键安装脚本

用法:
  .\install-openclaw.ps1 [-Help] [-SkipNode] [-InstallPath <路径>]

参数:
  -Help        显示此帮助信息
  -SkipNode    跳过 Node.js 安装（已手动安装时使用）
  -InstallPath 自定义安装路径（默认：%USERPROFILE%\.openclaw）

示例:
  .\install-openclaw.ps1
  .\install-openclaw.ps1 -SkipNode
  .\install-openclaw.ps1 -InstallPath "D:\OpenClaw"
"@ -ForegroundColor Cyan
    exit 0
}

# 颜色主题
$Theme = @{
    Title = 'Cyan'
    Success = 'Green'
    Warning = 'Yellow'
    Error = 'Red'
    Info = 'White'
}

# 打印标题
function Write-Title {
    param([string]$Text)
    Write-Host ""
    Write-Host "======================================" -ForegroundColor $Theme.Title
    Write-Host "  $Text" -ForegroundColor $Theme.Title
    Write-Host "======================================" -ForegroundColor $Theme.Title
    Write-Host ""
}

function Write-Step {
    param([string]$Text)
    Write-Host ""
    Write-Host "[$Text]" -ForegroundColor $Theme.Warning
}

function Write-Success {
    param([string]$Text)
    Write-Host "✓ $Text" -ForegroundColor $Theme.Success
}

function Write-Error {
    param([string]$Text)
    Write-Host "✗ $Text" -ForegroundColor $Theme.Error
}

# 开始安装
Write-Title "OpenClaw 一键安装脚本 (Windows 版)"

# 检查管理员权限
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Warning "建议以管理员身份运行，否则可能安装失败"
    $continue = Read-Host "是否继续？(y/n)"
    if ($continue -ne "y" -and $continue -ne "Y") {
        Write-Host "安装已取消" -ForegroundColor $Theme.Warning
        exit 0
    }
}

# 设置安装路径
if (-not $InstallPath) {
    $InstallPath = "$env:USERPROFILE\.openclaw"
}

# 步骤 1: 检查 Node.js
Write-Step "1/5 检查 Node.js"
try {
    $nodeVersion = node --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Success "Node.js 已安装：$nodeVersion"
        
        # 检查版本（需要 18+）
        $nodeMajor = [int]($nodeVersion -replace 'v(\d+)\..*', '$1')
        if ($nodeMajor -lt 18) {
            Write-Warning "Node.js 版本过低（需要 18+），建议升级"
            if (-not $SkipNode) {
                $update = Read-Host "是否更新 Node.js？(y/n)"
                if ($update -eq "y" -or $update -eq "Y") {
                    $SkipNode = $false
                } else {
                    $SkipNode = $true
                }
            }
        }
    } else {
        throw "Node.js not found"
    }
} catch {
    if (-not $SkipNode) {
        Write-Host "Node.js 未安装，正在通过 winget 安装..." -ForegroundColor $Theme.Warning
        try {
            winget install OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements --silent
            Write-Success "Node.js 安装完成"
            
            # 刷新环境变量
            $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        } catch {
            Write-Error "Node.js 安装失败"
            Write-Host "请手动安装：https://nodejs.org/" -ForegroundColor $Theme.Warning
            pause
            exit 1
        }
    } else {
        Write-Error "未检测到 Node.js 且跳过了安装"
        exit 1
    }
}

# 步骤 2: 检查 pnpm
Write-Step "2/5 检查 pnpm"
try {
    $pnpmVersion = pnpm --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Success "pnpm 已安装：$pnpmVersion"
    } else {
        throw "pnpm not found"
    }
} catch {
    Write-Host "正在安装 pnpm..." -ForegroundColor $Theme.Warning
    try {
        npm install -g pnpm
        Write-Success "pnpm 安装完成"
        
        # 刷新环境变量
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
    } catch {
        Write-Error "pnpm 安装失败"
        Write-Host "请手动运行：npm install -g pnpm" -ForegroundColor $Theme.Warning
        pause
        exit 1
    }
}

# 步骤 3: 创建安装目录
Write-Step "3/5 创建安装目录"
if (!(Test-Path $InstallPath)) {
    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    Write-Success "目录已创建：$InstallPath"
} else {
    Write-Success "目录已存在：$InstallPath"
}

# 步骤 4: 安装 OpenClaw
Write-Step "4/5 安装 OpenClaw"
Set-Location $InstallPath

# 检查是否已安装
if (Test-Path "$InstallPath\node_modules\openclaw") {
    Write-Host "检测到已安装的 OpenClaw" -ForegroundColor $Theme.Warning
    $action = Read-Host "选择操作：1-更新 2-重新安装 3-取消 (1/2/3)"
    
    if ($action -eq "1") {
        Write-Host "正在更新 OpenClaw..." -ForegroundColor $Theme.Warning
        pnpm update openclaw
        Write-Success "OpenClaw 更新完成"
    } elseif ($action -eq "2") {
        Write-Host "正在重新安装 OpenClaw..." -ForegroundColor $Theme.Warning
        Remove-Item -Path "$InstallPath\node_modules" -Recurse -Force
        pnpm create openclaw@latest .
        Write-Success "OpenClaw 重新安装完成"
    } else {
        Write-Host "安装已取消" -ForegroundColor $Theme.Warning
        exit 0
    }
} else {
    try {
        pnpm create openclaw@latest .
        Write-Success "OpenClaw 安装完成"
    } catch {
        Write-Error "OpenClaw 安装失败"
        Write-Host "请检查网络连接或手动安装" -ForegroundColor $Theme.Warning
        pause
        exit 1
    }
}

# 步骤 5: 配置环境变量
Write-Step "5/5 配置环境变量"
$envPath = [Environment]::GetEnvironmentVariable("PATH", "User")
$nodeModulesBin = "$InstallPath\node_modules\.bin"

if ($envPath -notlike "*$nodeModulesBin*") {
    [Environment]::SetEnvironmentVariable("PATH", $envPath + ";$nodeModulesBin", "User")
    Write-Success "环境变量已配置"
    
    # 刷新当前会话
    $env:Path += ";$nodeModulesBin"
} else {
    Write-Success "环境变量已存在"
}

# 创建快捷方式
Write-Host "正在创建桌面快捷方式..." -ForegroundColor $Theme.Warning
try {
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\OpenClaw.lnk")
    $Shortcut.TargetPath = "powershell.exe"
    $Shortcut.Arguments = "-NoExit -Command `"cd '$InstallPath'; openclaw`""
    $Shortcut.WorkingDirectory = $InstallPath
    $Shortcut.IconLocation = "shell32.dll,13"
    $Shortcut.Description = "OpenClaw - AI 助手框架"
    $Shortcut.Save()
    Write-Success "桌面快捷方式已创建"
} catch {
    Write-Warning "快捷方式创建失败（可手动创建）"
}

# 完成
Write-Title "安装完成！"

Write-Host @"
🎉 OpenClaw 已成功安装！

📍 安装位置：$InstallPath

下一步：
  1. 验证安装：openclaw --version
  2. 配置向导：openclaw configure
  3. 启动网关：openclaw gateway start
  4. 或直接运行：openclaw

📚 资源：
  - 文档：https://docs.openclaw.ai
  - 技能市场：https://clawhub.ai
  - 社区：https://discord.gg/clawd
  - GitHub：https://github.com/openclaw/openclaw

"@ -ForegroundColor $Theme.Info

# 询问是否现在配置
$configure = Read-Host "是否现在运行配置向导？(y/n)"
if ($configure -eq "y" -or $configure -eq "Y") {
    Write-Host "正在启动配置向导..." -ForegroundColor $Theme.Warning
    Set-Location $InstallPath
    openclaw configure
}

# 询问是否现在启动
$launch = Read-Host "是否现在启动 OpenClaw？(y/n)"
if ($launch -eq "y" -or $launch -eq "Y") {
    Write-Host "正在启动 OpenClaw..." -ForegroundColor $Theme.Warning
    Set-Location $InstallPath
    openclaw
}

Write-Host ""
Write-Success "祝你使用愉快！🌿"
Write-Host ""
