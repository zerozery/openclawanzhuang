# MOSS 分身安装包

这是 MOSS（玄柯的 AI 伙伴）的完整环境打包，安装后在 Windows 上运行一个相同的 AI 分身。

## 📦 包含内容

### 核心配置
- `SOUL.md` - AI 人格设定
- `USER.md` - 用户信息（玄柯）
- `MEMORY.md` - 长期记忆
- `memory/` - 每日记忆日志
- `IDENTITY.md` - 身份定义
- `AGENTS.md` - Agent 行为准则

### 技能库
- 35+ 个预装技能
- 自媒体内容工具（小红书、抖音等）
- 财经数据爬虫
- 自动化工具
- Feishu/企业微信集成

### 项目文件
- AI 自媒体项目配置
- Windows 安装脚本
- 财经数据工具

## 🚀 安装步骤

### 前置要求
- Windows 10/11
- 至少 4GB 可用内存
- 至少 10GB 可用磁盘空间
- 网络连接

### 一键安装

1. **先安装基础环境**
   ```
   双击运行：install-prerequisites.bat
   ```
   自动安装：
   - Node.js 18+
   - pnpm（包管理器）
   - Git（可选）

2. **安装 MOSS 分身**
   ```
   双击运行：install-moss-full.bat
   ```
   这会：
   - 下载完整环境包
   - 解压到用户目录
   - 配置环境变量
   - 创建桌面快捷方式

3. **启动 MOSS**
   ```
   双击桌面 "MOSS AI 助手" 快捷方式
   或运行：start-moss.bat
   ```

## 📁 安装后位置

```
C:\Users\你的用户名\.openclaw\
├── workspace/          # 工作区（技能、记忆、配置）
│   ├── SOUL.md        # 人格设定
│   ├── MEMORY.md      # 长期记忆
│   ├── memory/        # 每日记忆
│   ├── skills/        # 技能库
│   └── scripts/       # 脚本工具
├── agents/            # Agent 配置
├── extensions/        # 扩展插件
└── openclaw.json      # 主配置
```

## 🔧 常用命令

```bash
# 启动 MOSS
openclaw

# 查看状态
openclaw status

# 查看日志
openclaw logs

# 重启网关
openclaw gateway restart

# 停止服务
openclaw gateway stop

# 安装新技能
openclaw skills install <skill-name>
```

## 📝 配置说明

### 需要手动配置的内容

安装完成后，需要配置以下服务（如果需要）：

1. **飞书集成**（可选）
   - 编辑 `workspace/.env`
   - 添加飞书 API 凭证

2. **企业微信集成**（可选）
   - 编辑 `workspace/.env`
   - 添加企业微信 API 凭证

3. **模型配置**
   - 默认使用本地模型
   - 如需使用云端模型，编辑 `openclaw.json`

### 已预配置的内容

- ✅ 淘宝 npm 镜像（国内加速）
- ✅ 基础技能库
- ✅ MOSS 人格设定
- ✅ 玄柯的用户配置

## ⚠️ 注意事项

1. **首次启动较慢** - 需要初始化环境，耐心等待
2. **保持网络畅通** - 部分技能需要联网
3. **定期更新** - 运行 `openclaw skills update` 更新技能
4. **备份记忆** - 重要记忆会自动保存，但建议定期备份 `memory/` 目录

## 🆘 故障排查

### 启动失败
```bash
# 查看详细日志
openclaw logs

# 重置网关
openclaw gateway restart
```

### 技能无法使用
```bash
# 重新安装技能
openclaw skills sync
```

### 网络问题
```bash
# 检查网络连接
ping www.baidu.com

# 使用代理（如果需要）
set HTTP_PROXY=http://your-proxy:port
```

## 📞 支持

- 文档：https://docs.openclaw.ai
- 技能市场：https://clawhub.ai
- 社区：https://discord.gg/clawd

---

**MOSS v1.0** - 玄柯的 AI 伙伴
最后更新：2026-04-02
