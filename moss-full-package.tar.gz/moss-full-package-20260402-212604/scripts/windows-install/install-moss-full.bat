@echo off
chcp 65001 >nul
title MOSS 分身完整安装

echo.
echo ========================================
echo   MOSS AI 分身 - 完整安装
echo ========================================
echo.
echo 正在安装 MOSS（玄柯的 AI 伙伴）到本机...
echo.

:: 检查前置环境
echo [准备] 检查前置环境...
echo ----------------------------------------
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未检测到 Node.js
    echo 请先运行：install-prerequisites.bat
    pause
    exit /b 1
)
echo ✓ Node.js 已安装
node --version

pnpm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未检测到 pnpm
    echo 请先运行：install-prerequisites.bat
    pause
    exit /b 1
)
echo ✓ pnpm 已安装
pnpm --version
echo.

:: 设置 npm 镜像
echo [1/6] 配置 npm 镜像...
echo ----------------------------------------
call npm config set registry https://registry.npmmirror.com/
echo ✓ 已设置淘宝镜像
echo.

:: 创建安装目录
echo [2/6] 创建安装目录...
echo ----------------------------------------
set "INSTALL_DIR=%USERPROFILE%\.openclaw"
if exist "%INSTALL_DIR%" (
    echo [提示] 检测到现有安装
    set /p overwrite="是否覆盖安装？(y/n): "
    if /i not "%overwrite%"=="y" (
        echo 安装已取消
        pause
        exit /b 0
    )
    echo 正在备份现有配置...
    set "BACKUP_DIR=%INSTALL_DIR%\backup_%date:~0,4%%date:~5,2%%date:~8,2%"
    if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"
    xcopy "%INSTALL_DIR%\workspace" "%BACKUP_DIR%\workspace" /E /I /Y >nul 2>&1
    echo ✓ 配置已备份到：%BACKUP_DIR%
)

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
echo ✓ 安装目录：%INSTALL_DIR%
echo.

:: 安装 OpenClaw 框架
echo [3/6] 安装 OpenClaw 框架...
echo ----------------------------------------
cd /d "%INSTALL_DIR%"
echo 正在安装（可能需要 3-5 分钟）...
call pnpm create openclaw@latest .
if %errorlevel% neq 0 (
    echo.
    echo [错误] OpenClaw 安装失败
    echo 请检查网络连接后重试
    pause
    exit /b 1
)
echo ✓ OpenClaw 框架安装完成
echo.

:: 下载 MOSS 配置文件
echo [4/6] 下载 MOSS 配置文件...
echo ----------------------------------------
set "WORKSPACE_DIR=%INSTALL_DIR%\workspace"
if not exist "%WORKSPACE_DIR%" mkdir "%WORKSPACE_DIR%"

echo 正在从 GitHub 下载 MOSS 配置...

:: 下载核心配置文件
powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/zerozery/openclawanzhuang/main/workspace/SOUL.md' -OutFile '%WORKSPACE_DIR%\SOUL.md' -UseBasicParsing" 2>nul
if %errorlevel% equ 0 (echo ✓ SOUL.md) else (echo ✗ SOUL.md 下载失败)

powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/zerozery/openclawanzhuang/main/workspace/USER.md' -OutFile '%WORKSPACE_DIR%\USER.md' -UseBasicParsing" 2>nul
if %errorlevel% equ 0 (echo ✓ USER.md) else (echo ✗ USER.md 下载失败)

powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/zerozery/openclawanzhuang/main/workspace/MEMORY.md' -OutFile '%WORKSPACE_DIR%\MEMORY.md' -UseBasicParsing" 2>nul
if %errorlevel% equ 0 (echo ✓ MEMORY.md) else (echo ✗ MEMORY.md 下载失败)

powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/zerozery/openclawanzhuang/main/workspace/IDENTITY.md' -OutFile '%WORKSPACE_DIR%\IDENTITY.md' -UseBasicParsing" 2>nul
if %errorlevel% equ 0 (echo ✓ IDENTITY.md) else (echo ✗ IDENTITY.md 下载失败)

powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/zerozery/openclawanzhuang/main/workspace/AGENTS.md' -OutFile '%WORKSPACE_DIR%\AGENTS.md' -UseBasicParsing" 2>nul
if %errorlevel% equ 0 (echo ✓ AGENTS.md) else (echo ✗ AGENTS.md 下载失败)

powershell -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/zerozery/openclawanzhuang/main/workspace/HEARTBEAT.md' -OutFile '%WORKSPACE_DIR%\HEARTBEAT.md' -UseBasicParsing" 2>nul
if %errorlevel% equ 0 (echo ✓ HEARTBEAT.md) else (echo ✗ HEARTBEAT.md 下载失败)

echo.
echo [提示] 技能文件较大，建议手动下载技能包
echo 下载地址：https://github.com/zerozery/openclawanzhuang
echo.

:: 创建 memory 目录
echo [5/6] 创建记忆目录...
echo ----------------------------------------
if not exist "%WORKSPACE_DIR%\memory" mkdir "%WORKSPACE_DIR%\memory"
echo ✓ memory 目录已创建
echo.

:: 创建启动脚本
echo [6/6] 创建启动脚本...
echo ----------------------------------------

:: 创建 start-moss.bat
set "START_SCRIPT=%INSTALL_DIR%\start-moss.bat"
echo @echo off > "%START_SCRIPT%"
echo chcp 65001 ^>nul >> "%START_SCRIPT%"
echo title MOSS AI 助手 >> "%START_SCRIPT%"
echo. >> "%START_SCRIPT%"
echo echo ======================================== >> "%START_SCRIPT%"
echo echo   MOSS AI 助手 - 玄柯的伙伴 >> "%START_SCRIPT%"
echo echo ======================================== >> "%START_SCRIPT%"
echo echo. >> "%START_SCRIPT%"
echo cd /d "%INSTALL_DIR%" >> "%START_SCRIPT%"
echo call openclaw >> "%START_SCRIPT%"
echo. >> "%START_SCRIPT%"
echo ✓ 启动脚本已创建：%START_SCRIPT%

:: 创建桌面快捷方式
echo.
set /p createShortcut="是否创建桌面快捷方式？(y/n): "
if /i "%createShortcut%"=="y" (
    powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%USERPROFILE%\Desktop\MOSS AI 助手.lnk'); $Shortcut.TargetPath = '%START_SCRIPT%'; $Shortcut.WorkingDirectory = '%INSTALL_DIR%'; $Shortcut.Description = 'MOSS - 玄柯的 AI 伙伴'; $Shortcut.Save()"
    if %errorlevel% equ 0 (
        echo ✓ 桌面快捷方式已创建
    ) else (
        echo [警告] 快捷方式创建失败
    )
)
echo.

:: 完成
echo ========================================
echo   MOSS 分身安装完成！
echo ========================================
echo.
echo 🎉 MOSS 已成功安装到本机！
echo.
echo 📍 安装位置：%INSTALL_DIR%
echo 📁 工作区：%WORKSPACE_DIR%
echo.
echo 📋 快速开始：
echo   1. 双击桌面 "MOSS AI 助手" 快捷方式
echo   2. 或运行：%START_SCRIPT%
echo   3. 或命令行：cd %INSTALL_DIR% ^&^& openclaw
echo.
echo 🧠 MOSS 的人格和记忆已配置完成
echo 📚 技能库需要手动下载（见 GitHub）
echo.
echo ⚠️  首次启动较慢，请耐心等待初始化
echo.

:: 询问是否启动
set /p launch="是否现在启动 MOSS？(y/n): "
if /i "%launch%"=="y" (
    cd /d "%INSTALL_DIR%"
    call openclaw
) else (
    echo.
    echo ✓ 稍后双击快捷方式即可启动
)

echo.
echo 🌿 MOSS 随时为你服务！
echo.
pause
